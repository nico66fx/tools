@echo off
rem ===================================================================
rem  FABRICA DE ESTRATEGIAS - arranque de la consola con doble clic.
rem
rem  El "cd /d %~dp0" es necesario: al hacer doble clic, Windows puede
rem  dejarte en C:\Windows\System32 como carpeta actual, y ahi no estan
rem  ni servidor.py ni lector.py. %~dp0 es la carpeta de ESTE .bat.
rem
rem  El "pause" del final tampoco es adorno: sin el, si Python no esta
rem  instalado o el servidor revienta al arrancar, la ventana se cierra
rem  de golpe y te quedas sin ver el mensaje que explica que ha pasado.
rem ===================================================================
title Fabrica de estrategias - servidor local
cd /d "%~dp0"

python servidor.py %*

echo.
echo El servidor se ha cerrado.
pause
