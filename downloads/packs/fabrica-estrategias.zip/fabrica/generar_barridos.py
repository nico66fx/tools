# -*- coding: utf-8 -*-
"""
Genera un .set y un .ini por cada senal de la plantilla.

POR QUE UN BARRIDO POR SENAL Y NO UNO SOLO:
Un unico barrido mixto no funciona. Cada senal usa el gen InpUmbral en una
escala distinta (RSI 5..45, Bollinger 0.5..4.0, momento 0.01..2.0) y dos
senales no lo usan en absoluto. Un rango unico que las cubra todas hace que
la inmensa mayoria de combinaciones sorteadas sean invalidas: en la prueba
real MetaTrader aborto con
    "503 passes of 512 failed, genetic optimization stopped at generation 0"
porque el algoritmo genetico se rinde cuando casi toda la generacion falla.
Partiendolo por senal, cada barrido tiene su escala propia, la tasa de
combinaciones validas sube al 40-46 %, y ademas ninguna senal le roba el
presupuesto de busqueda a las otras.
"""
import argparse
import io
import os
import sys

# La carpeta de ESTE fichero. Nada de rutas absolutas de nadie: el proyecto
# funciona alla donde lo descomprima quien se lo baje.
RAIZ = os.path.dirname(os.path.abspath(__file__))
if RAIZ not in sys.path:
    sys.path.insert(0, RAIZ)

import detectar_mt5

DESDE = "2018.01.01"
HASTA = "2025.12.31"

# Genes comunes a todos los barridos: nombre -> (valor, inicio, paso, fin, optimizar)
COMUNES = [
    ("InpDireccion",       "0",        "0",    "1",    "2",    "Y"),
    ("InpFiltroTend",      "0",        "0",    "1",    "2",    "Y"),
    ("InpPeriodoTend",     "50",       "50",   "50",   "250",  "Y"),
    ("InpHoraInicio",      "0",        "0",    "2",    "20",   "Y"),
    ("InpHoraFin",         "23",       "3",    "2",    "23",   "Y"),
    ("InpATRPeriodo",      "14",       "10",   "5",    "20",   "Y"),
    ("InpMultSL",          "2.0",      "1.0",  "0.5",  "4.0",  "Y"),
    ("InpMultTP",          "3.0",      "1.0",  "0.5",  "6.0",  "Y"),
    ("InpSalidaContraria", "false",    "false","1",    "true", "Y"),
    # No son genes: configuracion fija.
    ("InpRiesgoPct",       "0.5",      "0.5",  "0.1",  "0.5",  "N"),
    ("InpMagico",          "20260914", "20260914", "1", "20260914", "N"),
]

# Por senal: (id, nombre, rango de InpPeriodoA, rango de InpPeriodoB, rango de InpUmbral)
# Los rangos de umbral son los que OnInit acepta para esa senal; asi ninguna
# combinacion se descarta por umbral fuera de escala.
# Los genes que la senal NO usa van a su valor CANONICO (20 / 0.5 / 50), que es
# lo que OnInit exige para no clonar pasadas.
SENALES = [
    ("s0_cruce",     "Cruce de medias",   ("12", "5",  "5",   "60"),
                                          ("36", "20", "20",  "200"),
                                          ("0.5", "0.5", "0.5", "0.5", "N")),
    ("s1_rsi",       "RSI en umbral",     ("14", "5",  "5",   "40"),
                                          ("20", "20", "20",  "20"),
                                          ("30.0", "10.0", "5.0", "45.0", "Y")),
    ("s2_ruptura",   "Ruptura de rango",  ("20", "5",  "5",   "60"),
                                          ("20", "20", "20",  "20"),
                                          ("0.5", "0.5", "0.5", "0.5", "N")),
    ("s3_bollinger", "Banda de Bollinger",("20", "10", "5",   "60"),
                                          ("20", "20", "20",  "20"),
                                          ("2.0", "1.0", "0.5", "4.0", "Y")),
    ("s4_momento",   "Momento simple",    ("14", "5",  "5",   "60"),
                                          ("20", "20", "20",  "20"),
                                          ("0.25", "0.05", "0.05", "1.0", "Y")),
]

PLANTILLA_INI = r"""; Barrido de la senal {idx} - {nombre}
; Generado por generar_barridos.py. Ver el README para los valores verificados.
[Experts]
AllowLiveTrading=0
Enabled=1
Account=1
Profile=1

[Tester]
Expert=Fabrica\FabricaEA.ex5
ExpertParameters={set_nombre}
Symbol=EURUSD
Period=H1
Model=1
FromDate={desde}
ToDate={hasta}
ForwardMode=3
Deposit=10000
Currency=USD
Leverage=1:100
Optimization=2
OptimizationCriterion=6
Visual=0
Report={informe}
ReplaceReport=1
ShutdownTerminal=1
"""


def linea(nombre, valor, inicio, paso, fin, opt):
    return "%s=%s||%s||%s||%s||%s" % (nombre, valor, inicio, paso, fin, opt)


def main(argv=None):
    analizador = argparse.ArgumentParser(
        description="Genera los .set y los .ini de los barridos de la fabrica.")
    detectar_mt5.anade_argumento_terminal(analizador)
    args = analizador.parse_args(argv)

    # La carpeta del terminal NO esta escrita en el codigo: se busca sola, y
    # se puede mandar a mano con --terminal o con la variable de entorno.
    # Si no hay ninguno servible, exige_terminal para el programa y explica
    # que falta.
    terminal = detectar_mt5.exige_terminal(args.terminal)
    destino_set = detectar_mt5.carpeta_sets(terminal)

    dir_sets = os.path.join(RAIZ, "sets")
    dir_logs = os.path.join(RAIZ, "logs")
    os.makedirs(dir_sets, exist_ok=True)
    os.makedirs(dir_logs, exist_ok=True)
    generados = []

    for idx, (clave, nombre, pa, pb, um) in enumerate(SENALES):
        lineas = [
            "; Barrido de la senal %d - %s" % (idx, nombre),
            "; Formato MetaTrader: nombre=valor||inicio||paso||fin||optimizar(Y/N)",
            "; Los genes que esta senal no usa van a su valor canonico, que es lo",
            "; que OnInit exige para no probar la misma estrategia dos veces.",
            linea("InpSenal", str(idx), str(idx), "1", str(idx), "N"),
            linea("InpPeriodoA", pa[0], pa[1], pa[2], pa[3], "Y"),
            linea("InpPeriodoB", pb[0], pb[1], pb[2], pb[3],
                  "Y" if idx == 0 else "N"),
            linea("InpUmbral", um[0], um[1], um[2], um[3], um[4]),
        ]
        for g in COMUNES:
            lineas.append(linea(*g))
        contenido = "\n".join(lineas) + "\n"

        nombre_set = "fabrica_%s.set" % clave
        io.open(os.path.join(dir_sets, nombre_set), "w",
                encoding="utf-8", newline="\r\n").write(contenido)
        if not os.path.isdir(destino_set):
            # La carpeta de .set del Probador la crea MetaTrader la primera vez
            # que se usa el Probador. Si aun no existe, se crea: sin ella el
            # terminal no encontraria los parametros del barrido.
            os.makedirs(destino_set, exist_ok=True)
        io.open(os.path.join(destino_set, nombre_set), "w",
                encoding="utf-8", newline="\r\n").write(contenido)

        informe = "fabrica_%s.xml" % clave
        ini = PLANTILLA_INI.format(idx=idx, nombre=nombre, set_nombre=nombre_set,
                                   desde=DESDE, hasta=HASTA, informe=informe)
        nombre_ini = "optimizar_%s.ini" % clave
        io.open(os.path.join(dir_logs, nombre_ini), "w",
                encoding="utf-8", newline="\r\n").write(ini)
        generados.append((nombre, nombre_set, nombre_ini, informe))

    print("Barridos generados:")
    for nombre, s, i, r in generados:
        print("  %-20s  %-28s  %-28s  -> %s" % (nombre, s, i, r))
    print("Los .set tambien se han copiado a: %s" % destino_set)


if __name__ == "__main__":
    main()
