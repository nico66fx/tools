# -*- coding: utf-8 -*-
"""
Fase 6 - Verificacion de un candidato.

Coge un candidato del resultados.json y prepara lo necesario para volver a
pasarlo por el Probador de MetaTrader como TEST INDIVIDUAL (no optimizacion),
con el mismo periodo y la misma configuracion que uso el barrido.

El objetivo es comprobar que la fila del XML se REPRODUCE. Si el test
individual no da lo mismo que decia el XML, algo esta mal y hay que decirlo,
no taparlo.

Uso:
    python verificar.py <resultados.json> [--pasada N] [--salida-dir DIR]
                        [--terminal RUTA]

Si no se indica --pasada, coge el mejor candidato APTO; si no hay ninguno
apto, coge el de mayor puntuacion y lo avisa por pantalla.
"""
import argparse
import io
import json
import os
import sys

# La carpeta de ESTE fichero: el proyecto no sabe -ni tiene por que saber- en
# que disco lo ha dejado quien se lo haya descargado.
RAIZ = os.path.dirname(os.path.abspath(__file__))
if RAIZ not in sys.path:
    sys.path.insert(0, RAIZ)

import detectar_mt5

# Genes que NO aparecen como columna en el XML porque no se optimizaron,
# pero que hay que fijar igualmente para reproducir la pasada.
FIJOS_POR_DEFECTO = {
    "InpRiesgoPct": "0.5",
    "InpMagico": "20260914",
}


def lee_set(ruta):
    """Lee un .set de MetaTrader y devuelve {nombre: valor_por_defecto}."""
    valores = {}
    if not os.path.isfile(ruta):
        return valores
    with io.open(ruta, encoding="utf-8", errors="ignore") as fh:
        for linea in fh:
            linea = linea.strip()
            if not linea or linea.startswith(";") or "=" not in linea:
                continue
            nombre, resto = linea.split("=", 1)
            valores[nombre.strip()] = resto.split("||")[0].strip()
    return valores


def formatea(valor):
    """Convierte un valor del JSON al texto que espera un fichero .set."""
    if isinstance(valor, bool):
        return "true" if valor else "false"
    if isinstance(valor, float):
        # Sin notacion cientifica y sin ceros de adorno.
        t = ("%.10f" % valor).rstrip("0").rstrip(".")
        return t if t else "0"
    return str(valor)


def elige_candidato(datos, pasada):
    cands = datos.get("candidatos", [])
    if not cands:
        sys.exit("El fichero no contiene candidatos.")
    if pasada is not None:
        for c in cands:
            if str(c.get("pass")) == str(pasada):
                return c, "pasada %s pedida a mano" % pasada
        sys.exit("No existe la pasada %s en el fichero." % pasada)
    aptas = [c for c in cands if c.get("apta")]
    if aptas:
        mejor = max(aptas, key=lambda c: c.get("puntuacion") or 0.0)
        return mejor, "mejor candidato APTO"
    mejor = max(cands, key=lambda c: c.get("puntuacion") or 0.0)
    return mejor, ("NINGUN candidato paso las puertas; se verifica el de mayor "
                   "puntuacion solo para comprobar que la cadena reproduce")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("resultados")
    ap.add_argument("--pasada", default=None)
    ap.add_argument("--set-base", default=os.path.join(RAIZ, "sets",
                                                       "fabrica_completo.set"))
    ap.add_argument("--salida-dir", default=RAIZ)
    ap.add_argument("--desde", default="2018.01.01")
    ap.add_argument("--hasta", default="2025.12.31")
    ap.add_argument("--set-destino", default=None,
                    help="Donde dejar el .set para el Probador. Por defecto, la "
                         "carpeta Tester del terminal que se detecte.")
    detectar_mt5.anade_argumento_terminal(ap)
    args = ap.parse_args()

    # De donde sale la carpeta del terminal: de --set-destino si lo han dicho a
    # mano, y si no, del terminal que se detecte (o del que manden con
    # --terminal / la variable de entorno). Clavada en el codigo, de ningun
    # sitio: esto tiene que funcionar en la maquina de cualquiera.
    if args.set_destino:
        set_destino = args.set_destino
    else:
        terminal = detectar_mt5.exige_terminal(args.terminal)
        set_destino = os.path.join(detectar_mt5.carpeta_sets(terminal),
                                   "fabrica_verificar.set")

    datos = json.load(io.open(args.resultados, encoding="utf-8"))
    cand, motivo = elige_candidato(datos, args.pasada)

    print("=" * 72)
    print("VERIFICACION DE UN CANDIDATO (Fase 6)")
    print("=" * 72)
    print("  Motivo de la eleccion : %s" % motivo)
    print("  Pasada                : %s" % cand.get("pass"))
    print("  Puntuacion en el XML  : %s" % cand.get("puntuacion"))
    print("  Beneficio en el XML   : %s" % cand.get("beneficio"))
    print("  Factor de beneficio   : %s" % cand.get("factor_beneficio"))
    print("  Operaciones           : %s" % cand.get("operaciones"))
    print("  Caida %%               : %s" % cand.get("caida_pct"))
    print("  Forward               : %s" % cand.get("resultado_forward"))
    print("  Apta                  : %s" % cand.get("apta"))
    if cand.get("motivos"):
        for m in cand["motivos"]:
            print("      - %s" % m)

    # Partimos de los valores del .set del barrido y los pisamos con los genes
    # concretos de esta pasada. Los genes que no se optimizaron no salen en el
    # XML, por eso hace falta el .set como base.
    base = lee_set(args.set_base)
    base.update(FIJOS_POR_DEFECTO)
    genes = cand.get("genes", {}) or {}
    base.update({k: formatea(v) for k, v in genes.items()})

    print("\n  GENES DE ESTE CANDIDATO (los que venian del XML):")
    for k in sorted(genes):
        print("      %-20s = %s" % (k, formatea(genes[k])))

    lineas = ["; Verificacion de la pasada %s - todos los genes FIJOS (sin optimizar)"
              % cand.get("pass")]
    for nombre, valor in base.items():
        lineas.append("%s=%s||%s||0||%s||N" % (nombre, valor, valor, valor))
    contenido = "\n".join(lineas) + "\n"

    for destino in (set_destino,
                    os.path.join(args.salida_dir, "sets", "fabrica_verificar.set")):
        carpeta = os.path.dirname(destino)
        if carpeta and not os.path.isdir(carpeta):
            os.makedirs(carpeta)
        io.open(destino, "w", encoding="utf-8", newline="\r\n").write(contenido)
        print("\n  .set escrito en: %s" % destino)

    ini = r"""; Verificacion individual de la pasada {pasada} - NO es una optimizacion.
[Experts]
AllowLiveTrading=0
Enabled=1
Account=1
Profile=1

[Tester]
Expert=Fabrica\FabricaEA.ex5
ExpertParameters=fabrica_verificar.set
Symbol=EURUSD
Period=H1
Model=1
FromDate={desde}
ToDate={hasta}
ForwardMode=0
Deposit=10000
Currency=USD
Leverage=1:100
Optimization=0
Visual=0
Report=fabrica_verificar.htm
ReplaceReport=1
ShutdownTerminal=1
""".format(pasada=cand.get("pass"), desde=args.desde, hasta=args.hasta)

    ruta_ini = os.path.join(args.salida_dir, "logs", "verificar.ini")
    if not os.path.isdir(os.path.dirname(ruta_ini)):
        os.makedirs(os.path.dirname(ruta_ini))
    io.open(ruta_ini, "w", encoding="utf-8", newline="\r\n").write(ini)
    print("  .ini escrito en: %s" % ruta_ini)

    esperado = {
        "pass": cand.get("pass"),
        "puntuacion": cand.get("puntuacion"),
        "beneficio": cand.get("beneficio"),
        "factor_beneficio": cand.get("factor_beneficio"),
        "operaciones": cand.get("operaciones"),
        "caida_pct": cand.get("caida_pct"),
        "genes": genes,
    }
    ruta_esp = os.path.join(args.salida_dir, "informes", "verificar_esperado.json")
    if not os.path.isdir(os.path.dirname(ruta_esp)):
        os.makedirs(os.path.dirname(ruta_esp))
    json.dump(esperado, io.open(ruta_esp, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("  Valores esperados en: %s" % ruta_esp)
    print("\n  Ahora ejecuta el terminal con ese .ini y compara.")
    print("=" * 72)


if __name__ == "__main__":
    main()
