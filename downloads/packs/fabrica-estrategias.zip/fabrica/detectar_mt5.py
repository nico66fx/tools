# -*- coding: utf-8 -*-
"""
detectar_mt5.py -- encuentra solo las instalaciones de MetaTrader 5.

POR QUE EXISTE ESTE FICHERO
---------------------------
La fabrica tiene que escribir ficheros dentro de la carpeta de datos del
terminal y lanzar terminal64.exe. Hasta ahora esa ruta estaba escrita a mano
en el codigo, lo cual funciona en UNA maquina y en ninguna mas. Este modulo la
busca solo, para que quien se descargue la fabrica no tenga que configurar
nada.

DONDE BUSCA (esto esta comprobado en maquinas reales, no supuesto)
------------------------------------------------------------------
1) Instalaciones NORMALES. MetaTrader no guarda sus datos junto al programa:
   los guarda en
       %APPDATA%\\MetaQuotes\\Terminal\\<32 caracteres hexadecimales>\\
   Esa carpeta se reconoce porque tiene dentro MQL5\\Experts, y trae un
   origin.txt (texto UTF-16 con BOM) que dice de que carpeta de INSTALACION
   salio; de ahi sacamos terminal64.exe y MetaEditor64.exe. Las carpetas
   Common, Community y Help que viven al lado NO son terminales.

2) Instalaciones PORTABLES. Son carpetas que llevan a la vez terminal64.exe y
   MQL5\\. Ahi los datos viven en la propia carpeta del programa y hay que
   lanzar el terminal con /portable. Se buscan en Program Files, en
   Program Files (x86) y en la raiz de cada disco fijo, bajando 3 niveles y
   con un tope de tiempo, para no pasarse diez minutos recorriendo un disco
   de 4 TB.

3) Y siempre vale que el usuario diga la ruta a mano: elegir_terminal() acepta
   tanto una carpeta de datos como una carpeta de instalacion.

QUE COMPRUEBA DE CADA UNO
-------------------------
  - Que existan MQL5\\Experts y MQL5\\Files y que se pueda ESCRIBIR en ambas.
    Se comprueba creando y borrando un fichero de verdad, no mirando los
    permisos declarados: en Windows los permisos declarados mienten a menudo
    (carpetas bajo Program Files con virtualizacion, unidades de red...).
  - Que este terminal64.exe.
  - Que el terminal TENGA CUENTA. Esto es decisivo y no se ve a simple vista:
    un terminal recien instalado que nunca se conecto a un broker hace que el
    Probador se niegue a arrancar con
        "tester not started because the account is not specified"
    y el barrido acaba sin informe y sin explicacion. Se detecta mirando las
    subcarpetas de bases\\: si solo estan Default, Custom, signals y Chats no
    hay ninguna cuenta; cualquier otra subcarpeta es el nombre del servidor de
    un broker.
  - Que NO haya ningun robot adjunto a los graficos. Un robot adjunto se
    activa solo al abrir el terminal y puede colocar ordenes en la cuenta,
    asi que conviene saberlo antes de arrancar nada. Se detecta leyendo los
    ficheros de los perfiles de graficos en binario y buscando nombres
    acabados en .ex5.

Solo biblioteca estandar. Python 3.

Uso como programa:
    python detectar_mt5.py
"""

from __future__ import annotations

import os
import re
import string
import sys
import time

# ---------------------------------------------------------------------------
# CONSTANTES DE BUSQUEDA
# ---------------------------------------------------------------------------

# Las carpetas de datos de un terminal se llaman con 32 caracteres hex.
RE_CARPETA_DATOS = re.compile(r"^[0-9A-Fa-f]{32}$")

# Vecinas de las carpetas de datos que NO son terminales.
NO_SON_TERMINALES = {"common", "community", "help"}

# Subcarpetas de bases\ que NO son cuentas de broker. Cualquier otra subcarpeta
# que aparezca ahi ES el nombre del servidor de un broker, y por tanto prueba
# de que este terminal ha tenido cuenta abierta alguna vez.
BASES_QUE_NO_SON_CUENTA = {"default", "custom", "signals", "chats"}

# Carpetas que no se recorren nunca al buscar portables: son enormes, estan
# protegidas y ahi no hay ningun MetaTrader.
NO_ENTRAR = {
    "windows", "$recycle.bin", "system volume information",
    "windows.old", "msocache", "$windows.~ws", "$windows.~bt",
    "perflogs", "recovery", "config.msi",
}

# Nombre de un robot compilado dentro de un fichero .chr.
RE_EX5 = re.compile(r"[A-Za-z0-9 _.\-]{3,60}\.ex5")

# Tope de bytes que se leen de un .chr. Son ficheros pequenos; el tope solo
# esta para que un fichero corrupto de 2 GB no se coma la memoria.
MAX_BYTES_CHR = 4 * 1024 * 1024

# Cuanto puede tardar como mucho el rastreo de portables por los discos.
SEGUNDOS_BUSQUEDA = 20.0

# Cuantos niveles se baja desde cada raiz al buscar portables.
NIVELES = 3


# ---------------------------------------------------------------------------
# UTILIDADES PEQUENAS
# ---------------------------------------------------------------------------

def _normal(ruta):
    """Forma canonica de una ruta, para poder compararlas sin sustos."""
    if not ruta:
        return ""
    return os.path.normcase(os.path.abspath(ruta))


def _hija(padre, nombre):
    """Devuelve la subcarpeta 'nombre' de 'padre' con su capitalizacion real.

    Hace falta porque en un portable la carpeta se llama 'Bases' y en una
    instalacion normal 'bases'. Windows no distingue, pero el codigo si, y
    algun dia esto correra sobre una unidad de red que si distinga.
    """
    directo = os.path.join(padre, nombre)
    if os.path.isdir(directo):
        return directo
    try:
        for entrada in os.listdir(padre):
            if entrada.lower() == nombre.lower():
                candidata = os.path.join(padre, entrada)
                if os.path.isdir(candidata):
                    return candidata
    except OSError:
        pass
    return None


def _momento(ruta):
    """Fecha de modificacion de una ruta, o 0 si no se puede saber."""
    try:
        return os.path.getmtime(ruta)
    except OSError:
        return 0.0


def probar_escritura(ruta):
    """Comprueba de verdad si se puede escribir en una carpeta.

    Crea un fichero, escribe un byte y lo borra. Devolver True aqui significa
    que la fabrica va a poder dejar sus .set y su robot ahi dentro; mirar los
    permisos declarados por Windows no lo garantiza.
    """
    if not ruta or not os.path.isdir(ruta):
        return False
    nombre = ".fabrica_prueba_%d_%d.tmp" % (os.getpid(), int(time.time() * 1000) % 100000)
    destino = os.path.join(ruta, nombre)
    try:
        with open(destino, "wb") as fh:
            fh.write(b"fabrica")
    except OSError:
        return False
    try:
        os.remove(destino)
    except OSError:
        # Se pudo crear pero no borrar: raro, pero escribir se puede, que es lo
        # que nos importa. Se deja el fichero y se avisa por consola.
        pass
    return True


def _parrafo(texto, ancho=68, sangria="       "):
    """Parte un aviso largo en lineas que quepan en una consola estrecha."""
    palabras = texto.split()
    lineas, actual = [], ""
    for palabra in palabras:
        if actual and len(actual) + 1 + len(palabra) > ancho:
            lineas.append(actual)
            actual = palabra
        else:
            actual = (actual + " " + palabra) if actual else palabra
    if actual:
        lineas.append(actual)
    return ("\n" + sangria).join(lineas)


def _lee_origin(carpeta_datos):
    """Carpeta de INSTALACION a la que apunta el origin.txt de una de datos.

    El fichero es texto UTF-16 con BOM. Se decodifica mirando el BOM en vez de
    probar a ciegas: un UTF-8 leido como UTF-16 no da error, da basura, y una
    ruta basura es peor que ninguna ruta.
    """
    ruta = os.path.join(carpeta_datos, "origin.txt")
    try:
        with open(ruta, "rb") as fh:
            bruto = fh.read(4096)
    except OSError:
        return None
    if not bruto:
        return None
    if bruto[:2] in (b"\xff\xfe", b"\xfe\xff"):
        codecs = ("utf-16",)
    elif bruto[:3] == b"\xef\xbb\xbf":
        codecs = ("utf-8-sig",)
    else:
        codecs = ("utf-8", "latin-1")
    for codec in codecs:
        try:
            texto = bruto.decode(codec)
        except (UnicodeDecodeError, UnicodeError):
            continue
        texto = texto.replace("\ufeff", "").replace("\x00", "").strip()
        texto = texto.splitlines()[0].strip() if texto.splitlines() else ""
        # Una ruta de Windows lleva ':' (C:\...) o empieza por '\\' (red).
        if texto and (":" in texto or texto.startswith("\\\\")):
            return texto
    return None


# ---------------------------------------------------------------------------
# LO QUE SE MIRA DE CADA TERMINAL
# ---------------------------------------------------------------------------

def brokers_del_terminal(carpeta_datos):
    """Nombres de los servidores de broker con los que este terminal trabajo.

    Lista vacia = este terminal NUNCA tuvo cuenta, y entonces el Probador se
    niega a arrancar. Es la comprobacion que mas fallos silenciosos evita.
    """
    bases = _hija(carpeta_datos, "bases")
    if not bases:
        return []
    nombres = []
    try:
        for entrada in sorted(os.listdir(bases)):
            if not os.path.isdir(os.path.join(bases, entrada)):
                continue
            if entrada.lower() in BASES_QUE_NO_SON_CUENTA:
                continue
            nombres.append(entrada)
    except OSError:
        return []
    return nombres


def robots_en_graficos(carpeta_datos):
    """Robots (.ex5) pegados a los graficos guardados de este terminal.

    Los .chr son binarios y guardan el nombre del experto unas veces en texto
    de un byte y otras en UTF-16, segun la version que los escribio. Se
    decodifica de las dos formas y se busca en ambas: sale mas barato que
    entender el formato entero, y aqui un falso positivo (avisar de mas) es
    infinitamente preferible a un falso negativo (arrancar un terminal con un
    robot vivo pegado a un grafico).
    """
    charts = None
    mql5 = _hija(carpeta_datos, "MQL5")
    if mql5:
        perfiles = _hija(mql5, "Profiles")
        if perfiles:
            charts = _hija(perfiles, "Charts")
    if not charts:
        return []

    encontrados = []
    vistos = set()
    try:
        perfiles = sorted(os.listdir(charts))
    except OSError:
        return []
    for perfil in perfiles:
        carpeta = os.path.join(charts, perfil)
        if not os.path.isdir(carpeta):
            continue
        try:
            ficheros = sorted(os.listdir(carpeta))
        except OSError:
            continue
        for fichero in ficheros:
            if not fichero.lower().endswith(".chr"):
                continue
            try:
                with open(os.path.join(carpeta, fichero), "rb") as fh:
                    bruto = fh.read(MAX_BYTES_CHR)
            except OSError:
                continue
            candidatos = set()
            candidatos.update(RE_EX5.findall(bruto.decode("latin-1", "ignore")))
            candidatos.update(RE_EX5.findall(bruto.decode("utf-16-le", "ignore")))
            for nombre in candidatos:
                limpio = nombre.strip()
                clave = limpio.lower()
                if len(limpio) < 5 or clave in vistos:
                    continue
                vistos.add(clave)
                encontrados.append("%s (perfil %s)" % (limpio, perfil))
    return encontrados


def _fecha_de_uso(carpeta_datos, exe):
    """Cuando se toco este terminal por ultima vez.

    Se mira lo que MetaTrader escribe al usarlo (logs, bases, config), no solo
    la carpeta raiz: la raiz puede llevar anos sin cambiar mientras el terminal
    se usa a diario.
    """
    marcas = [_momento(carpeta_datos)]
    for nombre in ("logs", "bases", "config", "Tester"):
        hija = _hija(carpeta_datos, nombre)
        if hija:
            marcas.append(_momento(hija))
    if exe:
        marcas.append(_momento(exe))
    return max(marcas) if marcas else 0.0


def examina(carpeta_datos, exe=None, portable=False, etiqueta=None):
    """Mira un terminal concreto y devuelve su ficha completa.

    Devuelve None si la carpeta no tiene pinta de ser un terminal MetaTrader 5
    (por ejemplo si es un MetaTrader 4, que tiene MQL4 y no MQL5).
    """
    carpeta_datos = os.path.abspath(carpeta_datos)
    mql5 = _hija(carpeta_datos, "MQL5")
    if not mql5:
        return None

    avisos = []
    experts = _hija(mql5, "Experts")
    files = _hija(mql5, "Files")

    # 1. Carpetas de trabajo y escritura real.
    escribible = True
    if not experts:
        avisos.append("Falta la carpeta MQL5\\Experts. Abre el terminal una vez "
                      "para que la cree.")
        escribible = False
    elif not probar_escritura(experts):
        avisos.append("No puedo escribir en %s. Sin eso no puedo dejar ahi el "
                      "robot de la fabrica." % experts)
        escribible = False
    if not files:
        avisos.append("Falta la carpeta MQL5\\Files. Abre el terminal una vez "
                      "para que la cree.")
        escribible = False
    elif not probar_escritura(files):
        avisos.append("No puedo escribir en %s." % files)
        escribible = False

    # 2. El ejecutable.
    if not exe:
        exe = os.path.join(carpeta_datos, "terminal64.exe")
    exe = os.path.abspath(exe)
    hay_exe = os.path.isfile(exe)
    if not hay_exe:
        avisos.append("No encuentro terminal64.exe donde deberia estar (%s). "
                      "Puede que hayas movido o desinstalado el terminal." % exe)

    instalacion = os.path.dirname(exe)
    editor = os.path.join(instalacion, "MetaEditor64.exe")
    if not os.path.isfile(editor):
        editor = None
        avisos.append("No encuentro MetaEditor64.exe junto al terminal: no podre "
                      "compilar el robot yo solo; tendras que compilarlo a mano "
                      "desde el propio MetaEditor.")

    # 3. La cuenta. Sin cuenta el Probador ni arranca.
    brokers = brokers_del_terminal(carpeta_datos)
    if not brokers:
        avisos.append(
            "ESTE TERMINAL NO TIENE NINGUNA CUENTA ABIERTA. El Probador de "
            "MetaTrader se niega a funcionar asi: falla con 'tester not started "
            "because the account is not specified' y no deja ni informe ni "
            "explicacion. Abre el terminal, entra en Archivo > Abrir una cuenta "
            "y abre una cuenta DEMO (es gratis y no hace falta dinero), cierra "
            "el terminal y vuelve a ejecutar esto.")

    # 4. Robots pegados a los graficos. La leccion cara.
    ea = robots_en_graficos(carpeta_datos)
    if ea:
        avisos.append(
            "!! CUIDADO: este terminal tiene %d robot(s) adjunto(s) a sus "
            "graficos (%s). Un robot adjunto se ACTIVA SOLO al abrir el "
            "terminal y puede COLOCAR ORDENES en la cuenta. La fabrica lo "
            "arranca siempre con el trading automatico DESACTIVADO "
            "(AllowLiveTrading=0), asi que no operara mientras lo maneje ella; "
            "pero si abres tu ese terminal a mano, quitale antes el robot al "
            "grafico."
            % (len(ea), ", ".join(ea)))

    if etiqueta is None:
        limpia = instalacion.rstrip("\\/")
        etiqueta = os.path.basename(limpia) or limpia
        if portable:
            # Las carpetas portables suelen llamarse "MT5" a secas, y con ese
            # nombre no se distinguen dos. Se anade la carpeta de arriba.
            padre = os.path.basename(os.path.dirname(limpia))
            if padre:
                etiqueta = "%s\\%s" % (padre, etiqueta)
            etiqueta += " [portable]"
        if brokers:
            etiqueta += " - " + ", ".join(brokers[:2])

    apto = bool(hay_exe and escribible and brokers)

    return {
        "datos": carpeta_datos,
        "exe": exe,
        "editor": editor,
        "nombre": etiqueta,
        "portable": bool(portable),
        "brokers": brokers,
        "ea_en_graficos": ea,
        "escribible": escribible,
        "modificado": _fecha_de_uso(carpeta_datos, exe if hay_exe else None),
        "avisos": avisos,
        "apto": apto,
    }


# ---------------------------------------------------------------------------
# BUSQUEDA 1: INSTALACIONES NORMALES (%APPDATA%\MetaQuotes\Terminal)
# ---------------------------------------------------------------------------

def carpeta_metaquotes():
    """La carpeta donde MetaTrader guarda los datos de todos los terminales."""
    appdata = os.environ.get("APPDATA")
    if not appdata:
        perfil = os.environ.get("USERPROFILE")
        if not perfil:
            return None
        appdata = os.path.join(perfil, "AppData", "Roaming")
    ruta = os.path.join(appdata, "MetaQuotes", "Terminal")
    return ruta if os.path.isdir(ruta) else None


def _busca_normales():
    """Terminales instalados de la forma habitual."""
    raiz = carpeta_metaquotes()
    if not raiz:
        return []
    salida = []
    try:
        entradas = sorted(os.listdir(raiz))
    except OSError:
        return []
    for entrada in entradas:
        if entrada.lower() in NO_SON_TERMINALES:
            continue
        if not RE_CARPETA_DATOS.match(entrada):
            continue
        datos = os.path.join(raiz, entrada)
        if not os.path.isdir(datos):
            continue
        # La prueba de que es un terminal MT5 de verdad y no un MT4 (que tiene
        # MQL4) ni el resto vacio de un portable (que solo deja logs y config).
        mql5 = _hija(datos, "MQL5")
        if not mql5 or not _hija(mql5, "Experts"):
            continue
        instalacion = _lee_origin(datos)
        exe = os.path.join(instalacion, "terminal64.exe") if instalacion else None
        ficha = examina(datos, exe=exe, portable=False)
        if ficha:
            salida.append(ficha)
    return salida


# ---------------------------------------------------------------------------
# BUSQUEDA 2: INSTALACIONES PORTABLES (rastreo de discos, con reloj)
# ---------------------------------------------------------------------------

def unidades_fijas():
    """Letras de las unidades de disco fijas (ni CD, ni red, ni USB).

    Se pregunta a Windows por ctypes. Si no se puede (otro sistema, API
    capada), se cae a lo unico seguro: la unidad donde vive este fichero.
    """
    try:
        import ctypes
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        mascara = kernel32.GetLogicalDrives()
        letras = []
        for indice, letra in enumerate(string.ascii_uppercase):
            if not (mascara >> indice) & 1:
                continue
            raiz = "%s:\\" % letra
            # 3 = DRIVE_FIXED. Los demas (extraibles, red, CD) no se rastrean:
            # tardan una eternidad o ni estan.
            if kernel32.GetDriveTypeW(raiz) == 3:
                letras.append(raiz)
        if letras:
            return letras
    except Exception:
        pass
    unidad = os.path.splitdrive(os.path.abspath(__file__))[0]
    return [unidad + "\\"] if unidad else []


def _raices_de_rastreo():
    """Por donde se empieza a buscar instalaciones portables."""
    raices = []
    for variable in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432"):
        valor = os.environ.get(variable)
        if valor and os.path.isdir(valor):
            raices.append(valor)
    raices.extend(unidades_fijas())
    # Sin repetir, respetando el orden: Program Files primero porque es donde
    # mas probable es encontrar algo, y el reloj corre.
    limpias, vistas = [], set()
    for raiz in raices:
        clave = _normal(raiz)
        if clave and clave not in vistas and os.path.isdir(raiz):
            vistas.add(clave)
            limpias.append(raiz)
    return limpias


def es_carpeta_portable(carpeta):
    """True si esa carpeta es una instalacion portable de MetaTrader 5.

    La firma es terminal64.exe y MQL5\\ en el mismo sitio. Ojo: una instalacion
    NORMAL tiene terminal64.exe pero NO tiene MQL5 al lado (sus datos viven en
    %APPDATA%), asi que esta prueba no las confunde.
    """
    try:
        if not os.path.isfile(os.path.join(carpeta, "terminal64.exe")):
            return False
    except OSError:
        return False
    return _hija(carpeta, "MQL5") is not None


def _busca_portables(segundos_max, instalaciones_ya_vistas):
    """Rastrea los discos buscando carpetas portables, con tope de tiempo.

    El tope no es pereza: hay maquinas con discos de varios TB y miles de
    carpetas, y la fabrica tiene que arrancar en segundos, no en minutos. Si se
    agota el tiempo se devuelve lo encontrado hasta ese momento y se sigue.
    """
    limite = time.time() + max(1.0, float(segundos_max))
    salida = []
    ya = set(instalaciones_ya_vistas)

    for raiz in _raices_de_rastreo():
        pila = [(raiz, 0)]
        while pila:
            if time.time() > limite:
                return salida, True  # se acabo el tiempo
            carpeta, nivel = pila.pop()
            if es_carpeta_portable(carpeta):
                clave = _normal(carpeta)
                if clave not in ya:
                    ya.add(clave)
                    ficha = examina(carpeta, portable=True)
                    if ficha:
                        salida.append(ficha)
                continue  # dentro de un terminal no hay otro terminal
            if nivel >= NIVELES:
                continue
            try:
                with os.scandir(carpeta) as entradas:
                    for entrada in entradas:
                        nombre = entrada.name
                        if nombre.startswith(".") or nombre.lower() in NO_ENTRAR:
                            continue
                        try:
                            # follow_symlinks=False evita bucles infinitos por
                            # enlaces simbolicos que apuntan hacia arriba.
                            if not entrada.is_dir(follow_symlinks=False):
                                continue
                        except OSError:
                            continue
                        pila.append((entrada.path, nivel + 1))
            except (OSError, PermissionError):
                continue  # carpeta protegida: ni caso, seguimos
    return salida, False


# ---------------------------------------------------------------------------
# LA BUSQUEDA COMPLETA
# ---------------------------------------------------------------------------

# Notas de la ultima busqueda, para que main() pueda avisar de si el rastreo de
# portables se quedo a medias por el tope de tiempo. No es estado importante:
# si nadie lo mira, no pasa nada.
ULTIMA_BUSQUEDA = {"tiempo_agotado": False}


def _orden(ficha):
    """Clave de ordenacion: primero lo que mas tranquilo deja al usuario.

    Grupo 0: apto y sin robots pegados a los graficos.
    Grupo 1: apto pero con algun robot pegado (usable, pero hay que avisar).
    Grupo 2: no apto.
    Dentro de cada grupo, el usado mas recientemente primero: casi siempre es
    el terminal que la persona considera "el suyo".
    """
    if not ficha["apto"]:
        grupo = 2
    elif ficha["ea_en_graficos"]:
        grupo = 1
    else:
        grupo = 0
    return (grupo, -ficha["modificado"])


def buscar_terminales(segundos_max=SEGUNDOS_BUSQUEDA, incluir_portables=True):
    """Todas las instalaciones de MetaTrader 5 de esta maquina.

    Devuelve una lista de fichas ordenada de MEJOR a PEOR candidato. Nunca
    lanza: si algo no se puede mirar, se omite y se sigue.
    """
    fichas = _busca_normales()

    # Las carpetas de instalacion de los terminales normales ya estan
    # cubiertas: si el rastreo de portables las volviera a encontrar, saldria
    # el mismo terminal dos veces y con la carpeta de datos equivocada.
    vistas = set()
    for ficha in fichas:
        vistas.add(_normal(os.path.dirname(ficha["exe"])))
        vistas.add(_normal(ficha["datos"]))

    ULTIMA_BUSQUEDA["tiempo_agotado"] = False
    if incluir_portables:
        portables, se_acabo_el_tiempo = _busca_portables(segundos_max, vistas)
        fichas.extend(portables)
        ULTIMA_BUSQUEDA["tiempo_agotado"] = se_acabo_el_tiempo

    # Nunca dos veces el mismo terminal, aunque se llegara a el por dos vias.
    unicas, claves = [], set()
    for ficha in fichas:
        clave = _normal(ficha["datos"])
        if clave in claves:
            continue
        claves.add(clave)
        unicas.append(ficha)

    unicas.sort(key=_orden)
    return unicas


def examina_ruta(ruta):
    """Ficha de un terminal a partir de una ruta dada a mano por el usuario.

    Se acepta lo que la persona tenga a mano, que no tiene por que ser lo que
    el programa considera "la carpeta buena":
      - la carpeta de DATOS de un terminal normal (la del hash de 32 letras),
      - la carpeta de una instalacion PORTABLE,
      - o la carpeta donde esta instalado un terminal normal, en cuyo caso se
        busca a que carpeta de datos corresponde.
    Devuelve None si ahi no hay ningun MetaTrader 5.
    """
    if not ruta:
        return None
    ruta = os.path.abspath(os.path.expandvars(os.path.expanduser(str(ruta).strip().strip('"'))))
    if not os.path.isdir(ruta):
        return None

    # Caso portable: el programa y los datos, juntos.
    if es_carpeta_portable(ruta):
        return examina(ruta, portable=True)

    # Caso carpeta de datos de un terminal normal.
    mql5 = _hija(ruta, "MQL5")
    if mql5 and _hija(mql5, "Experts"):
        instalacion = _lee_origin(ruta)
        exe = os.path.join(instalacion, "terminal64.exe") if instalacion else None
        return examina(ruta, exe=exe, portable=False)

    # Caso carpeta de INSTALACION de un terminal normal: sus datos viven en
    # %APPDATA%, asi que hay que buscar cual de las carpetas de alla apunta
    # aqui con su origin.txt.
    if os.path.isfile(os.path.join(ruta, "terminal64.exe")):
        buscada = _normal(ruta)
        for ficha in _busca_normales():
            if _normal(os.path.dirname(ficha["exe"])) == buscada:
                return ficha
    return None


def elegir_terminal(preferida=None, terminales=None):
    """El terminal que la fabrica va a usar, o None si no hay ninguno servible.

    Si se da 'preferida', manda la persona: se devuelve ESE terminal aunque no
    sea apto, con sus avisos dentro, para que quien llama decida y pueda
    explicar el motivo exacto. Sin 'preferida', se coge el mejor de la lista, y
    solo si es apto: arrancar con un terminal sin cuenta seria condenar al
    usuario a un fallo incomprensible media hora despues.
    """
    if preferida:
        ficha = examina_ruta(preferida)
        if ficha is not None:
            return ficha
        return None
    lista = terminales if terminales is not None else buscar_terminales()
    for ficha in lista:
        if ficha["apto"]:
            return ficha
    return None


# ---------------------------------------------------------------------------
# LO QUE USAN LOS DEMAS PROGRAMAS DE LA FABRICA
# ---------------------------------------------------------------------------
# Los tres programas de la fabrica (servidor, generar_barridos y verificar)
# resuelven el terminal igual: primero lo que diga el usuario por la linea de
# comandos, luego la variable de entorno, y si no, lo que se encuentre solo.
# La regla vive aqui para que no haya tres versiones de la misma regla.

VARIABLE_ENTORNO = "FABRICA_MT5"
VARIABLE_FORZAR = "FABRICA_MT5_FORZAR"


def anade_argumento_terminal(analizador):
    """Anade --terminal a un ArgumentParser, con la misma ayuda en todos."""
    analizador.add_argument(
        "--terminal", default=None, metavar="RUTA",
        help="Carpeta del MetaTrader 5 que hay que usar (la de datos o la de "
             "instalacion). Si no se indica, se busca solo. Tambien se puede "
             "poner en la variable de entorno %s." % VARIABLE_ENTORNO)
    return analizador


def preferencia_del_entorno():
    """Ruta indicada en la variable de entorno, si la hay."""
    valor = (os.environ.get(VARIABLE_ENTORNO) or "").strip().strip('"')
    return valor or None


def _texto_de_avisos(ficha):
    return "\n".join("  - %s" % _parrafo(aviso, ancho=66, sangria="    ")
                     for aviso in ficha["avisos"])


TEXTO_SIN_TERMINAL = """
No he encontrado ningun MetaTrader 5 que pueda usar en este ordenador.

La fabrica necesita DOS cosas, y las dos en ESTE MISMO ordenador:

  1. MetaTrader 5 instalado. Te lo da tu broker, o lo bajas gratis de
     www.metatrader5.com.
  2. Una cuenta ya abierta dentro del terminal. Vale una cuenta DEMO
     gratuita: sin dinero y sin compromiso. Sin cuenta, el Probador de
     MetaTrader ni arranca; falla con "tester not started because the
     account is not specified" y no explica nada mas.

Que hacer, paso a paso:
  a) Abre MetaTrader 5.
  b) Menu Archivo > Abrir una cuenta, y abre una cuenta demo.
  c) Cierra MetaTrader 5.
  d) Vuelve a ejecutar esto.

Esto NO funciona en remoto: el programa tiene que correr en el mismo
ordenador donde este instalado el terminal.

Si tienes el terminal en un sitio raro y no lo encuentro, dime donde esta:
    --terminal "C:\\ruta\\de\\tu\\MetaTrader"
o deja esa ruta en la variable de entorno %s.
Para ver que ha encontrado el detector:  python detectar_mt5.py
""" % VARIABLE_ENTORNO


def exige_terminal(preferida=None, imprimir=True):
    """Devuelve la ficha del terminal a usar, o para el programa explicandolo.

    Es la puerta de entrada de todos los programas de la fabrica. Si no hay
    nada servible corta con SystemExit y un mensaje que explica QUE falta y
    QUE hacer: quedarse a medias con un error tecnico seria dejar tirado a
    quien acaba de descargar esto.
    """
    a_mano = preferida or preferencia_del_entorno()

    if a_mano:
        ficha = examina_ruta(a_mano)
        if ficha is None:
            raise SystemExit(
                "\nEn esa carpeta no hay ningun MetaTrader 5:\n    %s\n\n"
                "Dame la carpeta de DATOS del terminal (la que tiene dentro\n"
                "MQL5) o la carpeta donde esta terminal64.exe.\n"
                "Para ver los que si he encontrado:  python detectar_mt5.py\n"
                % a_mano)
        if not ficha["apto"] and not os.environ.get(VARIABLE_FORZAR):
            raise SystemExit(
                "\nEse terminal no sirve tal y como esta:\n    %s\n\n%s\n\n"
                "Arregla lo de arriba, o elige otro con --terminal.\n"
                "Si estas seguro de que me equivoco, pon la variable de\n"
                "entorno %s=1 y lo intentare igualmente.\n"
                % (ficha["datos"], _texto_de_avisos(ficha), VARIABLE_FORZAR))
    else:
        if imprimir:
            print("Buscando MetaTrader 5 en este ordenador...")
        ficha = elegir_terminal()
        if ficha is None:
            raise SystemExit(TEXTO_SIN_TERMINAL)

    if imprimir:
        print("Terminal elegido : %s" % ficha["nombre"])
        print("Carpeta de datos : %s" % ficha["datos"])
        if ficha["ea_en_graficos"]:
            print("")
            print("  !! Ese terminal tiene %d robot(s) pegados a sus graficos."
                  % len(ficha["ea_en_graficos"]))
            print("     Se arrancara con el trading automatico DESACTIVADO,")
            print("     asi que no operara. Los robots son:")
            for nombre in ficha["ea_en_graficos"]:
                print("       %s" % nombre)
            print("")
        elif not ficha["apto"]:
            print("  !! Este terminal tiene problemas; sigo porque me lo has")
            print("     mandado con %s." % VARIABLE_FORZAR)
    return ficha


def carpeta_sets(ficha):
    """Donde MetaTrader espera los .set del Probador, para un terminal dado."""
    return os.path.join(ficha["datos"], "MQL5", "Profiles", "Tester")


def carpeta_experts(ficha):
    """Donde va el robot compilado, para un terminal dado."""
    return os.path.join(ficha["datos"], "MQL5", "Experts")


# ---------------------------------------------------------------------------
# MODO PROGRAMA: LA TABLA POR PANTALLA
# ---------------------------------------------------------------------------

def _fecha_legible(marca):
    if not marca:
        return "desconocida"
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(marca))


def _modo_para_bat(argv):
    """Salida para EMPEZAR.bat: lineas CLAVE=VALOR que el .bat lee con 'set'.

    Un .bat no sabe leer JSON, pero sabe hacer 'set FABRICA_DATOS=...' con
    cada linea que le demos. Si no hay terminal servible, exige_terminal corta
    con SystemExit: el mensaje para el usuario sale por la salida de errores
    (que el .bat deja pasar a la pantalla tal cual) y aqui no se imprime nada,
    que es como el .bat se entera de que la cosa fue mal.
    """
    preferida = None
    if "--terminal" in argv:
        posicion = argv.index("--terminal")
        if posicion + 1 < len(argv):
            preferida = argv[posicion + 1]
    ficha = exige_terminal(preferida, imprimir=False)
    print("FABRICA_NOMBRE=%s" % ficha["nombre"])
    print("FABRICA_DATOS=%s" % ficha["datos"])
    print("FABRICA_EXE=%s" % ficha["exe"])
    print("FABRICA_EDITOR=%s" % (ficha["editor"] or ""))
    print("FABRICA_PORTABLE=%d" % (1 if ficha["portable"] else 0))
    print("FABRICA_CUENTAS=%s" % ", ".join(ficha["brokers"]))
    print("FABRICA_ROBOTS=%d" % len(ficha["ea_en_graficos"]))
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--para-bat" in argv:
        return _modo_para_bat(argv)
    a_mano = argv[0] if argv and not argv[0].startswith("-") else None

    print("=" * 72)
    print(" METATRADER 5 EN ESTE ORDENADOR")
    print("=" * 72)

    if a_mano:
        print(" Mirando la ruta que me has dado: %s" % a_mano)
        ficha = examina_ruta(a_mano)
        terminales = [ficha] if ficha else []
        if not ficha:
            print("\n En esa carpeta no hay ningun MetaTrader 5.")
            print(" Dame la carpeta de datos del terminal (la que tiene dentro")
            print(" MQL5) o la carpeta donde esta instalado terminal64.exe.")
            return 1
    else:
        print(" Buscando... (los portables se rastrean por disco; hasta %d s)"
              % int(SEGUNDOS_BUSQUEDA))
        inicio = time.time()
        terminales = buscar_terminales()
        print(" Busqueda terminada en %.1f segundos." % (time.time() - inicio))
        if ULTIMA_BUSQUEDA.get("tiempo_agotado"):
            print(" (El rastreo de portables se corto por tiempo. Si el tuyo no")
            print("  aparece, pasame su carpeta: python detectar_mt5.py RUTA)")

    if not terminales:
        print("")
        print(" No he encontrado ningun MetaTrader 5 instalado.")
        print("")
        print(" La fabrica necesita MetaTrader 5 instalado EN ESTE MISMO")
        print(" ORDENADOR y con una cuenta abierta (vale una demo gratuita).")
        print(" Descargalo de tu broker o de www.metatrader5.com, abrelo una")
        print(" vez, abre una cuenta demo, cierralo y vuelve a ejecutar esto.")
        print("=" * 72)
        return 1

    aptos = [t for t in terminales if t["apto"]]
    print(" Encontrados: %d (aptos para la fabrica: %d)"
          % (len(terminales), len(aptos)))
    print("")

    for numero, t in enumerate(terminales, 1):
        estado = "APTO" if t["apto"] else "NO APTO"
        if t["apto"] and t["ea_en_graficos"]:
            estado = "APTO (con robots en los graficos)"
        print(" [%d] %s" % (numero, t["nombre"]))
        print("     Estado    : %s" % estado)
        print("     Datos     : %s" % t["datos"])
        print("     Programa  : %s" % t["exe"])
        print("     MetaEditor: %s" % (t["editor"] or "no encontrado"))
        print("     Portable  : %s" % ("si (se lanza con /portable)" if t["portable"] else "no"))
        print("     Cuentas   : %s" % (", ".join(t["brokers"]) if t["brokers"]
                                       else "NINGUNA"))
        print("     Escribible: %s" % ("si" if t["escribible"] else "NO"))
        print("     Usado el  : %s" % _fecha_legible(t["modificado"]))
        if t["ea_en_graficos"]:
            print("     Robots    : %s" % ", ".join(t["ea_en_graficos"]))
        if t["avisos"]:
            print("     Avisos:")
            for aviso in t["avisos"]:
                print("       - %s" % _parrafo(aviso))
        print("")

    elegido = elegir_terminal(terminales=terminales)
    print("-" * 72)
    if elegido:
        print(" La fabrica usaria: %s" % elegido["nombre"])
        print(" Carpeta de datos : %s" % elegido["datos"])
        if elegido["ea_en_graficos"]:
            print(" OJO: ese terminal tiene robots pegados a sus graficos. Se")
            print("      arrancara con el trading automatico DESACTIVADO.")
        print("")
        print(" Si prefieres otro, arranca con:  --terminal \"RUTA\"")
        print(" o pon la variable de entorno FABRICA_MT5 con esa ruta.")
    else:
        print(" Ninguno de los terminales encontrados sirve para la fabrica.")
        print("")
        print(" Lo mas habitual es que el terminal no tenga cuenta. Abrelo,")
        print(" entra en Archivo > Abrir una cuenta, abre una cuenta DEMO (es")
        print(" gratis), cierra el terminal y vuelve a ejecutar esto.")
    print("=" * 72)
    return 0 if elegido else 1


if __name__ == "__main__":
    sys.exit(main())
