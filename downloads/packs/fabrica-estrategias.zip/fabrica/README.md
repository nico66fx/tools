# Fábrica de estrategias para MetaTrader 5 — documentación técnica

> **Esto genera candidatos, no estrategias ganadoras.** Probar miles de combinaciones sobre
> los mismos datos hace que algunas parezcan buenas por pura casualidad. El tramo reservado
> reduce ese riesgo, no lo elimina. Nada de lo que salga aquí está listo para dinero real sin
> pasar antes por una cuenta demo.

Un robot-plantilla cuyas reglas son parámetros, el optimizador genético de MetaTrader como
motor de búsqueda, un juez de robustez que descarta lo que no aguanta, y un panel para mirar
los resultados.

Si solo quieres usarlo, lee `LEEME.md` y haz doble clic en `EMPEZAR.bat`. Este documento es
para quien quiera saber **qué decide cada cosa y por qué**, o repetir el proceso a mano.

---

## 1. Con qué se probó

| | |
|---|---|
| **Terminal** | Una instalación **portable** de MetaTrader 5 (los datos viven en la propia carpeta). **La ruta ya no está clavada en el código: el kit la detecta solo** |
| **Versión** | MetaTrader 5 x64 **build 6193** |
| **Servidor** | MetaQuotes-Demo (cuenta demo) |
| **Símbolo / marco** | EURUSD, H1 |
| **Periodo** | 2018.01.01 – 2025.12.31, con el 25 % final reservado |
| **Histórico disponible** | EURUSD desde **2016.12.22** — cubre de sobra el periodo pedido |
| **Máquina** | 8 núcleos, 8 agentes locales del Probador |

Una instalación portable se lanza siempre con `/portable`. Es obligatorio: sin esa opción el
terminal usaría la carpeta de datos de `%APPDATA%` y no encontraría nada de esto. En una
instalación normal ocurre justo al revés. El detector distingue los dos casos; por eso no hay
ninguna ruta de disco escrita a mano en los ficheros del kit.

### Cómo elegir el terminal (y cuáles descartar)

En la máquina de pruebas había nueve carpetas de datos de MetaTrader. Los criterios que se
usaron sirven para cualquiera:

- **Terminales en ejecución: no se tocan.** Lanzar una optimización con `ShutdownTerminal=1`
  sobre uno de ellos lo habría cerrado, y cualquiera de ellos podía tener posiciones abiertas.
- **Terminales que nunca se conectaron a un bróker: no sirven.** Su propio log muestra el fallo
  típico: `tester not started because the account is not specified`. El Probador exige cuenta.
- **Terminales con un robot adjunto a un gráfico: peligrosos.** Arrancarlos lo pone en marcha.
  Ver la sección 7, que cuenta lo que pasa cuando no se comprueba.
- **Terminales con poco histórico: inútiles para el periodo que pides.** Uno de los descartados
  solo servía EURUSD desde finales de 2022.

El elegido fue el que cumplía las cuatro condiciones: portable, parado, **sin ningún robot
adjunto a sus gráficos** (comprobado leyendo los ficheros `.chr` de todos sus perfiles antes de
arrancarlo) y con histórico de EURUSD desde 2016.

---

## 2. Los genes de la plantilla

`FabricaEA.mq5` no implementa *una* estrategia: implementa un **espacio** de estrategias.
Ninguna regla está escrita a fuego; todas son `input`, y cada combinación de valores es una
estrategia distinta.

| Gen | Qué decide |
|---|---|
| `InpSenal` | La señal de entrada: `0` cruce de medias · `1` RSI en umbral · `2` ruptura del rango de N velas · `3` cruce de banda de Bollinger · `4` momento simple |
| `InpPeriodoA` | Periodo principal: media rápida, periodo del RSI, N velas de la ruptura, periodo de Bollinger o del momento |
| `InpPeriodoB` | Media lenta. **Solo lo usa el cruce de medias** |
| `InpUmbral` | Nivel del RSI (5–45), desviaciones de Bollinger (0,5–4,0) o % de momento (0,01–2,0) |
| `InpDireccion` | `0` ambas · `1` solo largos · `2` solo cortos |
| `InpFiltroTend` | `0` ninguno · `1` a favor (largos exigen cierre > media) · `2` en contra |
| `InpPeriodoTend` | Periodo de la media del filtro de tendencia |
| `InpHoraInicio` / `InpHoraFin` | Ventana horaria operativa, ambas inclusive |
| `InpATRPeriodo` | Periodo del ATR que dimensiona stop y objetivo |
| `InpMultSL` / `InpMultTP` | Stop y objetivo en múltiplos de ATR |
| `InpSalidaContraria` | Cerrar también cuando aparece la señal opuesta |
| `InpRiesgoPct` | % del saldo arriesgado por operación, sobre la distancia al stop. **No es un gen**: es configuración fija |
| `InpMagico` | Número mágico. Tampoco es un gen |

### Reglas de la casa (invariantes, no parametrizables)

- Una sola posición abierta a la vez.
- **Nada de martingala, rejillas ni promediar pérdidas.** Aunque mejorase la puntuación.
- Se decide **en el cierre de vela**, sobre barras ya cerradas (índices 1 y 2, nunca la 0 en
  formación). Así no hay sesgo de anticipación.
- Se consultan `SYMBOL_TRADE_STOPS_LEVEL` y `SYMBOL_TRADE_FREEZE_LEVEL`, y se normalizan
  precios y volúmenes antes de enviar la orden.
- Las posiciones se filtran siempre por símbolo **y** número mágico.
- El valor del tick se lee **vivo** en cada cálculo de volumen, no cacheado al arrancar: en
  símbolos cuya divisa de beneficio no es la de la cuenta, cachearlo desvía el riesgo real de
  forma sistemática durante todo el backtest.

### Combinaciones que se rechazan sin gastar pasada

`OnInit` devuelve `INIT_PARAMETERS_INCORRECT` y el optimizador las descarta al instante. En el
log se ve así: `"incorrect input parameters" in 0:00:00.000`. Se rechazan:

- Ventana horaria vacía o fuera de 0–23; periodos menores que 2; cruce de medias con la rápida
  igual o más lenta que la lenta; multiplicadores o riesgo no positivos; umbral fuera del rango
  propio de la señal elegida; número mágico 0.
- **Genes inertes fuera de su valor canónico.** Esto importa: `InpPeriodoB` solo lo usa el cruce
  de medias, `InpUmbral` no lo usan ni el cruce de medias ni la ruptura, y `InpPeriodoTend` solo
  se usa si hay filtro de tendencia. Dos combinaciones que difieren solo en un gen inerte son
  **la misma estrategia**, y el optimizador gastaría una pasada en cada clon. Obligando a esos
  genes a un valor canónico (`20`, `0,5` y `50`), el espacio de búsqueda válido baja de
  **75.841.920.000 a 3.489.992.352** combinaciones — **21,7 veces menos**, sin perder ni una
  estrategia distinta.

Si cambias los rangos de un `.set`, esos tres valores canónicos **tienen que seguir dentro del
rango barrido**, o esas ramas se quedarán sin pasadas.

---

## 3. Qué penaliza el juez, y con qué umbrales

`JuezRobustez.mqh` expone `PuntuacionRobustez()`, que `OnTester()` devuelve. **La puntuación no
es el beneficio.** Parte del factor de beneficio (base = `PF − 1`, así un PF de 1,00 puntúa 0) y
la multiplica por cinco factores de penalización, cada uno entre 0 y 1.

| Penalización | Umbral | Qué castiga y por qué |
|---|---|---|
| **Pocas operaciones** | `MIN_OPS_ABSOLUTO = 100`<br>`MIN_OPS_COMODO = 250` | Por debajo de 100 cierres la puntuación es **cero**: una muestra así es anécdota, no evidencia. Entre 100 y 250 el factor sube linealmente de 0,3 a 1,0 |
| **Caída frente a beneficio** | `MAX_DD_SOBRE_BENEFICIO = 0,50` | Si la caída máxima supera la mitad del beneficio neto, el factor decae. Una curva que arriesga más de lo que gana no la aguanta nadie en real |
| **Dependencia de la mejor operación** | `MAX_PESO_MEJOR_OP = 0,25`<br>letal en `0,50` | Si la mejor operación aporta más del 25 % del beneficio bruto, el factor cae **al cuadrado**. Si aporta más de la mitad, cero: eso no es un sistema, es un golpe de suerte |
| **Meses desiguales** | `MIN_MESES_POSITIVOS = 0,55`<br>`MIN_MESES_ACTIVOS = 6` | Proporción de meses cerrados en positivo sobre los meses que **abarca** la pasada, huecos incluidos. Así un sistema que solo funcionó en un tramo concreto queda penalizado |
| **Rachas en contra** | `MARGEN_RACHA = 1,5` | Racha perdedora esperada ≈ `log(N) / −log(1−p)` para su porcentaje de acierto `p`. Si la observada supera 1,5 veces la esperada, penaliza |

Además devuelve **cero** de plano si: hay menos de 100 operaciones, el beneficio neto no es
positivo, el factor de beneficio no llega a `MIN_PF_ABSOLUTO = 1,05`, la pasada abarca menos de
6 meses, o la mejor operación pasa del 50 %. Esas combinaciones desaparecen de la búsqueda.

Casos degenerados protegidos: factor de beneficio infinito cuando no hay pérdidas (se topa en
`PF_TOPE_DEGENERADO = 10`), `p = 0` y `p = 1` en el cálculo de rachas, divisiones por cero y
`NaN`. La función devuelve **siempre** un número finito y no negativo.

En un test individual (no durante la optimización) imprime el desglose completo y una línea
`JUEZ|...` con todos los valores separados por `;`, para poder auditar por qué una combinación
puntuó lo que puntuó.

---

## 4. Las puertas de calidad del lector

`lector.py` aplica, sobre cada candidato del XML, unas puertas **independientes** del juez.
Están al principio del fichero, en el diccionario `PUERTAS`, y son fáciles de relajar:

| Puerta | Valor |
|---|---|
| `MIN_OPERACIONES` | 100 |
| `MIN_PUNTUACION` | 0,05 |
| `MAX_CAIDA_SOBRE_BENEFICIO` | 0,50 |
| `MAX_PESO_MEJOR_OPERACION` | 0,25 *(solo si el XML trae el dato)* |
| `MIN_MESES_POSITIVOS` | 0,55 *(solo si el XML trae el dato)* |
| `FORWARD_MINIMO` | 0,0 |
| `FORWARD_RATIO_MINIMO` | 0,35 |

Cada candidato lleva `apta: true/false` y una lista `motivos` con **todas** las puertas que no
superó, no solo la primera.

**La puerta decisiva es la del forward**: el tramo reservado tiene que quedar en positivo y su
puntuación no puede caer por debajo del 35 % de la del tramo de búsqueda. Si no hay dato de
forward, el candidato se marca **no apta** con el motivo «sin tramo reservado que verificar»:
más vale descartar que aprobar a ciegas.

Sobre la caída: el XML da la caída en **porcentaje de fondos** y el beneficio en **dinero**, que
no son comparables. El lector deduce la caída en dinero a partir del **factor de recuperación**,
que MetaTrader define exactamente como `beneficio neto / caída máxima en dinero` — es una
identidad de la plataforma, no una estimación. Si no dispone ni de la caída absoluta ni del
factor de recuperación, la puerta **lo dice** en lugar de fingir que ha comprobado algo.

Las puertas se pueden mover desde la consola, pero conviene recordar para qué están. Bajar el
listón hasta que aparezcan candidatas no fabrica estrategias: deja pasar el ruido que antes se
quedaba fuera.

---

## 5. Cómo repetirlo a mano

Todo esto lo hace `EMPEZAR.bat` por ti. Se documenta para quien quiera ejecutarlo paso a paso,
o entender qué está pasando por debajo.

En los ejemplos, `<carpeta del terminal>` es la carpeta de datos de tu MetaTrader (por ejemplo
`C:\MetaTrader5`); la encuentras en *Archivo → Abrir carpeta de datos*. `<carpeta del kit>` es
donde has descomprimido esto. **El kit las detecta solas**; aquí se escriben porque a mano hay
que ponerlas.

```bash
mkdir "<carpeta del terminal>\MQL5\Experts\Fabrica"
```

```bash
copy FabricaEA.mq5 JuezRobustez.mqh "<carpeta del terminal>\MQL5\Experts\Fabrica\"
```

Compilar (no toca la cuenta ni abre el terminal):

```bash
"<carpeta del terminal>\MetaEditor64.exe" /portable /compile:"<carpeta del terminal>\MQL5\Experts\Fabrica\FabricaEA.mq5" /inc:"<carpeta del terminal>\MQL5" /log:compile.log
```

Generar los `.set` y los `.ini` de los cinco barridos (los copia solo al terminal):

```bash
python generar_barridos.py
```

Lanzar cada barrido; el terminal se cierra solo al acabar:

```bash
"<carpeta del terminal>\terminal64.exe" /portable /config:"<carpeta del kit>\logs\optimizar_s1_rsi.ini"
```

Leer los cinco XML de golpe y aplicar las puertas:

```bash
python lector.py "<carpeta del terminal>\fabrica_s0_cruce.xml" "<carpeta del terminal>\fabrica_s1_rsi.xml" "<carpeta del terminal>\fabrica_s2_ruptura.xml" "<carpeta del terminal>\fabrica_s3_bollinger.xml" "<carpeta del terminal>\fabrica_s4_momento.xml" --salida informes\resultados.json
```

Comprobar que el lector no ha corrompido ningún número:

```bash
python comprobar_lector.py "<carpeta del terminal>\fabrica_s1_rsi.xml" informes\resultados.json
```

Luego abre `panel.html` con doble clic y arrástrale `informes\resultados.json`.

### Por qué cinco barridos y no uno

Un único barrido mixto **no funciona**, y no es una cuestión de gusto. Cada señal usa el gen
`InpUmbral` en una escala distinta (RSI 5–45, Bollinger 0,5–4,0, momento 0,01–2,0) y dos señales
no lo usan en absoluto. Un rango único que las cubra todas hace que casi toda combinación
sorteada sea inválida. Al intentarlo, MetaTrader abortó:

```
503 passes of 512 failed, genetic optimization stopped at generation 0
genetic optimization finished on pass 512 (of 120748320000)
```

El algoritmo genético se rinde cuando casi toda la generación falla. Partiendo el barrido por
señal, cada uno tiene su escala propia, la tasa de combinaciones válidas sube al 40–46 %, y
además ninguna señal le roba el presupuesto de búsqueda a las otras.

### Valores del `.ini` verificados contra la instalación de pruebas

No los des por buenos de memoria; estos se comprobaron contra el build 6193 que había delante:

| Clave | Valor | Cómo se comprobó |
|---|---|---|
| `Optimization` | `2` | genético. El log dice `genetic mode turned off due to N passes` cuando el espacio es pequeño, y `Best result … produced at generation N` cuando actúa |
| `OptimizationCriterion` | `6` | personalizado. Verificado: la columna `Result` del XML coincide con `Custom`, que es lo que devuelve `OnTester()` |
| `Model` | `1` | barras de 1 minuto OHLC |
| `ForwardMode` | `3` | reserva **1/4** final. Verificado en el log: `back test from 2018.01.01 to 2023.12.31 forward test from 2023.12.31 to 2025.12.31` — exactamente el 25 % |
| `Report` | ruta **relativa** | **Importante**: con una ruta absoluta MetaTrader no escribe el informe y **no avisa**. Debe ser relativa a la carpeta de datos del terminal |

`[Experts] AllowLiveTrading=0` no es decorativo: impide que cualquier robot adjunto a un gráfico
opere mientras el terminal está abierto para optimizar. El Probador no se ve afectado, porque
simula en lugar de operar. La sección 7 explica por qué esa línea está ahí.

### Precisión de la puntuación

El XML trae la puntuación **dos veces**: en `Result`, redondeada a dos decimales, y en `Custom`,
completa. Con puntuaciones del orden de 0,09 el redondeo se come casi toda la señal, así que el
lector usa `Custom` siempre que ambas coincidan dentro del margen de ese redondeo.

---

## 6. Qué hay en esta carpeta

| Fichero | Qué es |
|---|---|
| `EMPEZAR.bat` | El arranque de doble clic: detecta el terminal, compila el robot y abre la consola |
| `LEEME.md` | Lo que lee quien descarga esto. Empieza por el aviso |
| `README.md` | Este documento |
| `LICENSE` | Licencia MIT |
| `FabricaEA.mq5` | El robot-plantilla. Compila con 0 errores y 0 avisos |
| `JuezRobustez.mqh` | El juez. `PuntuacionRobustez()` para `OnTester()` |
| `detectar_mt5.py` | Encuentra la instalación de MetaTrader y su carpeta de datos |
| `optimizar.ini` | Configuración de arranque, con los valores verificados y comentados |
| `generar_barridos.py` | Genera los cinco `.set` y los cinco `.ini`, uno por señal |
| `sets/` | Rangos y pasos de cada gen, por señal |
| `logs/` | Los `.ini` generados y los logs de compilación |
| `lector.py` | XML de MetaTrader → `resultados.json`, con las puertas aplicadas |
| `comprobar_lector.py` | Relee el XML con un parser distinto y contrasta cada número, para detectar corrupción silenciosa |
| `verificar.py` | Prepara el test individual de un candidato (Fase 6) |
| `servidor.py` | El motor local: cola de barridos, lanza el terminal, recoge los XML. Solo escucha en `127.0.0.1` |
| `consola.bat` | Arranca el servidor con doble clic |
| `consola.html` | La consola: lanzador, recuento, gráficos y biblioteca |
| `panel.html` | El panel suelto. Un solo fichero, doble clic, sin servidor ni dependencias |
| `empaquetar.py` | Construye el ZIP de distribución y aborta si encuentra datos personales. Es herramienta de quien redistribuye, no va dentro del ZIP |
| `informes/` | XML de MetaTrader y JSON generados |

---

## 7. La incidencia que explica por qué el trading automático arranca apagado

Hay que dejarlo escrito, porque afectó a una cuenta real (demo, pero real).

La comprobación inicial eligió un terminal por ser el de modificación más reciente, sin mirar
qué tenía cargado. Al arrancarlo en modo headless para una prueba de humo, **ese terminal cargó
el robot que tenía adjunto a su gráfico por defecto y colocó una orden en la cuenta demo**.
Nadie había pedido esa orden: arrancar el terminal fue suficiente.

La orden **no se canceló**: tocar órdenes de una cuenta de trading queda fuera de lo que este
kit hace, y sigue quedando fuera.

Qué se cambió a raíz de eso, y sigue vigente:

1. **Comprobar los ficheros `.chr` de todos los perfiles del terminal antes de arrancarlo.** Ahí
   es donde MetaTrader guarda qué robot tiene adjunto cada gráfico. Si hay alguno, se busca otro
   terminal.
2. **`[Experts] AllowLiveTrading=0` en todas las configuraciones de arranque.** Con eso, aunque
   un robot esté adjunto, no opera. El Probador no se ve afectado, porque simula en lugar de
   operar.
3. Todo lo que se había creado en el terminal descartado se eliminó después; sus ficheros
   propios quedaron intactos.

Los logs de todas las ejecuciones posteriores registran **cero operaciones**.

La lección, que vale para cualquiera: **arrancar un terminal de MetaTrader no es una operación
inocua.** Antes de lanzar esto contra un terminal tuyo, comprueba que no tenga robots adjuntos a
sus gráficos, o arráncalo con `AllowLiveTrading=0` desde el principio. El kit hace lo segundo
siempre.

---

## 8. Resultados del barrido

Todas las cifras de esta sección salen de ejecuciones reales. Ninguna está inventada.

**EURUSD H1, 2018.01.01 – 2025.12.31.** Búsqueda sobre 2018.01.01–2023.12.31 y tramo
reservado 2024.01.01–2025.12.31 (el 25 % final), que el optimizador nunca ve.

| Barrido | Combinaciones | Aptas | % |
|---|---:|---:|---:|
| s0_cruce | 6.008 | 29 | 0.48 % |
| s1_rsi | 6.916 | 9 | 0.13 % |
| s2_ruptura | 5.911 | 2 | 0.03 % |
| **TOTAL** | **18.835** | **40** | **0.21 %** |

### El resultado que de verdad importa

Las combinaciones con MEJOR puntuación en el tramo de búsqueda **suspenden casi todas el
tramo reservado**. Ejemplos reales del barrido del RSI:

```
Pasada  Busqueda  Reservado   ¿Apta?
  6610    0.7794     0.0000     NO
  6309    0.7660     0.0000     NO
  6508    0.7499     0.0000     NO
```

Puntuaciones de 0,75-0,78 entre 2018 y 2023 que se desploman a **cero** en 2024-2025.
Eso es sobreoptimización de manual. Quien mire solo el ranking de resultados se lleva
justo las peores. El gráfico de dispersión del panel lo dice con una cifra que calcula
el propio panel: **el 99,8 % de las combinaciones empeora fuera de la muestra**.

### Por qué no pasan

Una misma combinación puede fallar varias puertas, así que no suma cien.

| Motivo | Combinaciones | % de las descartadas |
|---|---:|---:|
| el tramo reservado no es positivo | 14.226 | 75.7 % |
| puntuación de robustez baja | 11.811 | 62.8 % |
| desplome fuera de muestra | 8.908 | 47.4 % |
| el beneficio del tramo de búsqueda no es positivo | 7.263 | 38.6 % |
| caída excesiva frente al beneficio | 6.892 | 36.7 % |
| muestra insuficiente | 6.158 | 32.8 % |
| sin tramo reservado que verificar | 3.527 | 18.8 % |

Tres cuartas partes caen por lo mismo: **el tramo reservado no es positivo**. No es que
los umbrales sean caprichosos; es que casi nada sobrevive fuera de muestra.

### Las mejores supervivientes

Ordenadas por el TRAMO RESERVADO, que es el criterio honesto, no por la búsqueda.

| Barrido | Pasada | Búsqueda | Reservado | Fwd/Bus | Beneficio | PF | Oper. | Caída % |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| s0_cruce | 4302 | 0.3485 | 0.4420 | 1.27 | 1378.20 | 1.35 | 286 | 3.16 |
| s0_cruce | 4359 | 0.1736 | 0.2455 | 1.41 | 1160.46 | 1.17 | 287 | 4.86 |
| s0_cruce | 4122 | 0.2461 | 0.2346 | 0.95 | 1512.31 | 1.25 | 285 | 5.43 |
| s0_cruce | 4893 | 0.2777 | 0.2342 | 0.84 | 1975.23 | 1.28 | 284 | 6.99 |
| s0_cruce | 3996 | 0.2343 | 0.2118 | 0.90 | 1733.66 | 1.23 | 287 | 5.35 |
| s0_cruce | 2900 | 0.1698 | 0.2094 | 1.23 | 1033.48 | 1.17 | 386 | 4.43 |
| s0_cruce | 4594 | 0.2786 | 0.2083 | 0.75 | 1243.10 | 1.28 | 276 | 4.89 |
| s0_cruce | 5294 | 0.2520 | 0.1900 | 0.75 | 1262.49 | 1.25 | 280 | 4.49 |
| s0_cruce | 4524 | 0.2896 | 0.1707 | 0.59 | 1567.07 | 1.29 | 269 | 4.53 |
| s0_cruce | 5569 | 0.2853 | 0.1611 | 0.56 | 1403.81 | 1.29 | 271 | 4.59 |

La mejor por tramo reservado es la **pasada 4302 del cruce de medias**, que además puntuó
MÁS fuera de muestra que dentro (0.4420 frente a 0.3485). Sus genes:

```
InpPeriodoA=35
InpPeriodoB=120
InpDireccion=0
InpFiltroTend=1
InpPeriodoTend=50
InpHoraInicio=2
InpHoraFin=23
InpATRPeriodo=15
InpMultSL=3.0
InpMultTP=1.5
InpSalidaContraria=true
```

### Rasgos comunes, y por qué no hay que fiarse de ellos

De las 40 aptas: 35 operan en ambas direcciones y 5 solo cortos; 30 usan salida por señal
contraria; el filtro de tendencia se reparte (24 a favor, 9 en contra, 7 sin filtro).

Con el primer barrido terminado (solo el RSI, 9 aptas) parecía que **todas** llevaban el
filtro de tendencia en contra. Al entrar los otros dos barridos ese patrón se deshizo.
Es un buen recordatorio: con muestras de nueve casos sobre siete mil, cualquier
regularidad aparente puede ser el ruido que sobrevivió al filtro.

### Barridos que no se completaron

La tanda se canceló antes de terminar:

- **Banda de Bollinger**: se ejecutó el tramo de búsqueda (2.093 combinaciones) pero no
  el reservado. Sin forward no se puede aprobar nada, así que queda fuera de
  `resultados.json`. Su XML parcial se quedó en la carpeta del terminal.
- **Momento simple**: no llegó a ejecutarse.

Para completarlos, desde la consola marca solo esas dos señales y pulsa lanzar, o bien:

```bash
"<carpeta del terminal>\terminal64.exe" /portable /config:"<carpeta del kit>\logs\optimizar_s3_bollinger.ini"
```

### Verificación individual (Fase 6): pendiente

Volver a pasar el mejor candidato por el Probador como test individual **no se hizo**,
porque la tanda se canceló. No se da por verificado algo que no se ha ejecutado. Para
hacerlo:

```bash
python verificar.py informes/resultados.json
```
```bash
"<carpeta del terminal>\terminal64.exe" /portable /config:"<carpeta del kit>\logs\verificar.ini"
```

`verificar.py` deja en `informes/verificar_esperado.json` las cifras que dice el XML.
Si el test individual no las reproduce, hay algo mal y hay que decirlo, no taparlo.

---

## 9. Qué NO se ha comprobado

Para que nadie dé por probado lo que no lo está:

- La verificación individual del mejor candidato (arriba).
- Los barridos de Bollinger y de momento.
- El botón *Lanzar* de la consola no se ejercitó de punta a punta contra un barrido real,
  porque durante las pruebas el terminal estaba ocupado y lanzar habría roto la regla de
  una sola instancia por carpeta de datos. Sí está probado todo lo que lo rodea:
  generación del `.set` y del `.ini`, validación de entrada, detección de terminal
  ocupado (409 real), cola, lectura del log y recuento.
- Nada de esto se ha probado en una cuenta demo operando en vivo. Es backtest.

---

## Licencia

MIT (ver `LICENSE`). Se entrega tal cual, **sin garantía de ningún tipo**.
