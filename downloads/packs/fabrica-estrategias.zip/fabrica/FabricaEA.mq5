//+------------------------------------------------------------------+
//|                                                    FabricaEA.mq5 |
//|                             Fabrica de estrategias parametricas  |
//+------------------------------------------------------------------+
//  QUE ES ESTO
//  -----------
//  Este Expert Advisor NO implementa "una" estrategia: implementa un
//  ESPACIO de estrategias.  Ninguna regla esta escrita a fuego en el
//  codigo; todas las decisiones (que senal usar, con que periodos, con
//  que filtro de tendencia, en que horas, con que stop y que objetivo)
//  estan expuestas como inputs.  Cada combinacion concreta de valores
//  de esos inputs ES una estrategia distinta.
//
//  El optimizador genetico de MetaTrader 5 recorre ese espacio y el
//  fichero JuezRobustez.mqh decide, mediante OnTester(), que pasadas
//  merecen sobrevivir.  Por eso aqui no hay ninguna puntuacion: la
//  fabrica solo produce candidatos, el juez los evalua.
//
//  REGLAS DE LA CASA (invariantes, no son parametrizables):
//    * Una sola posicion abierta a la vez.
//    * Nada de promediar, rejillas ni martingalas.  Jamas.
//    * Se decide en el cierre de vela, sobre barras YA CERRADAS.
//    * El riesgo por operacion se calcula sobre la distancia al stop.
//+------------------------------------------------------------------+
#property copyright "Fabrica de Estrategias - 2026"
#property link      "https://www.mql5.com"
#property version   "1.00"
#property description "Plantilla parametrica: cada combinacion de inputs es una estrategia."
#property description "Senales: cruce de medias, RSI, ruptura de rango, Bollinger y momento."
#property description "Pensada para el optimizador genetico; la puntuacion vive en JuezRobustez.mqh."

//--- El juez externo aporta PuntuacionRobustez(), usada por OnTester().
#include "JuezRobustez.mqh"
//--- Libreria estandar de trading (envio y gestion de ordenes).
#include <Trade\Trade.mqh>

//+------------------------------------------------------------------+
//| VALORES CANONICOS DE LOS GENES INERTES                           |
//+------------------------------------------------------------------+
//  Un gen es INERTE cuando la combinacion elegida no lo lee: por
//  ejemplo InpPeriodoB con la senal de RSI, o InpPeriodoTend sin filtro
//  de tendencia.  Dos combinaciones que solo difieren en un gen inerte
//  NO son dos estrategias: son la MISMA estrategia escrita dos veces.
//
//  Si se deja libre un gen inerte, el barrido lo multiplica todo: con
//  20 valores de InpPeriodoB, cada estrategia de RSI, ruptura,
//  Bollinger y momento aparece 20 veces identica.  El genetico llena la
//  poblacion de clones (cree que explora y solo repite) y el ranking
//  final de JuezRobustez devuelve N copias del mismo candidato en vez
//  de N candidatos distintos.
//
//  Solucion: cada gen inerte tiene un valor CANONICO.  En OnInit se
//  exige ese valor exacto cuando el gen no se usa y se rechaza con
//  INIT_PARAMETERS_INCORRECT en caso contrario, de modo que de cada
//  estrategia sobreviva UNA sola copia en el espacio de busqueda.
//  El valor canonico debe estar SIEMPRE entre los que el .set visita
//  (lo natural es el primero del rango) o esa rama se quedaria vacia.
#define CANON_PERIODO_B    20     // valor canonico de InpPeriodoB cuando la senal no lo usa
#define CANON_UMBRAL       0.5    // valor canonico de InpUmbral cuando la senal no lo usa
#define CANON_PERIODO_TEND 50     // valor canonico de InpPeriodoTend cuando no hay filtro de tendencia

//+------------------------------------------------------------------+
//| GENES: enumeraciones                                             |
//| Valores explicitos empezando en 0 para que los ficheros .set del |
//| optimizador trabajen con enteros limpios 0..N.                   |
//+------------------------------------------------------------------+
enum ENUM_SENAL
  {
   SENAL_CRUCE_MEDIAS = 0, // 0 - Cruce de medias
   SENAL_RSI          = 1, // 1 - RSI cruzando umbral
   SENAL_RUPTURA      = 2, // 2 - Ruptura de rango de N velas
   SENAL_BOLLINGER    = 3, // 3 - Cruce de banda de Bollinger
   SENAL_MOMENTO      = 4  // 4 - Momento simple (% de variacion)
  };

enum ENUM_DIRECCION
  {
   DIR_AMBAS       = 0, // 0 - Ambas direcciones
   DIR_SOLO_LARGOS = 1, // 1 - Solo largos
   DIR_SOLO_CORTOS = 2  // 2 - Solo cortos
  };

enum ENUM_FILTRO_TEND
  {
   FILTRO_NINGUNO   = 0, // 0 - Sin filtro de tendencia
   FILTRO_A_FAVOR   = 1, // 1 - A favor de la media
   FILTRO_EN_CONTRA = 2  // 2 - En contra de la media
  };

//+------------------------------------------------------------------+
//| GENES: inputs (contrato cerrado, no tocar nombres ni tipos)      |
//+------------------------------------------------------------------+
input ENUM_SENAL     InpSenal           = SENAL_CRUCE_MEDIAS; // 0=cruce medias,1=RSI umbral,2=ruptura rango N,3=cruce banda Bollinger,4=momento simple
input int            InpPeriodoA        = 12;   // periodo principal / rapido / N velas / periodo RSI / periodo Bollinger / periodo momento
input int            InpPeriodoB        = 36;   // periodo secundario / lento (solo lo usa el cruce de medias)
input double         InpUmbral          = 30.0; // umbral: nivel RSI (ej 30), desviaciones Bollinger (ej 2.0), % momento (ej 0.15)
input ENUM_DIRECCION InpDireccion       = DIR_AMBAS;     // 0=ambas,1=solo largos,2=solo cortos
input ENUM_FILTRO_TEND InpFiltroTend    = FILTRO_NINGUNO; // 0=ninguno,1=a favor (largos exigen cierre>MA, cortos cierre<MA),2=en contra (inverso)
input int            InpPeriodoTend     = 200;  // periodo de la media del filtro de tendencia
input int            InpHoraInicio      = 0;    // hora de inicio de la ventana operativa (0..23)
input int            InpHoraFin         = 23;   // hora de fin de la ventana operativa (0..23), inclusive
input int            InpATRPeriodo      = 14;   // periodo del ATR usado para stop y objetivo
input double         InpMultSL          = 2.0;  // stop = InpMultSL * ATR
input double         InpMultTP          = 3.0;  // objetivo = InpMultTP * ATR
input bool           InpSalidaContraria = false;// cerrar tambien si aparece la senal contraria
input double         InpRiesgoPct       = 0.5;  // % del saldo arriesgado por operacion (sobre la distancia al stop)
input long           InpMagico          = 20260914; // numero magico

//+------------------------------------------------------------------+
//| Estado global                                                    |
//+------------------------------------------------------------------+
CTrade g_operador;                        // ejecutor de ordenes

//--- Handles de indicador.  Solo se crean los que la combinacion
//--- concreta necesita: crear de mas gasta memoria y tiempo de CPU en
//--- cada pasada de optimizacion, y son millones de pasadas.
int g_hMediaRapida = INVALID_HANDLE;      // media rapida (cruce)
int g_hMediaLenta  = INVALID_HANDLE;      // media lenta  (cruce)
int g_hRSI         = INVALID_HANDLE;      // RSI
int g_hBandas      = INVALID_HANDLE;      // Bollinger
int g_hMomento     = INVALID_HANDLE;      // Momentum
int g_hATR         = INVALID_HANDLE;      // ATR (stop y objetivo): SIEMPRE necesario
int g_hMediaTend   = INVALID_HANDLE;      // media del filtro de tendencia

//--- Cache de propiedades del simbolo.  Solo se cachea lo que de verdad
//--- es invariante durante la pasada: digitos, punto y tamano de tick.
//--- SYMBOL_TRADE_TICK_VALUE NO se cachea a proposito: esta expresado en
//--- la divisa del deposito y el terminal lo recalcula con la cotizacion
//--- cruzada vigente, asi que en todo simbolo cuya divisa de beneficio
//--- no sea la de la cuenta (USDJPY en cuenta USD, cruces, indices,
//--- metales) se mueve a lo largo del backtest.  Congelarlo desviaria el
//--- riesgo real respecto a InpRiesgoPct de forma sistematica; se lee
//--- vivo en CalcularVolumen.
int    g_digitos   = 5;
double g_tickSize  = 0.0;
double g_punto     = 0.0;

//--- Numero minimo de barras cerradas que la combinacion necesita para
//--- poder calcularse sin leer datos inexistentes.
int g_barrasNecesarias = 100;

//--- Tiempo de apertura de la ultima barra YA PROCESADA (0 = ninguna
//--- todavia).  Vive como variable global, que en MQL5 tiene almacena-
//--- miento estatico, porque la DETECCION de barra nueva y su CONSUMO
//--- ocurren en puntos distintos del ciclo de OnTick.
datetime g_tiempoUltimaBarra = 0;

//+------------------------------------------------------------------+
//| OnInit                                                           |
//| Filtro de cordura + creacion de handles.                         |
//| Devolver INIT_PARAMETERS_INCORRECT es la forma barata de decirle  |
//| al optimizador "esta combinacion no tiene sentido, no gastes una  |
//| pasada entera en ella".                                           |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- 1) Ventana horaria coherente ---------------------------------
   if(InpHoraInicio < 0 || InpHoraInicio > 23)
      return(INIT_PARAMETERS_INCORRECT);
   if(InpHoraFin < 0 || InpHoraFin > 23)
      return(INIT_PARAMETERS_INCORRECT);
   if(InpHoraInicio > InpHoraFin)          // ventana vacia: no operaria nunca
      return(INIT_PARAMETERS_INCORRECT);

//--- 2) Periodos minimamente sensatos -----------------------------
//     Ojo: aqui solo se exige ">= 2" a los periodos que TODA combina-
//     cion usa siempre (InpPeriodoA y InpATRPeriodo).  A InpPeriodoB y
//     a InpPeriodoTend se les exige el minimo unicamente cuando la
//     combinacion los usa de verdad; cuando estan inertes lo que manda
//     es su valor canonico (bloque 2-bis), no el rango.
   if(InpPeriodoA < 2 || InpATRPeriodo < 2)
      return(INIT_PARAMETERS_INCORRECT);

//--- 2-bis) CANONIZACION DE GENES INERTES --------------------------
//     Mismo argumento que el bloque 3 (rapida >= lenta): si dos juegos
//     de inputs producen EXACTAMENTE la misma estrategia, solo uno debe
//     sobrevivir.  Un gen que la senal elegida no lee no cambia ni una
//     operacion; dejarlo libre solo sirve para clonar pasadas.  Por eso
//     se exige aqui su valor canonico y se rechaza el resto sin gastar
//     la pasada entera.

//     a) InpPeriodoB (media lenta) SOLO lo usa SENAL_CRUCE_MEDIAS.
//        Para RSI, ruptura, Bollinger y momento es inerte: sin esta
//        regla, cada una de esas estrategias se repetiria tantas veces
//        como valores de InpPeriodoB recorra el .set.
   if(InpSenal == SENAL_CRUCE_MEDIAS)
     {
      if(InpPeriodoB < 2)
         return(INIT_PARAMETERS_INCORRECT);
     }
   else
     {
      if(InpPeriodoB != CANON_PERIODO_B)
         return(INIT_PARAMETERS_INCORRECT);
     }

//     b) InpUmbral NO lo leen ni SENAL_CRUCE_MEDIAS ni SENAL_RUPTURA
//        (el cruce compara medias y la ruptura compara con el rango).
//        Barriendo 40 umbrales, cada estrategia de cruce y de ruptura
//        se evaluaria 40 veces identica: 39 pasadas tiradas.  Es un
//        double, asi que la igualdad se comprueba con tolerancia.
   if(InpSenal == SENAL_CRUCE_MEDIAS || InpSenal == SENAL_RUPTURA)
     {
      if(MathAbs(InpUmbral - CANON_UMBRAL) >= 1e-9)
         return(INIT_PARAMETERS_INCORRECT);
     }

//     c) InpPeriodoTend SOLO se usa si hay filtro de tendencia activo.
//        Con FILTRO_NINGUNO no se crea ni el handle de la media, asi
//        que cada valor del barrido duplicaria todas las combinaciones
//        sin filtro.
   if(InpFiltroTend != FILTRO_NINGUNO)
     {
      if(InpPeriodoTend < 2)
         return(INIT_PARAMETERS_INCORRECT);
     }
   else
     {
      if(InpPeriodoTend != CANON_PERIODO_TEND)
         return(INIT_PARAMETERS_INCORRECT);
     }

//--- 3) Coherencia rapida/lenta en el cruce de medias --------------
//     Una media "rapida" con periodo mayor o igual que la "lenta" es
//     la misma estrategia espejada: duplicaria el espacio de busqueda.
   if(InpSenal == SENAL_CRUCE_MEDIAS && InpPeriodoA >= InpPeriodoB)
      return(INIT_PARAMETERS_INCORRECT);

//--- 4) Gestion monetaria con sentido ------------------------------
   if(InpMultSL <= 0.0 || InpMultTP <= 0.0)
      return(INIT_PARAMETERS_INCORRECT);
   if(InpRiesgoPct <= 0.0 || InpRiesgoPct > 5.0)   // techo duro de riesgo
      return(INIT_PARAMETERS_INCORRECT);

//--- 4-bis) Numero magico propio y distinto de cero ----------------
//     Las operaciones abiertas A MANO llevan magico 0.  Con InpMagico=0
//     el filtro por magico casaria con ellas y el EA las adoptaria como
//     suyas: bloquearia sus propias aperturas y, con InpSalidaContraria,
//     hasta podria cerrarlas.  Exactamente lo que el comentario del
//     bloque de POSICIONES llama catastrofico.
   if(InpMagico <= 0)
      return(INIT_PARAMETERS_INCORRECT);

//--- 5) El umbral significa cosas distintas segun la senal ---------
   if(InpSenal == SENAL_RSI && (InpUmbral < 5.0 || InpUmbral > 45.0))
      return(INIT_PARAMETERS_INCORRECT);        // nivel de sobreventa
   if(InpSenal == SENAL_BOLLINGER && (InpUmbral < 0.5 || InpUmbral > 4.0))
      return(INIT_PARAMETERS_INCORRECT);        // desviaciones tipicas
   if(InpSenal == SENAL_MOMENTO && (InpUmbral < 0.01 || InpUmbral > 2.0))
      return(INIT_PARAMETERS_INCORRECT);        // porcentaje de variacion

//--- 6) Handles de indicador --------------------------------------
//     El ATR se usa siempre (stop y objetivo se miden en ATR).
//     Un INVALID_HANDLE con parametros ya validados NO es un problema de
//     parametros sino de ENTORNO (agente sin recursos, historico no
//     disponible).  Por eso se devuelve INIT_FAILED y no
//     INIT_PARAMETERS_INCORRECT: con la etiqueta equivocada el genetico
//     podaria esa region del espacio como si fuera absurda y el fallo
//     real desapareceria del informe sin dejar rastro.
   g_hATR = iATR(_Symbol, _Period, InpATRPeriodo);
   if(g_hATR == INVALID_HANDLE)
      return(INIT_FAILED);

   switch(InpSenal)
     {
      case SENAL_CRUCE_MEDIAS:
         g_hMediaRapida = iMA(_Symbol, _Period, InpPeriodoA, 0, MODE_SMA, PRICE_CLOSE);
         g_hMediaLenta  = iMA(_Symbol, _Period, InpPeriodoB, 0, MODE_SMA, PRICE_CLOSE);
         if(g_hMediaRapida == INVALID_HANDLE || g_hMediaLenta == INVALID_HANDLE)
            return(INIT_FAILED);
         g_barrasNecesarias = InpPeriodoB + 5;
         break;

      case SENAL_RSI:
         g_hRSI = iRSI(_Symbol, _Period, InpPeriodoA, PRICE_CLOSE);
         if(g_hRSI == INVALID_HANDLE)
            return(INIT_FAILED);
         g_barrasNecesarias = InpPeriodoA * 3 + 5;
         break;

      case SENAL_RUPTURA:
         //--- No necesita indicador: se calcula con maximos y minimos.
         g_barrasNecesarias = InpPeriodoA + 5;
         break;

      case SENAL_BOLLINGER:
         g_hBandas = iBands(_Symbol, _Period, InpPeriodoA, 0, InpUmbral, PRICE_CLOSE);
         if(g_hBandas == INVALID_HANDLE)
            return(INIT_FAILED);
         g_barrasNecesarias = InpPeriodoA + 5;
         break;

      case SENAL_MOMENTO:
         g_hMomento = iMomentum(_Symbol, _Period, InpPeriodoA, PRICE_CLOSE);
         if(g_hMomento == INVALID_HANDLE)
            return(INIT_FAILED);
         g_barrasNecesarias = InpPeriodoA + 5;
         break;

      default:
         return(INIT_PARAMETERS_INCORRECT);
     }

//--- Media del filtro de tendencia: solo si el filtro esta activo.
   if(InpFiltroTend != FILTRO_NINGUNO)
     {
      g_hMediaTend = iMA(_Symbol, _Period, InpPeriodoTend, 0, MODE_SMA, PRICE_CLOSE);
      if(g_hMediaTend == INVALID_HANDLE)
         return(INIT_FAILED);
      if(InpPeriodoTend + 5 > g_barrasNecesarias)
         g_barrasNecesarias = InpPeriodoTend + 5;
     }

   if(InpATRPeriodo + 5 > g_barrasNecesarias)
      g_barrasNecesarias = InpATRPeriodo + 5;

//--- 7) Cache de propiedades del simbolo ---------------------------
//     Solo las realmente invariantes.  El valor del tick se lee vivo en
//     CalcularVolumen (ver comentario de las globales).
   g_digitos   = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   g_punto     = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   g_tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);

//     Sin punto o sin tamano de tick no se pueden normalizar precios ni
//     dimensionar el lote: el EA no abriria una sola operacion en toda
//     la pasada, en silencio.  Es un fallo de entorno, no de genes.
   if(g_punto <= 0.0 || g_tickSize <= 0.0)
      return(INIT_FAILED);

//--- Ninguna barra procesada todavia: la primera observacion solo
//--- sembrara el reloj interno (ver EsBarraNueva).
   g_tiempoUltimaBarra = 0;

//--- 8) Configuracion del ejecutor de ordenes ----------------------
   g_operador.SetExpertMagicNumber((ulong)InpMagico);
   g_operador.SetDeviationInPoints(20);          // desvio razonable
   g_operador.SetTypeFillingBySymbol(_Symbol);   // relleno admitido por el simbolo
   g_operador.LogLevel(LOG_LEVEL_ERRORS);        // menos ruido en optimizacion

   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| OnDeinit: devolver los handles al terminal.                      |
//| En una optimizacion con millones de pasadas, no liberar handles   |
//| termina agotando recursos del agente.                             |
//+------------------------------------------------------------------+
void OnDeinit(const int motivo)
  {
   if(g_hMediaRapida != INVALID_HANDLE) IndicatorRelease(g_hMediaRapida);
   if(g_hMediaLenta  != INVALID_HANDLE) IndicatorRelease(g_hMediaLenta);
   if(g_hRSI         != INVALID_HANDLE) IndicatorRelease(g_hRSI);
   if(g_hBandas      != INVALID_HANDLE) IndicatorRelease(g_hBandas);
   if(g_hMomento     != INVALID_HANDLE) IndicatorRelease(g_hMomento);
   if(g_hATR         != INVALID_HANDLE) IndicatorRelease(g_hATR);
   if(g_hMediaTend   != INVALID_HANDLE) IndicatorRelease(g_hMediaTend);

   g_hMediaRapida = INVALID_HANDLE;
   g_hMediaLenta  = INVALID_HANDLE;
   g_hRSI         = INVALID_HANDLE;
   g_hBandas      = INVALID_HANDLE;
   g_hMomento     = INVALID_HANDLE;
   g_hATR         = INVALID_HANDLE;
   g_hMediaTend   = INVALID_HANDLE;
  }

//+------------------------------------------------------------------+
//| OnTester: la puntuacion la pone el juez, no la fabrica.          |
//+------------------------------------------------------------------+
double OnTester()
  {
   return(PuntuacionRobustez());
  }

//+------------------------------------------------------------------+
//| UTILIDADES DE LECTURA                                            |
//+------------------------------------------------------------------+

//--- Copia "cuantos" valores de un buffer empezando en la barra
//--- "desde" (1 = ultima barra cerrada).  Deja el array en modo serie,
//--- asi destino[0] es la barra "desde", destino[1] la anterior, etc.
bool LeerBuffer(const int manejador, const int indiceBuffer,
                const int desde, const int cuantos, double &destino[])
  {
   if(manejador == INVALID_HANDLE || cuantos <= 0)
      return(false);
   ArraySetAsSeries(destino, true);
   if(CopyBuffer(manejador, indiceBuffer, desde, cuantos, destino) < cuantos)
      return(false);
   return(true);
  }

//--- Igual, pero con los precios de cierre de las barras cerradas.
bool LeerCierres(const int desde, const int cuantos, double &destino[])
  {
   if(cuantos <= 0)
      return(false);
   ArraySetAsSeries(destino, true);
   if(CopyClose(_Symbol, _Period, desde, cuantos, destino) < cuantos)
      return(false);
   return(true);
  }

//+------------------------------------------------------------------+
//| DETECCION DE BARRA NUEVA                                         |
//| Solo decidimos en el cierre de vela: operar tick a tick convierte |
//| el backtest en ficcion (depende del modelado de ticks) y multi-   |
//| plica el sobreajuste.                                             |
//|                                                                   |
//| Dos matices que importan:                                         |
//|   * La PRIMERA observacion tras arrancar, recompilar o reconectar |
//|     no opera: solo siembra el reloj.  Si disparase, el EA decidi- |
//|     ria en mitad de la vela en formacion con una senal de la barra|
//|     1 que puede tener horas (o dias en D1) de antiguedad.         |
//|   * Detectar NO es consumir.  La barra se marca como procesada    |
//|     desde OnTick, y solo cuando el ciclo ha podido completarse: si|
//|     el historico o el ATR aun no estan listos se sale sin marcarla|
//|     y la senal se reintenta, en vez de perderla para siempre.     |
//+------------------------------------------------------------------+
bool EsBarraNueva(datetime &tiempoBarra)
  {
   tiempoBarra = iTime(_Symbol, _Period, 0);
   if(tiempoBarra == 0)                           // historico aun no listo
      return(false);
   if(tiempoBarra == g_tiempoUltimaBarra)         // ya procesada
      return(false);

   if(g_tiempoUltimaBarra == 0)                   // primera observacion
     {
      g_tiempoUltimaBarra = tiempoBarra;          // sembrar y no operar
      return(false);
     }

   return(true);
  }

//+------------------------------------------------------------------+
//| SENALES                                                          |
//| Todas devuelven +1 (compra), -1 (venta) o 0 (nada) y TODAS se     |
//| calculan sobre las barras 1 y 2, ya cerradas.  La barra 0 esta en |
//| formacion: usarla seria mirar el futuro (look-ahead bias) y daria |
//| curvas de beneficio preciosas e imposibles de reproducir.         |
//+------------------------------------------------------------------+

//--- 0) Cruce de medias: rapida (A) contra lenta (B).
int SenalCruceMedias()
  {
   double rapida[], lenta[];
   if(!LeerBuffer(g_hMediaRapida, 0, 1, 2, rapida)) return(0);
   if(!LeerBuffer(g_hMediaLenta,  0, 1, 2, lenta))  return(0);

   //--- indice 0 = barra 1 (ultima cerrada), indice 1 = barra 2
   bool cruceAlza  = (rapida[1] <= lenta[1] && rapida[0] >  lenta[0]);
   bool cruceBaja  = (rapida[1] >= lenta[1] && rapida[0] <  lenta[0]);

   if(cruceAlza) return(+1);
   if(cruceBaja) return(-1);
   return(0);
  }

//--- 1) RSI: cruce al alza del nivel de sobreventa (InpUmbral) o
//---    cruce a la baja del de sobrecompra (100 - InpUmbral).
int SenalRSI()
  {
   double rsi[];
   if(!LeerBuffer(g_hRSI, 0, 1, 2, rsi)) return(0);

   double nivelBajo = InpUmbral;             // p.ej. 30
   double nivelAlto = 100.0 - InpUmbral;     // p.ej. 70

   if(rsi[1] <= nivelBajo && rsi[0] > nivelBajo) return(+1);
   if(rsi[1] >= nivelAlto && rsi[0] < nivelAlto) return(-1);
   return(0);
  }

//--- 2) Ruptura del rango de las InpPeriodoA barras anteriores.
//---    El rango se mide en las barras 2..InpPeriodoA+1, de modo que
//---    la barra 1 (la que rompe) NO forma parte de su propio rango.
int SenalRuptura()
  {
   int n = InpPeriodoA;
   double maximos[], minimos[], cierres[];

   ArraySetAsSeries(maximos, true);
   ArraySetAsSeries(minimos, true);

   if(CopyHigh(_Symbol, _Period, 2, n, maximos) < n) return(0);
   if(CopyLow(_Symbol, _Period, 2, n, minimos)  < n) return(0);
   if(!LeerCierres(1, 1, cierres))                   return(0);

   int idxMax = ArrayMaximum(maximos, 0, n);
   int idxMin = ArrayMinimum(minimos, 0, n);
   if(idxMax < 0 || idxMin < 0) return(0);

   double techo = maximos[idxMax];
   double suelo = minimos[idxMin];

   if(cierres[0] > techo) return(+1);
   if(cierres[0] < suelo) return(-1);
   return(0);
  }

//--- 3) Bollinger: cruce de la banda superior (compra) o inferior
//---    (venta).  Buffers: 0 = linea media, 1 = superior, 2 = inferior.
int SenalBollinger()
  {
   double superior[], inferior[], cierres[];
   if(!LeerBuffer(g_hBandas, 1, 1, 2, superior)) return(0);
   if(!LeerBuffer(g_hBandas, 2, 1, 2, inferior)) return(0);
   if(!LeerCierres(1, 2, cierres))               return(0);

   bool cruzaSuperior = (cierres[1] <= superior[1] && cierres[0] >  superior[0]);
   bool cruzaInferior = (cierres[1] >= inferior[1] && cierres[0] <  inferior[0]);

   if(cruzaSuperior) return(+1);
   if(cruzaInferior) return(-1);
   return(0);
  }

//--- 4) Momento: variacion porcentual del cierre respecto al cierre de
//---    hace InpPeriodoA barras.  El indicador Momentum devuelve
//---    close[i]/close[i+n]*100, asi que restarle 100 da justo el % .
int SenalMomento()
  {
   double momento[];
   if(!LeerBuffer(g_hMomento, 0, 1, 1, momento)) return(0);

   double variacionPct = momento[0] - 100.0;

   if(variacionPct >  InpUmbral) return(+1);
   if(variacionPct < -InpUmbral) return(-1);
   return(0);
  }

//--- Despachador: traduce el gen InpSenal en la funcion concreta.
int CalcularSenal()
  {
   switch(InpSenal)
     {
      case SENAL_CRUCE_MEDIAS: return(SenalCruceMedias());
      case SENAL_RSI:          return(SenalRSI());
      case SENAL_RUPTURA:      return(SenalRuptura());
      case SENAL_BOLLINGER:    return(SenalBollinger());
      case SENAL_MOMENTO:      return(SenalMomento());
     }
   return(0);
  }

//+------------------------------------------------------------------+
//| FILTROS                                                          |
//+------------------------------------------------------------------+

//--- Filtro de tendencia: media simple de InpPeriodoTend sobre cierres.
//--- A FAVOR   -> compras solo por encima de la media, ventas debajo.
//--- EN CONTRA -> exactamente lo contrario (reversion a la media).
//--- Es un gen deliberadamente simetrico: dejamos que el optimizador
//--- descubra si el mercado premia seguir o contrariar la tendencia.
bool PasaFiltroTendencia(const int senal)
  {
   if(InpFiltroTend == FILTRO_NINGUNO)
      return(true);
   if(senal == 0)
      return(false);

   double media[], cierres[];
   if(!LeerBuffer(g_hMediaTend, 0, 1, 1, media)) return(false);
   if(!LeerCierres(1, 1, cierres))               return(false);

   bool porEncima = (cierres[0] > media[0]);

   if(InpFiltroTend == FILTRO_A_FAVOR)
      return((senal > 0) ? porEncima : !porEncima);

   //--- FILTRO_EN_CONTRA
   return((senal > 0) ? !porEncima : porEncima);
  }

//--- Filtro de direccion: amputa el lado que el gen no permite.
bool PasaFiltroDireccion(const int senal)
  {
   if(senal > 0 && InpDireccion == DIR_SOLO_CORTOS) return(false);
   if(senal < 0 && InpDireccion == DIR_SOLO_LARGOS) return(false);
   return(senal != 0);
  }

//--- Filtro horario: usa la hora del servidor, que es la que ve el
//--- historico del tester.  Solo condiciona APERTURAS; una posicion
//--- abierta puede cerrarse a cualquier hora (lo contrario dejaria
//--- riesgo vivo fuera de la ventana).
bool DentroDeVentanaHoraria()
  {
   MqlDateTime ahora;
   TimeToStruct(TimeCurrent(), ahora);
   return(ahora.hour >= InpHoraInicio && ahora.hour <= InpHoraFin);
  }

//+------------------------------------------------------------------+
//| POSICIONES                                                       |
//| SIEMPRE filtradas por simbolo Y numero magico: en una cuenta      |
//| compartida con otros EAs, tocar posiciones ajenas es catastrofico.|
//+------------------------------------------------------------------+
bool BuscarPosicionPropia(ulong &ticket, ENUM_POSITION_TYPE &tipo)
  {
   ticket = 0;
   tipo   = POSITION_TYPE_BUY;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong t = PositionGetTicket(i);
      if(t == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;
      if(PositionGetInteger(POSITION_MAGIC) != InpMagico)
         continue;

      ticket = t;
      tipo   = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      return(true);
     }
   return(false);
  }

//+------------------------------------------------------------------+
//| PRECIOS Y VOLUMEN                                                |
//+------------------------------------------------------------------+

//--- Redondea al tick del simbolo y despues a sus digitos.  Enviar un
//--- precio que no cae en la rejilla de ticks es rechazo seguro.
double NormalizarPrecio(const double precio)
  {
   double p = precio;
   if(g_tickSize > 0.0)
      p = MathRound(precio / g_tickSize) * g_tickSize;
   return(NormalizeDouble(p, g_digitos));
  }

//--- Distancia minima a la que el broker acepta stop y objetivo.
//--- Tomamos el mayor entre STOPS_LEVEL y FREEZE_LEVEL y, si el broker
//--- declara cero (habitual en cuentas ECN), usamos el spread actual
//--- como colchon para no pegar los stops al precio.
double DistanciaMinima()
  {
   long nivelStops   = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL);
   long nivelCongela = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_FREEZE_LEVEL);
   long nivel        = (nivelStops > nivelCongela) ? nivelStops : nivelCongela;

   double distancia = (double)nivel * g_punto;

   double ask    = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid    = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double spread = ask - bid;
   if(spread > 0.0 && distancia < spread)
      distancia = spread;

   //--- Suelo absoluto: nunca menos de un par de ticks.
   double suelo = (g_tickSize > 0.0) ? (2.0 * g_tickSize) : (2.0 * g_punto);
   if(distancia < suelo)
      distancia = suelo;

   return(distancia);
  }

//--- Cuantos decimales tiene el paso de volumen (para NormalizeDouble).
//--- Se cuenta multiplicando por 10 hasta que el paso es ENTERO, no
//--- hasta que llega a 1.0: con el criterio antiguo un paso de 0.25
//--- devolvia 1 decimal y NormalizeDouble convertia un volumen valido
//--- de 1.75 en 1.8, que ya no es multiplo del paso -> "Invalid volume"
//--- y operacion perdida.  Pasos de 0.25 o 0.025 son minoritarios pero
//--- existen en CFDs y futuros, y esto pretende ser generico.
int DecimalesDelPaso(const double paso)
  {
   int decimales = 0;
   double p = paso;
   while(decimales < 8 && MathAbs(p - MathRound(p)) > 1e-9)
     {
      p *= 10.0;
      decimales++;
     }
   return(decimales);
  }

//--- Volumen que arriesga InpRiesgoPct % del saldo si salta el stop.
//--- Devuelve 0 si no se puede operar con ese riesgo: preferimos NO
//--- operar antes que forzar el lote minimo, porque forzarlo falsea
//--- el riesgo real y contamina la estadistica de la optimizacion.
double CalcularVolumen(const double distanciaStop)
  {
   if(distanciaStop <= 0.0)
      return(0.0);
   if(g_tickSize <= 0.0)
      return(0.0);

   //--- Valor del tick LEIDO EN VIVO, no cacheado en OnInit: esta en
   //--- divisa del deposito y el terminal lo recalcula con la cotizacion
   //--- cruzada vigente.  Con una copia rancia, el lote dejaria de
   //--- arriesgar InpRiesgoPct y la desviacion seria sistematica durante
   //--- toda la pasada (y si en el arranque el terminal aun no tenia la
   //--- cotizacion de conversion valdria 0, con lo que el EA no abriria
   //--- ni una sola operacion, en silencio y sin error).
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   if(tickValue <= 0.0)
      return(0.0);

   double saldo         = AccountInfoDouble(ACCOUNT_BALANCE);
   double dineroRiesgo  = saldo * InpRiesgoPct / 100.0;
   if(dineroRiesgo <= 0.0)
      return(0.0);

   //--- Perdida en dinero por cada lote si el precio recorre el stop.
   double ticksHastaStop  = distanciaStop / g_tickSize;
   double perdidaPorLote  = ticksHastaStop * tickValue;
   if(perdidaPorLote <= 0.0)
      return(0.0);

   double volumen = dineroRiesgo / perdidaPorLote;

   //--- Normalizacion al paso, minimo y maximo del simbolo.
   double paso = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   double vMin = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double vMax = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   if(paso <= 0.0)
      paso = 0.01;

   //--- Hacia abajo (nunca de mas), pero con una pizca de tolerancia:
   //--- 0.03/0.01 vale 2.9999999999999996 en binario y MathFloor a pelo
   //--- devolveria 0.02, un 33% menos de riesgo del pedido, de forma
   //--- erratica segun el cociente.
   volumen = MathFloor(volumen / paso + 1e-8) * paso;
   volumen = NormalizeDouble(volumen, DecimalesDelPaso(paso));

   if(vMax > 0.0 && volumen > vMax)
      volumen = vMax;
   if(volumen < vMin)
      return(0.0);                                  // riesgo demasiado pequeno

   return(volumen);
  }

//--- Deja rastro de un envio rechazado (stops invalidos, margen,
//--- requote, mercado cerrado...).  Sin esto, una orden rechazada
//--- desaparece sin dejar senal y la pasada sale con menos operaciones
//--- de las que la estrategia genero.  En optimizacion se calla: son
//--- millones de pasadas y escribir en disco las frena.
void RegistrarFalloOperacion(const string contexto)
  {
   if(MQLInfoInteger(MQL_OPTIMIZATION) != 0)
      return;
   PrintFormat("%s fallido: retcode=%u (%s)", contexto,
               g_operador.ResultRetcode(),
               g_operador.ResultRetcodeDescription());
  }

//+------------------------------------------------------------------+
//| APERTURA                                                         |
//| Stop y objetivo en multiplos de ATR: asi la estrategia se adapta  |
//| sola a la volatilidad del momento y del simbolo, y los genes      |
//| InpMultSL/InpMultTP son comparables entre mercados.               |
//+------------------------------------------------------------------+
void AbrirOperacion(const int senal, const double atr)
  {
   if(senal == 0 || atr <= 0.0)
      return;

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(ask <= 0.0 || bid <= 0.0)
      return;

   double spread = ask - bid;
   if(spread < 0.0)
      spread = 0.0;

   double distSL = InpMultSL * atr;
   double distTP = InpMultTP * atr;

   //--- Separacion minima exigida por el broker.
   double minima = DistanciaMinima();

   //--- OJO: el stop se mide desde el precio de ENTRADA (ask al comprar,
   //--- bid al vender) pero el broker valida la distancia contra el
   //--- precio de CIERRE de la posicion (bid al comprar, ask al vender).
   //--- En una compra el margen efectivo es bid-SL = distSL - spread, de
   //--- modo que un stop pegado a "minima" se queda corto por todo el
   //--- spread y la orden vuelve rechazada (10016, invalid stops).  Se
   //--- suma el spread al minimo del SL; el TP no lo necesita porque ahi
   //--- el spread juega a favor (tp-bid = distTP + spread).
   double minimaSL = minima + spread;
   if(distSL < minimaSL) distSL = minimaSL;
   if(distTP < minima)   distTP = minima;

   double precio = 0.0, sl = 0.0, tp = 0.0;

   if(senal > 0)
     {
      precio = ask;
      sl = NormalizarPrecio(precio - distSL);
      tp = NormalizarPrecio(precio + distTP);
      //--- El redondeo puede haber acercado los niveles: reverificar
      //--- contra el precio de cierre (bid), que es lo que mira el broker.
      if((bid - sl) < minima || (tp - bid) < minima)
        {
         sl = NormalizarPrecio(precio - (distSL + g_tickSize));
         tp = NormalizarPrecio(precio + (distTP + g_tickSize));
        }
     }
   else
     {
      precio = bid;
      sl = NormalizarPrecio(precio + distSL);
      tp = NormalizarPrecio(precio - distTP);
      //--- Aqui el precio de cierre es el ask.
      if((sl - ask) < minima || (ask - tp) < minima)
        {
         sl = NormalizarPrecio(precio + (distSL + g_tickSize));
         tp = NormalizarPrecio(precio - (distTP + g_tickSize));
        }
     }

   if(sl <= 0.0 || tp <= 0.0)
      return;

   //--- El volumen se calcula con la distancia REAL al stop ya
   //--- normalizado, no con la teorica: si el broker nos obligo a
   //--- separar el stop, el riesgo ha cambiado y el lote tambien.
   double distanciaReal = MathAbs(precio - sl);
   double volumen       = CalcularVolumen(distanciaReal);
   if(volumen <= 0.0)
      return;                       // riesgo no representable: no operamos

   if(senal > 0)
     {
      if(!g_operador.Buy(volumen, _Symbol, 0.0, sl, tp, "Fabrica"))
         RegistrarFalloOperacion("Apertura de compra");
     }
   else
     {
      if(!g_operador.Sell(volumen, _Symbol, 0.0, sl, tp, "Fabrica"))
         RegistrarFalloOperacion("Apertura de venta");
     }
  }

//+------------------------------------------------------------------+
//| OnTick                                                           |
//| Todo el ciclo de decision, una sola vez por vela cerrada.        |
//+------------------------------------------------------------------+
void OnTick()
  {
//--- 1) Solo trabajamos al cierre de vela.  Detectar no es consumir:
//---    la barra no se da por procesada hasta el paso 4-bis.
   datetime tiempoBarra = 0;
   if(!EsBarraNueva(tiempoBarra))
      return;

//--- 2) Historico suficiente para que los calculos sean reales.
   if(Bars(_Symbol, _Period) < g_barrasNecesarias)
      return;

//--- 3) ATR de la ultima barra cerrada (stop, objetivo y volumen).
   double atrBuffer[];
   if(!LeerBuffer(g_hATR, 0, 1, 1, atrBuffer))
      return;
   double atr = atrBuffer[0];
   if(atr <= 0.0)
      return;

//--- 4) Senal cruda de la combinacion (aun sin filtrar).
   int senalCruda = CalcularSenal();

//--- 4-bis) Llegados aqui el ciclo de decision se ha podido completar
//---    con datos reales: marcamos la barra como procesada para no
//---    repetirla.  Si hubiesemos salido antes (historico corto, ATR
//---    todavia sin calcular tras un hueco de conexion) la barra sigue
//---    sin consumir y el proximo tick lo reintenta, en vez de perder
//---    esa senal para siempre.  Las decisiones se siguen tomando sobre
//---    las barras 1 y 2, ya cerradas: jamas sobre la 0.
   g_tiempoUltimaBarra = tiempoBarra;

//--- 5) Gestion de la posicion abierta, si la hay.
   ulong ticket = 0;
   ENUM_POSITION_TYPE tipo = POSITION_TYPE_BUY;

   if(BuscarPosicionPropia(ticket, tipo))
     {
      //--- Salida por senal contraria (gen opcional).  Usamos la senal
      //--- CRUDA a proposito: si aplicasemos aqui el filtro de
      //--- direccion, un EA "solo largos" nunca veria la senal de venta
      //--- y la salida contraria quedaria muerta.
      if(InpSalidaContraria && senalCruda != 0)
        {
         bool contraria = ((tipo == POSITION_TYPE_BUY  && senalCruda < 0) ||
                           (tipo == POSITION_TYPE_SELL && senalCruda > 0));
         if(contraria)
           {
            if(!g_operador.PositionClose(ticket))
               RegistrarFalloOperacion("Cierre por senal contraria");
           }
        }
      //--- Haya cerrado o no, no abrimos nada en esta vela: una sola
      //--- posicion a la vez y sin dar la vuelta en el mismo instante.
      return;
     }

//--- 6) Sin posicion: evaluamos la apertura.
   if(senalCruda == 0)
      return;
   if(!DentroDeVentanaHoraria())      // el horario solo frena aperturas
      return;
   if(!PasaFiltroDireccion(senalCruda))
      return;
   if(!PasaFiltroTendencia(senalCruda))
      return;

   AbrirOperacion(senalCruda, atr);
  }
//+------------------------------------------------------------------+
