# -*- coding: utf-8 -*-
"""
Comprobacion independiente del lector.

Vuelve a leer el XML con un parser MINIMO y distinto del de lector.py y
compara, celda a celda, los numeros que produjo lector.py contra el texto
crudo del XML. Sirve para detectar corrupcion silenciosa: separadores de
millares mal interpretados, columnas desalineadas por ss:Index, etc.

Uso: python comprobar_lector.py <xml> <resultados.json>
"""
import io
import json
import os
import sys
import xml.etree.ElementTree as ET

SS = "{urn:schemas-microsoft-com:office:spreadsheet}"


def celdas(fila):
    """Extrae las celdas de una fila RESPETANDO ss:Index."""
    fuera = []
    idx = 0
    for c in fila.findall(SS + "Cell"):
        i = c.get(SS + "Index")
        if i:
            idx = int(i) - 1
        while len(fuera) < idx:
            fuera.append(None)
        d = c.find(SS + "Data")
        fuera.append(d.text if d is not None else None)
        idx = len(fuera)
    return fuera


def main():
    xml, js = sys.argv[1], sys.argv[2]
    raiz = ET.parse(xml).getroot()
    filas = raiz.findall(".//" + SS + "Worksheet/" + SS + "Table/" + SS + "Row")
    cab = celdas(filas[0])
    crudo = {}
    for f in filas[1:]:
        v = dict(zip(cab, celdas(f)))
        crudo[str(v.get("Pass"))] = v

    datos = json.load(io.open(js, encoding="utf-8"))
    cands = datos.get("candidatos", [])

    # Cuando el JSON funde VARIOS barridos, los numeros de pasada se repiten:
    # cada barrido numera desde 0. Comparar un XML suelto contra todos los
    # candidatos casaria la pasada 6610 de un barrido con la 6610 de otro y
    # daria miles de discrepancias falsas. Nos quedamos solo con los candidatos
    # que vienen de ESTE fichero, que es lo que lector.py anota en "origen".
    origen_xml = os.path.splitext(os.path.basename(xml))[0]
    con_origen = [c for c in cands if c.get("origen")]
    if con_origen:
        propios = [c for c in cands if c.get("origen") == origen_xml]
        if not propios:
            print("AVISO: el JSON no contiene ningun candidato con origen '%s'."
                  % origen_xml)
            print("       Barridos que si contiene: %s"
                  % ", ".join(sorted({c["origen"] for c in con_origen})))
            return 1
        cands = propios
        print("  (comparando solo los %d candidatos de '%s')"
              % (len(cands), origen_xml))

    # Que clave del JSON corresponde a que columna del XML.
    pares = [
        ("beneficio", "Profit"),
        ("factor_beneficio", "Profit Factor"),
        ("operaciones", "Trades"),
        ("caida_pct", "Equity DD %"),
        ("beneficio_esperado", "Expected Payoff"),
        ("factor_recuperacion", "Recovery Factor"),
        ("sharpe", "Sharpe Ratio"),
        ("personalizado", "Custom"),
    ]

    fallos = []
    comparadas = 0
    for c in cands:
        p = str(c.get("pass"))
        if p not in crudo:
            fallos.append("la pasada %s del JSON no existe en el XML" % p)
            continue
        for clave_json, col_xml in pares:
            txt = crudo[p].get(col_xml)
            if txt is None:
                continue
            try:
                esperado = float(txt)
            except (TypeError, ValueError):
                continue
            obtenido = c.get(clave_json)
            if obtenido is None:
                fallos.append("pasada %s: %s ausente en el JSON (XML dice %s)"
                              % (p, clave_json, txt))
                continue
            comparadas += 1
            if abs(float(obtenido) - esperado) > max(1e-6, abs(esperado) * 1e-9):
                fallos.append("pasada %s: %s -> JSON %r vs XML %r"
                              % (p, clave_json, obtenido, txt))
        # Los genes tambien: columnas que empiezan por Inp
        for col, txt in crudo[p].items():
            if not col or not col.startswith("Inp") or txt is None:
                continue
            g = (c.get("genes") or {}).get(col)
            if g is None:
                fallos.append("pasada %s: gen %s ausente en el JSON" % (p, col))
                continue
            comparadas += 1
            try:
                if abs(float(g) - float(txt)) > 1e-9:
                    fallos.append("pasada %s: gen %s -> JSON %r vs XML %r"
                                  % (p, col, g, txt))
            except (TypeError, ValueError):
                if str(g) != str(txt):
                    fallos.append("pasada %s: gen %s -> JSON %r vs XML %r"
                                  % (p, col, g, txt))

    print("=" * 68)
    print("COMPROBACION INDEPENDIENTE DEL LECTOR")
    print("=" * 68)
    print("  Filas en el XML        : %d" % len(crudo))
    print("  Candidatos en el JSON  : %d" % len(cands))
    print("  Valores comparados     : %d" % comparadas)
    if fallos:
        print("  RESULTADO              : %d DISCREPANCIAS" % len(fallos))
        for f in fallos[:25]:
            print("      - %s" % f)
        if len(fallos) > 25:
            print("      ... y %d mas" % (len(fallos) - 25))
        sys.exit(1)
    print("  RESULTADO              : sin discrepancias")
    print("=" * 68)


if __name__ == "__main__":
    main()
