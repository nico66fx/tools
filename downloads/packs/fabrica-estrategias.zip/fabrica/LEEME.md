# Fábrica de estrategias para MetaTrader 5

**por @nico66fx**

---

> ## Léelo antes de tocar nada
>
> **Esto genera candidatos, no estrategias ganadoras. Probar miles de combinaciones sobre los
> mismos datos hace que algunas parezcan buenas por pura casualidad. El tramo reservado reduce
> ese riesgo, no lo elimina. Nada de lo que salga aquí está listo para dinero real sin pasar
> antes por una cuenta demo.**

Tres cosas más, en el mismo tono:

- **Esto no es asesoramiento financiero.** No es una recomendación de inversión, ni una señal,
  ni una opinión sobre qué deberías hacer con tu dinero. Es una herramienta de búsqueda.
- **Quien lo use, lo usa bajo su propia responsabilidad.** Las decisiones son tuyas y las
  pérdidas también.
- **La inmensa mayoría de lo que salga de aquí no valdrá nada.** No es pesimismo: en la tanda
  de referencia, de 18.835 combinaciones probadas pasaron el filtro 40, un 0,21 %. Y pasar el
  filtro sigue sin significar que funcione con dinero real. Lo normal es terminar sin ninguna
  candidata, y eso es un resultado correcto, no un fallo del programa.

---

## Qué es esto

Un robot de MetaTrader 5 cuyas reglas no están escritas a fuego, sino que son parámetros: cada
combinación de valores es una estrategia distinta. El optimizador de MetaTrader recorre ese
espacio probando combinaciones, y un juez de robustez puntúa cada una castigando lo que suele
engañar (pocas operaciones, caídas grandes, un único acierto gigante que sostiene la curva).
Al final, un panel te enseña qué ha sobrevivido y, sobre todo, qué se ha caído y por qué.

## Qué hace falta

| | |
|---|---|
| **Windows** | El kit habla con MetaTrader, que es un programa de Windows |
| **MetaTrader 5** | Instalado **y con una cuenta abierta dentro del terminal**. Vale una demo gratuita: al abrir MetaTrader por primera vez te ofrece abrir una cuenta demo en MetaQuotes-Demo, sin coste y sin dar datos bancarios. Sin cuenta, el Probador de MetaTrader no arranca |
| **Python 3** | Descárgalo de <https://www.python.org/downloads/> e instálalo. **Marca la casilla «Add Python to PATH»** en la primera pantalla del instalador |

No hace falta saber programar. No hace falta configurar nada a mano.

## Cómo se usa

**Doble clic en `EMPEZAR.bat`.** Y ya.

Se abrirá una ventana negra con texto —es normal, no la cierres— y al terminar se abrirá la
consola en tu navegador.

**La primera vez tarda un poco más** y no se ha colgado: está compilando el robot con el
MetaEditor y buscando dónde tienes instalado MetaTrader. Las siguientes veces arranca en
segundos.

## Qué vas a ver

La consola tiene cuatro zonas, de arriba abajo:

1. **El lanzador.** Eliges qué señales quieres barrer (cruce de medias, RSI, ruptura, Bollinger,
   momento), el símbolo, el marco temporal, las fechas y cuánto periodo quieres reservar sin
   tocar. Pulsas *Lanzar barrido* y empieza. Debajo tienes el estado en vivo: qué está corriendo,
   qué hay en cola y qué dice el log de MetaTrader.
2. **El recuento.** Cuántas combinaciones se probaron, cuántas pasaron el filtro, y —la tabla
   más útil de todas— **por qué no pasan** las demás, motivo a motivo.
3. **Los gráficos.** El reparto de puntuaciones, y un gráfico de dispersión que enfrenta lo que
   una combinación puntuó en el tramo de búsqueda con lo que puntuó en el tramo reservado. Ese
   segundo gráfico es el que de verdad hay que mirar: enseña de un vistazo cuántas cosas
   brillantes se desinflan en cuanto ven datos nuevos.
4. **La biblioteca.** Las supervivientes se van acumulando ahí entre tandas, sin duplicados, con
   sus parámetros a la vista para que puedas reproducirlas.

## Cuánto tarda

**Decenas de minutos por señal.** Un barrido de verdad, con años de histórico, no es cosa de un
par de minutos: MetaTrader tiene que simular miles de combinaciones vela a vela, y además repite
cada superviviente sobre el tramo reservado.

Mientras corre, el estado en vivo se va moviendo y el log va creciendo. Si ves que avanza,
funciona. Déjalo trabajar.

## Lo que este kit NO hace

Conviene tenerlo claro, porque es la parte que más tranquilidad da:

- **No abre ni cierra operaciones reales.** Todo ocurre dentro del Probador de estrategias de
  MetaTrader, que es una simulación sobre datos históricos.
- **No toca la configuración de tu terminal.** No cambia tus plantillas, ni tus perfiles, ni tus
  gráficos.
- **No interactúa con tu cuenta.** No lee tu saldo, no mira tus posiciones, no cancela nada ni
  las órdenes que ya tuvieras puestas.
- **Arranca el terminal siempre con el trading automático DESACTIVADO.**

Esa última precaución no es un adorno, y tiene un motivo concreto: si tienes un robot adjunto a
alguno de tus gráficos, **arrancar el terminal lo pondría en marcha**, y ese robot podría colocar
órdenes en tu cuenta sin que tú hayas pedido nada. Como el kit necesita arrancar MetaTrader para
optimizar, lo arranca con el trading automático apagado (`AllowLiveTrading=0`). El Probador no se
ve afectado, porque simula en lugar de operar.

Aun así, el consejo prudente: **usa un terminal sin robots adjuntos a los gráficos**, o crea una
instalación aparte para esto.

## Preguntas frecuentes

**«No me detecta MetaTrader».**
El lanzador te lo dirá en la ventana negra y se parará ahí en lugar de seguir a ciegas.
Comprueba: que MetaTrader 5 está instalado de verdad (no solo descargado), que lo has abierto al
menos una vez, y que en su carpeta existe el fichero `terminal64.exe`. Si lo tienes en una
instalación portable o en una carpeta poco habitual, apunta esa ruta: es la que hay que indicarle.
Para encontrarla: abre MetaTrader y ve a *Archivo → Abrir carpeta de datos*.

**«Dice que no hay cuenta».**
El Probador de MetaTrader se niega a arrancar si el terminal no tiene ninguna cuenta conectada.
En el log aparece tal cual: `tester not started because the account is not specified`. Solución:
abre MetaTrader, *Archivo → Abrir una cuenta*, elige MetaQuotes-Demo, acepta y deja que se
conecte. Es gratis y es una demo. Luego cierra el terminal y vuelve a lanzar `EMPEZAR.bat`.

**«No sobrevive ninguna estrategia».**
Eso es un resultado válido, y de hecho es lo normal. Significa que en ese símbolo, ese periodo y
ese espacio de reglas no había nada que aguantase fuera de muestra. Es información buena, no un
error: te acabas de ahorrar el disgusto.

**No relajes las puertas para que salga algo.** La consola te deja ajustarlas, y es tentador
bajarlas hasta que aparezcan candidatas. Lo único que consigues así es dejar pasar el ruido que
antes se quedaba fuera. Si quieres cambiar algo, cambia el símbolo, el periodo o las señales,
no el listón.

**«¿Puedo probar otro símbolo que no sea EURUSD?».**
Sí, se elige en el lanzador. Ten en cuenta que MetaTrader solo puede simular con el histórico
que tu bróker sirva para ese símbolo; si tiene poco, el periodo que pidas se recortará solo.

## Licencia

MIT. Ver el fichero `LICENSE`. Puedes usarlo, copiarlo, modificarlo y distribuirlo.

**Se entrega tal cual, sin garantía de ningún tipo.** Ni de que funcione, ni de que los
resultados sean correctos, ni de que sirva para ningún fin concreto.

---

## Quién hace esto

Hecho y regalado por **@nico66fx**.

Si lo usas y te sirve, cuéntalo. Si encuentras algo que falla, cuéntalo también: se arregla
antes si alguien lo dice.
