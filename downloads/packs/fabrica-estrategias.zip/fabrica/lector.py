# -*- coding: utf-8 -*-
"""
lector.py -- Lector de informes de optimizacion del Probador de Estrategias de
MetaTrader 5.

Lee el XML ("Spreadsheet XML 2003" de Microsoft Office) que exporta MetaTrader 5
al terminar una optimizacion, opcionalmente cruza el tramo reservado (forward),
aplica una bateria de puertas de calidad y escribe un resultados.json.

Solo biblioteca estandar. Python 3.

Uso:
    python lector.py <ruta_xml> [--forward <ruta_forward_xml>] [--salida resultados.json]

Si no se indica --forward se intenta deducir sustituyendo ".xml" por ".forward.xml".
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from collections import namedtuple


# ---------------------------------------------------------------------------
# PUERTAS DE CALIDAD
# ---------------------------------------------------------------------------
# Umbrales que decide si una combinacion de parametros merece seguir viva.
# Son deliberadamente ESTRICTOS: es mas barato descartar una buena que aprobar
# una mala. Para relajarlos basta con tocar los numeros de este diccionario,
# no hay que buscar nada mas por el fichero.
PUERTAS = {
    # Numero minimo de operaciones cerradas. Con menos de 100 operaciones la
    # estadistica es ruido: cualquier resultado puede ser casualidad.
    "MIN_OPERACIONES": 100,

    # La caida maxima (drawdown) EN DINERO no debe superar esta fraccion del
    # beneficio total. 0.50 = la caida no puede pasar de la mitad de lo ganado.
    # OJO: para comprobarlo hace falta la caida en dinero, y el informe de
    # MetaTrader normalmente solo trae "Equity DD %" (un porcentaje de los
    # fondos), que NO es comparable con un beneficio en divisa. Ver la puerta 3
    # en evalua_puertas(): de donde se saca la caida en dinero y que hace la
    # puerta cuando no hay manera de obtenerla.
    "MAX_CAIDA_SOBRE_BENEFICIO": 0.50,

    # Peso maximo que puede tener la mejor operacion sobre el beneficio total.
    # Evita las estrategias que viven de un unico pelotazo afortunado.
    # SOLO se comprueba si el XML trae la columna correspondiente.
    "MAX_PESO_MEJOR_OPERACION": 0.25,

    # Fraccion minima de meses en positivo. Mide regularidad, no suerte.
    # SOLO se comprueba si el XML trae el dato.
    "MIN_MESES_POSITIVOS": 0.55,

    # Puntuacion de robustez minima (valor devuelto por OnTester) para que la
    # combinacion merezca siquiera ser considerada.
    "MIN_PUNTUACION": 0.05,

    # El tramo reservado (forward) tiene que quedar en positivo, sin excusas.
    "FORWARD_MINIMO": 0.0,

    # Y ademas no puede desplomarse respecto al tramo de busqueda:
    # forward / busqueda no puede bajar de este ratio. 0.35 = se tolera perder
    # hasta el 65% del rendimiento fuera de muestra, no mas.
    "FORWARD_RATIO_MINIMO": 0.35,
}


# ---------------------------------------------------------------------------
# MAPA DE COLUMNAS
# ---------------------------------------------------------------------------
# Nombres de cabecera (en ingles y en espanol, normalizados a minusculas y sin
# espacios sobrantes) -> clave interna. No damos por fija ni la posicion ni el
# idioma: todo se descubre leyendo la primera fila.
MAPA_COLUMNAS = {
    # Pass / Pasada
    "pass": "pass",
    "pasada": "pass",
    "#": "pass",
    # Result / Resultado (valor de OnTester)
    "result": "resultado",
    "resultado": "resultado",
    # Profit / Beneficio
    "profit": "beneficio",
    "beneficio": "beneficio",
    # Expected Payoff / Beneficio esperado
    "expected payoff": "beneficio_esperado",
    "beneficio esperado": "beneficio_esperado",
    # Profit Factor / Factor de beneficio
    "profit factor": "factor_beneficio",
    "factor de beneficio": "factor_beneficio",
    "factor beneficio": "factor_beneficio",
    # Recovery Factor / Factor de recuperacion
    "recovery factor": "factor_recuperacion",
    "factor de recuperacion": "factor_recuperacion",
    "factor de recuperación": "factor_recuperacion",
    "factor recuperacion": "factor_recuperacion",
    # Sharpe Ratio / Ratio de Sharpe
    "sharpe ratio": "sharpe",
    "ratio de sharpe": "sharpe",
    "ratio sharpe": "sharpe",
    # Custom / Personalizado
    "custom": "personalizado",
    "personalizado": "personalizado",
    # Equity DD % / Reduccion de fondos
    "equity dd %": "caida_pct",
    "equity dd%": "caida_pct",
    "equity dd": "caida_pct",
    "reduccion de fondos": "caida_pct",
    "reducción de fondos": "caida_pct",
    "reduccion de fondos %": "caida_pct",
    "reducción de fondos %": "caida_pct",
    "drawdown %": "caida_pct",
    # Caida ABSOLUTA (en dinero). MetaTrader no siempre la exporta, pero si
    # viene es la unica medida directamente comparable con el beneficio y es
    # la que usa la puerta 3.
    "equity drawdown": "caida_abs",
    "equity drawdown maximal": "caida_abs",
    "balance drawdown": "caida_abs",
    "balance drawdown maximal": "caida_abs",
    "maximal drawdown": "caida_abs",
    "reduccion de fondos absoluta": "caida_abs",
    "reducción de fondos absoluta": "caida_abs",
    "caida maxima": "caida_abs",
    "caída máxima": "caida_abs",
    # Trades / Operaciones
    "trades": "operaciones",
    "operaciones": "operaciones",
    "total trades": "operaciones",
    "deals": "operaciones",
    # Resultados por tramo cuando MetaTrader ya los cruza el solo
    "back result": "resultado_busqueda",
    "resultado de busqueda": "resultado_busqueda",
    "resultado de búsqueda": "resultado_busqueda",
    "forward result": "resultado_forward",
    "resultado forward": "resultado_forward",
    # Datos opcionales para las puertas que solo se comprueban si existen.
    # No estan en el enunciado como obligatorias, pero si MetaTrader las
    # exporta las aprovechamos.
    "best trade": "mejor_operacion",
    "mejor operacion": "mejor_operacion",
    "mejor operación": "mejor_operacion",
    "profitable months %": "meses_positivos",
    "meses positivos": "meses_positivos",
    "meses positivos %": "meses_positivos",
}

# Espacio de nombres del formato Spreadsheet XML 2003.
NS_SS = "urn:schemas-microsoft-com:office:spreadsheet"

# Una celda leida del XML: su texto y el TIPO que el propio fichero declara en
# el atributo ss:Type ("Number", "String", "DateTime"...). El tipo viaja junto
# al texto hasta a_numero() porque es lo unico que permite convertir los
# numeros sin tener que adivinar el formato regional. Ver a_numero().
Celda = namedtuple("Celda", ("texto", "tipo"))

# Celda inexistente (hueco de los que MetaTrader se salta con ss:Index).
CELDA_VACIA = Celda(None, None)


# ---------------------------------------------------------------------------
# UTILIDADES DE NORMALIZACION
# ---------------------------------------------------------------------------


def _elegir_puntuacion(resultado, personalizado):
    """Devuelve la puntuacion de OnTester con la maxima precision disponible.

    MetaTrader escribe dos columnas para lo mismo cuando el criterio de
    optimizacion es 6 (personalizado): "Result", redondeada a dos decimales,
    y "Custom", con todos los decimales. Preferimos "Custom" cuando ambas
    coinciden dentro del margen de ese redondeo; si difieren mucho es que el
    criterio era otro y entonces la buena es "Result".
    """
    if personalizado is None:
        return resultado
    if resultado is None:
        return personalizado
    try:
        if abs(float(personalizado) - float(resultado)) <= 0.005 + 1e-9:
            return personalizado
    except (TypeError, ValueError):
        return resultado
    return resultado


def normaliza_cabecera(texto):
    """Pasa un nombre de columna a su forma canonica para poder compararlo.

    Minusculas, sin espacios al principio/final y colapsando espacios internos.
    """
    if texto is None:
        return ""
    return re.sub(r"\s+", " ", str(texto)).strip().lower()


# Patron de un numero "limpio": opcional signo, digitos, separador decimal
# (punto o coma) y opcional exponente. Admite el espacio como separador de
# millares (los espacios raros ya se han normalizado a espacio normal antes).
_RE_NUMERO = re.compile(
    r"^[+-]?(\d{1,3}(?: \d{3})*|\d+)([.,]\d+)?([eE][+-]?\d+)?$"
)

# Entero puro (sin parte decimal ni exponente).
_RE_ENTERO = re.compile(r"^[+-]?\d+$")

# Espacios "no separables" que, segun la configuracion regional de Windows,
# MetaTrader puede usar como separador de millares: duro (U+00A0), fino no
# separable (U+202F) y fino (U+2009). Si no se normalizan, el numero no se
# reconoce, la metrica se pierde en silencio y el candidato se rechaza por
# "faltan datos" aunque el dato estuviera alli.
_RE_ESPACIOS_DUROS = re.compile("[\u00a0\u202f\u2009]")

# Separador de millares SOLO cuando el texto no deja lugar a duda:
#   - dos o mas grupos de tres: 1.234.567 / 1,234,567
#   - o grupos de tres MAS una parte decimal marcada con el otro separador:
#     1.234,56 / 1,234.56
# Un unico grupo de tres y nada mas ("1.234", "1,234") es AMBIGUO: tanto puede
# ser mil doscientos treinta y cuatro como uno coma doscientos treinta y
# cuatro. Ante la duda NO se quita el separador, porque multiplicar por mil
# "por si acaso" corrompe el dato en silencio: un factor de beneficio de 1,234
# convertido en 1234 se cuela por cualquier filtro. Se excluye ademas el
# entero "0", porque detras de un cero solo jamas puede ir un grupo de
# millares ("0.085" es decimal sin discusion posible).
_RE_MILLARES_COMA = re.compile(
    r"^[+-]?(?!0[.,])\d{1,3}(?:,\d{3}){2,}$"
    r"|^[+-]?(?!0[.,])\d{1,3}(?:,\d{3})+\.\d+$"
)
_RE_MILLARES_PUNTO = re.compile(
    r"^[+-]?(?!0[.,])\d{1,3}(?:\.\d{3}){2,}$"
    r"|^[+-]?(?!0[.,])\d{1,3}(?:\.\d{3})+,\d+$"
)


def _convierte_ingles(limpio, bruto):
    """Convierte a int/float un texto que YA esta en formato ingles.

    `bruto` es el texto original y es lo que se devuelve si la conversion
    falla: preferimos que un valor raro se vea tal cual en el JSON a
    tragarnoslo en silencio.
    """
    try:
        if _RE_ENTERO.match(limpio):
            return int(limpio)
        return float(limpio)
    except ValueError:
        return bruto


def a_numero(texto, tipo=None):
    """Convierte a int/float si el valor es numerico; si no, devuelve el texto.

    `tipo` es el ss:Type que declara la propia celda del XML. Es la pieza clave
    para no corromper datos y por eso el parser lo propaga hasta aqui:

    - tipo "Number": en Spreadsheet XML 2003 una celda numerica se escribe
      SIEMPRE en formato invariante (punto decimal y sin separador de
      millares), y asi es exactamente como exporta MetaTrader:
      <Data ss:Type="Number">1.341241</Data>, 1147.98, 8.3416, 211.
      Por tanto se convierte con float()/int() DIRECTO, sin ninguna heuristica
      de locale. Aplicar heuristicas aqui era el fallo grave que se corrige:
      la regla de "millares continentales" se comia el punto decimal de
      cualquier valor con tres decimales y convertia 1.234 en 1234 o 0.085 en
      85. Un error de x1000 mudo que ademas colaba basura por las puertas.

    - tipo "String" o desconocido (texto escrito a mano, CSV, otro
      exportador): ahi si puede haber formato regional, asi que se normalizan
      los espacios raros y se aplican las reglas de millares, pero SOLO cuando
      el texto es inequivoco (ver _RE_MILLARES_*). Ante la duda no se
      multiplica nunca.

    Devuelve None si el valor esta vacio.
    """
    if texto is None:
        return None
    if isinstance(texto, (int, float)):
        return texto

    bruto = str(texto).strip()
    if bruto == "":
        return None

    # --- Celda declarada como numero: cero adivinanzas ----------------------
    if tipo is not None and str(tipo).strip().lower() == "number":
        return _convierte_ingles(bruto, bruto)

    # --- Resto de celdas: texto que PUEDE traer formato regional ------------
    # Quitamos un % final y normalizamos los espacios no separables.
    limpio = bruto.rstrip("%").strip()
    limpio = _RE_ESPACIOS_DUROS.sub(" ", limpio)

    # Caso anglosajon inequivoco: 1,234,567 o 1,234.56 -> la coma es millares.
    if _RE_MILLARES_COMA.match(limpio):
        limpio = limpio.replace(",", "")
    # Caso continental inequivoco: 1.234.567 o 1.234,56 -> el punto es millares.
    elif _RE_MILLARES_PUNTO.match(limpio):
        limpio = limpio.replace(".", "").replace(",", ".")

    if not _RE_NUMERO.match(limpio):
        # No es un numero reconocible: devolvemos el texto original tal cual.
        return bruto

    # Espacios de millares fuera y coma decimal a punto. Un "1,234" que llegue
    # hasta aqui se lee como 1.234 (decimal), que es la lectura que NO
    # multiplica por mil: ante la duda, el valor pequeno.
    limpio = limpio.replace(" ", "").replace(",", ".")
    return _convierte_ingles(limpio, bruto)


def a_float(valor):
    """Devuelve el valor como float, o None si no es numerico.

    Se usa sobre valores YA convertidos (int/float) o sobre texto suelto sin
    tipo declarado; por eso no recibe ss:Type.
    """
    if isinstance(valor, bool):
        return None
    if isinstance(valor, (int, float)):
        return float(valor)
    convertido = a_numero(valor)
    if isinstance(convertido, (int, float)) and not isinstance(convertido, bool):
        return float(convertido)
    return None


# ---------------------------------------------------------------------------
# PARSER DEL SPREADSHEET XML 2003
# ---------------------------------------------------------------------------

def _lee_celda(celda):
    """Extrae (texto, tipo) de una celda <Cell> mirando su hijo <Data>.

    El tipo es el atributo ss:Type que el fichero declara ("Number", "String",
    "DateTime"...). Se devuelve junto al texto y se propaga hasta a_numero()
    porque es lo unico que permite convertir los numeros sin adivinar el
    formato regional: con ss:Type="Number" el contenido es siempre ingles.
    """
    # El hijo puede venir con o sin espacio de nombres segun como se escribiera.
    for hijo in celda:
        if hijo.tag.split("}")[-1] != "Data":
            continue
        # itertext recoge tambien fragmentos con formato interno (<B>, <I>...).
        texto = "".join(hijo.itertext())
        tipo = hijo.get("{%s}Type" % NS_SS) or hijo.get("Type")
        return Celda(texto, tipo)

    # Algunos exportadores meten el texto directamente en la celda. Sin <Data>
    # no hay ss:Type, asi que el tipo queda desconocido (None) y a_numero
    # tratara el valor como texto con posible formato regional.
    texto = (celda.text or "").strip()
    return Celda(texto, None) if texto else CELDA_VACIA


def _celdas_de_fila(fila):
    """Devuelve la fila como lista de Celda (texto + ss:Type) respetando ss:Index.

    ESTE ES EL PUNTO CRITICO DEL FORMATO: MetaTrader omite las celdas vacias.
    Cuando una celda lleva el atributo ss:Index="N" significa "esta celda es la
    columna N (base 1)", es decir, hay que rellenar con huecos hasta llegar
    ahi. Si no se respeta, todas las columnas posteriores quedan desplazadas y
    los datos se mezclan sin que nada falle de forma visible. Es el fallo
    clasico al leer estos informes.
    """
    valores = []
    indice = 0  # posicion (base 0) donde se escribira la siguiente celda

    for celda in fila:
        if celda.tag.split("}")[-1] != "Cell":
            continue

        # ss:Index reposiciona la celda en una columna concreta (base 1).
        bruto_index = celda.get("{%s}Index" % NS_SS) or celda.get("Index")
        if bruto_index:
            try:
                nuevo_indice = int(bruto_index)
            except ValueError:
                nuevo_indice = 0  # indice corrupto: seguimos en secuencia
            if nuevo_indice >= 1:
                indice = nuevo_indice - 1
            # Un ss:Index de 0 o negativo no existe en el formato (es base 1).
            # Aceptarlo daria indice = -1, que mas abajo SOBRESCRIBIRIA la
            # ultima celda ya escrita y encogeria la fila sin avisar, que es
            # justo el desalineado silencioso que este parser evita. Se ignora
            # y se continua en secuencia.

        # Rellenamos los huecos que hayan quedado por el camino.
        while len(valores) < indice:
            valores.append(CELDA_VACIA)

        valor = _lee_celda(celda)
        if len(valores) == indice:
            valores.append(valor)
        else:
            # La celda vuelve sobre una posicion ya escrita (raro, pero legal).
            valores[indice] = valor

        # Una celda puede abarcar varias columnas con ss:MergeAcross.
        merge = celda.get("{%s}MergeAcross" % NS_SS)
        salto = 1
        if merge:
            try:
                salto += int(merge)
            except ValueError:
                pass
        indice += salto

    return valores


def _primera_tabla(raiz):
    """Localiza la primera <Table> con filas dentro del libro."""
    for tabla in raiz.iter():
        if tabla.tag.split("}")[-1] != "Table":
            continue
        filas = [f for f in tabla if f.tag.split("}")[-1] == "Row"]
        if filas:
            return filas
    return []


def lee_xml_metatrader(ruta):
    """Lee un informe XML de MetaTrader y devuelve (cabeceras, filas_crudas).

    cabeceras: lista de textos de la primera fila.
    filas_crudas: lista de listas de Celda (texto + ss:Type declarado),
                  alineadas con las cabeceras.

    Lanza LectorError con un mensaje claro si algo va mal.
    """
    if not os.path.isfile(ruta):
        raise LectorError("No existe el fichero XML: %s" % ruta)

    try:
        arbol = ET.parse(ruta)
    except ET.ParseError as err:
        raise LectorError(
            "XML malformado en '%s': %s\n"
            "Comprueba que es el informe de optimizacion exportado por "
            "MetaTrader 5 (formato Spreadsheet XML 2003) y que la descarga "
            "termino completa." % (ruta, err)
        )
    except OSError as err:
        raise LectorError("No se pudo leer '%s': %s" % (ruta, err))

    filas_xml = _primera_tabla(arbol.getroot())
    if not filas_xml:
        raise LectorError(
            "No se encontro ninguna tabla con filas en '%s'. "
            "El fichero no parece un informe de optimizacion de MetaTrader 5."
            % ruta
        )

    # De la cabecera solo interesa el texto; de los datos, texto Y tipo.
    cabeceras = [c.texto for c in _celdas_de_fila(filas_xml[0])]
    filas = [_celdas_de_fila(f) for f in filas_xml[1:]]

    # Descartamos filas completamente vacias (MetaTrader a veces cierra con una).
    filas = [f for f in filas if any(c.texto not in (None, "") for c in f)]

    return cabeceras, filas


# ---------------------------------------------------------------------------
# INTERPRETACION DE LAS COLUMNAS
# ---------------------------------------------------------------------------

def construye_indice_columnas(cabeceras, ruta):
    """Asocia cada posicion de columna con su clave interna o con un gen.

    Devuelve (mapa_metricas, mapa_genes, claves_en_porcentaje):
      mapa_metricas:        {posicion: clave_interna}
      mapa_genes:           {posicion: nombre_original_del_gen}
      claves_en_porcentaje: claves cuya cabecera declaraba "%" de forma
                            explicita. Sirve para no tener que adivinar despues
                            la escala de un dato (ver puerta 5).
    """
    mapa_metricas = {}
    mapa_genes = {}
    claves_en_porcentaje = set()
    claves_vistas = set()  # claves internas que ya tienen columna asignada

    for pos, titulo in enumerate(cabeceras):
        if titulo is None:
            continue
        nombre = normaliza_cabecera(titulo)
        if not nombre:
            continue

        clave = MAPA_COLUMNAS.get(nombre)
        if clave is None:
            # Tolerancia extra: quitamos un % o : final y reintentamos.
            alternativo = nombre.rstrip("%:").strip()
            clave = MAPA_COLUMNAS.get(alternativo)

        if clave is not None:
            # El informe combinado de MetaTrader repite cabeceras (Profit,
            # Trades o Equity DD % pueden aparecer una vez por tramo). Nos
            # quedamos con la PRIMERA aparicion, la de la izquierda, que es la
            # del tramo principal.
            # OJO: el mapa esta indexado por POSICION y la posicion es unica en
            # cada vuelta del bucle, asi que un setdefault sobre el mapa no
            # detecta ningun duplicado; hay que llevar la cuenta de las claves
            # ya asignadas. Sin esto se colaban todas las repeticiones y luego,
            # al montar el registro, ganaba la ULTIMA columna: lo contrario de
            # lo que dice este comentario.
            if clave in claves_vistas:
                continue
            claves_vistas.add(clave)
            mapa_metricas[pos] = clave
            # Nos quedamos con el dato de si la cabecera declaraba "%".
            if nombre.rstrip().endswith("%"):
                claves_en_porcentaje.add(clave)
            continue

        # Todo lo que empieza por "Inp" es un parametro de entrada: un GEN.
        if nombre.startswith("inp"):
            mapa_genes[pos] = str(titulo).strip()

    if not mapa_metricas and not mapa_genes:
        raise LectorError(
            "Cabecera no reconocida en '%s'.\n"
            "Se leyo esta primera fila: %s\n"
            "Se esperaban columnas tipo Pass/Pasada, Result/Resultado, "
            "Profit/Beneficio... Revisa que el fichero sea el informe de "
            "optimizacion y no el informe de una sola pasada."
            % (ruta, [c for c in cabeceras if c])
        )

    return mapa_metricas, mapa_genes, claves_en_porcentaje


def _valor_de_celda(celda):
    """Convierte una celda leida del XML al valor Python que le corresponda.

    Acepta tanto una Celda (texto + ss:Type, que es lo que produce el parser)
    como un texto suelto, por si se llama al modulo desde fuera con listas de
    cadenas. Es aqui donde el tipo declarado llega hasta a_numero.
    """
    if isinstance(celda, Celda):
        return a_numero(celda.texto, celda.tipo)
    return a_numero(celda)


def fila_a_registro(valores, mapa_metricas, mapa_genes,
                    claves_en_porcentaje=frozenset()):
    """Convierte una fila cruda en un diccionario con metricas y genes."""
    registro = {"genes": {}}

    for pos, clave in mapa_metricas.items():
        if pos < len(valores):
            convertido = _valor_de_celda(valores[pos])
            if convertido is None:
                continue
            if (clave == "meses_positivos"
                    and clave in claves_en_porcentaje
                    and isinstance(convertido, (int, float))
                    and not isinstance(convertido, bool)):
                # La cabecera declaraba "%", asi que el dato viene en
                # porcentaje. Lo guardamos SIEMPRE como fraccion y dejamos
                # constancia de que la escala es conocida, para que la puerta 5
                # no tenga que adivinarla.
                convertido = convertido / 100.0
                registro["meses_positivos_escala"] = "fraccion"
            registro[clave] = convertido

    for pos, nombre in mapa_genes.items():
        if pos < len(valores):
            convertido = _valor_de_celda(valores[pos])
            if convertido is not None:
                registro["genes"][nombre] = convertido

    return registro


def carga_informe(ruta):
    """Lee un XML completo y devuelve la lista de registros ya interpretados."""
    cabeceras, filas = lee_xml_metatrader(ruta)
    mapa_metricas, mapa_genes, claves_en_porcentaje = construye_indice_columnas(
        cabeceras, ruta)
    return [fila_a_registro(f, mapa_metricas, mapa_genes, claves_en_porcentaje)
            for f in filas]


# ---------------------------------------------------------------------------
# PUERTAS DE CALIDAD
# ---------------------------------------------------------------------------

def evalua_puertas(candidato, puertas):
    """Aplica TODAS las puertas y devuelve la lista de motivos de rechazo.

    Se comprueban todas, no se corta en la primera: interesa ver el cuadro
    completo de por que se descarta una combinacion.
    Lista vacia = la combinacion es apta.
    """
    motivos = []

    # --- Puerta 1: tamano de muestra ---------------------------------------
    operaciones = a_float(candidato.get("operaciones"))
    if operaciones is None:
        motivos.append("no consta el numero de operaciones")
    elif operaciones < puertas["MIN_OPERACIONES"]:
        motivos.append(
            "muestra insuficiente: %d operaciones, minimo %d"
            % (int(operaciones), puertas["MIN_OPERACIONES"])
        )

    # --- Puerta 2: puntuacion de robustez (OnTester) ------------------------
    puntuacion = a_float(candidato.get("puntuacion"))
    if puntuacion is None:
        motivos.append("no consta la puntuacion de robustez (OnTester)")
    elif puntuacion < puertas["MIN_PUNTUACION"]:
        motivos.append(
            "puntuacion de robustez baja: %.4f, minimo %.4f"
            % (puntuacion, puertas["MIN_PUNTUACION"])
        )

    # --- Puerta 3: la caida frente al BENEFICIO -----------------------------
    # LIMITACION DEL FORMATO, escrita aqui a proposito para que nadie se confie:
    # el informe de MetaTrader trae la caida como "Equity DD %", un PORCENTAJE
    # sobre los fondos, mientras que el beneficio va en DINERO. Un porcentaje de
    # fondos y una cantidad de divisa NO son magnitudes comparables, asi que
    # dividir la caida entre 100 y compararla con el umbral NO comprueba "la
    # caida no pasa de la mitad de lo ganado": comprueba otra cosa distinta y
    # mucho mas laxa (un drawdown de fondos por debajo del 50%), y lo hace sin
    # mirar el beneficio ni una sola vez. Eso es lo que hacia antes esta puerta.
    #
    # Para comprobar lo que el umbral promete hace falta la caida EN DINERO, y
    # solo hay dos formas honestas de obtenerla de este fichero:
    #   1) una columna de caida absoluta, si el informe la trae (caida_abs);
    #   2) el factor de recuperacion, que MetaTrader define exactamente como
    #      beneficio neto / caida maxima en dinero, de donde se despeja
    #      caida_dinero = beneficio / factor_recuperacion. Es una identidad de
    #      la propia plataforma, no una estimacion.
    # Si no hay ninguna de las dos, la puerta NO puede comprobarse con rigor y
    # lo dice en voz alta en lugar de fingir que la ha comprobado. Como en el
    # resto del modulo, sin verificacion no se aprueba: el motivo cuenta como
    # rechazo.
    beneficio = a_float(candidato.get("beneficio"))
    caida_pct = a_float(candidato.get("caida_pct"))
    caida_abs = a_float(candidato.get("caida_abs"))
    factor_recuperacion = a_float(candidato.get("factor_recuperacion"))

    if beneficio is None:
        motivos.append("no consta el beneficio del tramo de busqueda")
    elif beneficio <= 0:
        motivos.append("el beneficio del tramo de busqueda no es positivo")
    else:
        origen = None
        if caida_abs is not None and caida_abs >= 0:
            origen = "columna de caida absoluta"
        elif factor_recuperacion is not None and factor_recuperacion > 0:
            caida_abs = beneficio / factor_recuperacion
            origen = "deducida del factor de recuperacion"

        if origen is None:
            detalle = ("solo consta la caida en porcentaje de fondos "
                       "(Equity DD %% = %.2f%%)" % caida_pct
                       if caida_pct is not None
                       else "no consta ninguna medida de caida")
            motivos.append(
                "no se puede comprobar la caida sobre el beneficio: %s, y un "
                "porcentaje de fondos no es comparable con un beneficio en "
                "dinero; haria falta la caida absoluta o el factor de "
                "recuperacion" % detalle
            )
        else:
            relacion = caida_abs / beneficio
            if relacion > puertas["MAX_CAIDA_SOBRE_BENEFICIO"]:
                motivos.append(
                    "caida excesiva frente al beneficio: la caida vale el "
                    "%.0f%% de lo ganado (%.2f de caida frente a %.2f de "
                    "beneficio, %s), maximo %.0f%%"
                    % (relacion * 100, caida_abs, beneficio, origen,
                       puertas["MAX_CAIDA_SOBRE_BENEFICIO"] * 100)
                )

    # --- Puerta 4: peso de la mejor operacion (solo si hay dato) ------------
    mejor = a_float(candidato.get("mejor_operacion"))
    if mejor is not None and beneficio is not None and beneficio > 0:
        peso = mejor / beneficio
        if peso > puertas["MAX_PESO_MEJOR_OPERACION"]:
            motivos.append(
                "la mejor operacion pesa el %.1f%% del beneficio, maximo %.0f%%"
                % (peso * 100, puertas["MAX_PESO_MEJOR_OPERACION"] * 100)
            )

    # --- Puerta 5: meses positivos (solo si hay dato) ----------------------
    meses = a_float(candidato.get("meses_positivos"))
    if meses is not None:
        # La escala la fija la cabecera: si el titulo traia "%", el dato ya se
        # paso a fraccion al leer el fichero (ver fila_a_registro) y aqui no
        # hay nada que interpretar. Si la cabecera no lo declaraba, hay que
        # deducirlo, y eso no se hace a la ligera:
        #   < 1.0        -> fraccion (0.62 = 62% de meses en positivo)
        #   > 1.5        -> porcentaje (62 = 62%)
        #   entre 1 y 1.5 -> AMBIGUO. Un "1" pelado tanto puede ser el 100% de
        #                    los meses como el 1%, que es la peor estrategia
        #                    imaginable; darlo por bueno seria aprobar justo lo
        #                    que esta puerta existe para rechazar.
        if candidato.get("meses_positivos_escala") == "fraccion":
            fraccion = meses
        elif meses > 1.5:
            fraccion = meses / 100.0
        elif meses < 1.0:
            fraccion = meses
        else:
            fraccion = None
            motivos.append(
                "dato de meses positivos ambiguo (%.4f): la cabecera no "
                "declaraba la escala y no se puede saber si es fraccion "
                "(100%%) o porcentaje (1%%)" % meses
            )
        if fraccion is not None and fraccion < puertas["MIN_MESES_POSITIVOS"]:
            motivos.append(
                "pocos meses positivos: %.0f%%, minimo %.0f%%"
                % (fraccion * 100, puertas["MIN_MESES_POSITIVOS"] * 100)
            )

    # --- Puerta 6: LA DECISIVA, el tramo reservado (forward) ---------------
    forward = a_float(candidato.get("resultado_forward"))
    busqueda = a_float(candidato.get("resultado_busqueda"))
    if busqueda is None:
        busqueda = a_float(candidato.get("puntuacion"))

    if forward is None:
        # Sin verificacion fuera de muestra no se aprueba nada. Mas vale
        # descartar que aprobar a ciegas.
        motivos.append("sin tramo reservado que verificar")
    else:
        if forward <= puertas["FORWARD_MINIMO"]:
            motivos.append(
                "el tramo reservado no es positivo: %.4f, minimo %.4f"
                % (forward, puertas["FORWARD_MINIMO"])
            )
        if busqueda is not None and busqueda > 0:
            ratio = forward / busqueda
            if ratio < puertas["FORWARD_RATIO_MINIMO"]:
                motivos.append(
                    "desplome fuera de muestra: forward/busqueda = %.2f, "
                    "minimo %.2f" % (ratio, puertas["FORWARD_RATIO_MINIMO"])
                )

    return motivos


# ---------------------------------------------------------------------------
# CRUCE BUSQUEDA + FORWARD Y CONSTRUCCION DE CANDIDATOS
# ---------------------------------------------------------------------------

def construye_candidatos(registros_busqueda, registros_forward, puertas):
    """Cruza ambos tramos por numero de pasada y aplica las puertas."""
    # Indice del tramo reservado por numero de pasada.
    indice_forward = {}
    for reg in registros_forward:
        clave = reg.get("pass")
        if clave is not None:
            indice_forward[str(clave)] = reg

    candidatos = []
    for reg in registros_busqueda:
        pasada = reg.get("pass")
        reg_fwd = indice_forward.get(str(pasada)) if pasada is not None else None

        # La puntuacion es el valor de OnTester del tramo de busqueda.
        # OJO con la precision: MetaTrader escribe "Result" REDONDEADO a dos
        # decimales, mientras que "Custom" trae el valor completo que devolvio
        # OnTester(). Con puntuaciones del orden de 0.09 el redondeo se come
        # casi toda la senal, asi que preferimos "Custom" SIEMPRE QUE sea el
        # mismo numero (cuando el criterio de optimizacion es 6, lo es).
        # Si el criterio NO fue 6, "Result" es otra magnitud (balance, PF...)
        # y ambos valores diferiran mucho: en ese caso mandamos "Result".
        puntuacion = _elegir_puntuacion(reg.get("resultado"), reg.get("personalizado"))
        if puntuacion is None:
            puntuacion = reg.get("resultado_busqueda")

        # Resultado del tramo de busqueda: la columna explicita si existe,
        # y si no la propia puntuacion.
        resultado_busqueda = reg.get("resultado_busqueda")
        if resultado_busqueda is None:
            resultado_busqueda = puntuacion

        # Resultado del tramo reservado: primero la columna del propio XML de
        # busqueda (MetaTrader la escribe cuando cruza el solo), y si no el
        # valor que venga del fichero .forward.xml.
        resultado_forward = reg.get("resultado_forward")
        if resultado_forward is None and reg_fwd is not None:
            # Mismo criterio de precision que arriba: "Custom" antes que "Result".
            resultado_forward = _elegir_puntuacion(
                reg_fwd.get("resultado"), reg_fwd.get("personalizado"))

        candidato = {
            "pass": pasada,
            "resultado": reg.get("resultado"),
            "beneficio": reg.get("beneficio"),
            "beneficio_esperado": reg.get("beneficio_esperado"),
            "factor_beneficio": reg.get("factor_beneficio"),
            "factor_recuperacion": reg.get("factor_recuperacion"),
            "sharpe": reg.get("sharpe"),
            "personalizado": reg.get("personalizado"),
            "operaciones": reg.get("operaciones"),
            "caida_pct": reg.get("caida_pct"),
            # Caida en dinero: solo si el informe trae la columna. Es la unica
            # comparable con el beneficio (ver puerta 3).
            "caida_abs": reg.get("caida_abs"),
            "resultado_busqueda": resultado_busqueda,
            "resultado_forward": resultado_forward,
            "puntuacion": puntuacion,
            "genes": reg.get("genes", {}),
        }
        # Datos opcionales que solo se usan si el XML los trae.
        if "mejor_operacion" in reg:
            candidato["mejor_operacion"] = reg["mejor_operacion"]
        if "meses_positivos" in reg:
            candidato["meses_positivos"] = reg["meses_positivos"]
            # Escala del dato: "fraccion" si la cabecera declaraba "%" y ya se
            # normalizo al leer, "desconocida" si hay que interpretarlo.
            candidato["meses_positivos_escala"] = reg.get(
                "meses_positivos_escala", "desconocida")

        motivos = evalua_puertas(candidato, puertas)
        candidato["apta"] = not motivos
        candidato["motivos"] = motivos

        candidatos.append(candidato)

    # Orden: puntuacion descendente. Los que no tienen puntuacion van al final.
    def clave_orden(c):
        valor = a_float(c.get("puntuacion"))
        return (0 if valor is None else 1, valor if valor is not None else 0.0)

    candidatos.sort(key=clave_orden, reverse=True)
    return candidatos


# ---------------------------------------------------------------------------
# SALIDA POR PANTALLA
# ---------------------------------------------------------------------------

def formatea(valor, decimales=2):
    """Formatea un numero para el resumen, o '-' si no hay dato."""
    numero = a_float(valor)
    if numero is None:
        return "-"
    if float(numero).is_integer() and decimales == 0:
        return "%d" % int(numero)
    return ("%%.%df" % decimales) % numero


def imprime_resumen(candidatos, rutas, aptas):
    """Muestra por pantalla el resumen en espanol."""
    print("")
    print("=" * 72)
    print("LECTOR DE OPTIMIZACION DE METATRADER 5")
    print("=" * 72)
    for ruta in rutas:
        print("  Fichero leido : %s" % ruta)
    print("  Combinaciones leidas : %d" % len(candidatos))
    print("  Combinaciones aptas  : %d" % aptas)
    if candidatos:
        porcentaje = 100.0 * aptas / len(candidatos)
        print("  Tasa de aprobacion   : %.1f%%" % porcentaje)
    print("-" * 72)
    print("LAS 5 MEJORES POR PUNTUACION")
    print("-" * 72)

    if not candidatos:
        print("  (no hay combinaciones que mostrar)")
        return

    cabecera = ("%-8s %-10s %-12s %-8s %-9s %-9s %-10s %s"
                % ("Pasada", "Puntuac.", "Beneficio", "Oper.", "Caida%",
                   "Forward", "Apta", "Motivos"))
    print(cabecera)
    for c in candidatos[:5]:
        motivos = "OK" if c["apta"] else "; ".join(c["motivos"])
        if len(motivos) > 60:
            motivos = motivos[:57] + "..."
        print("%-8s %-10s %-12s %-8s %-9s %-9s %-10s %s" % (
            c.get("pass") if c.get("pass") is not None else "-",
            formatea(c.get("puntuacion"), 4),
            formatea(c.get("beneficio"), 2),
            formatea(c.get("operaciones"), 0),
            formatea(c.get("caida_pct"), 2),
            formatea(c.get("resultado_forward"), 4),
            "SI" if c["apta"] else "NO",
            motivos,
        ))
    print("=" * 72)
    print("")


# ---------------------------------------------------------------------------
# ERRORES PROPIOS
# ---------------------------------------------------------------------------

class LectorError(Exception):
    """Error controlado del lector, con mensaje ya listo para el usuario."""


# ---------------------------------------------------------------------------
# PROGRAMA PRINCIPAL
# ---------------------------------------------------------------------------

def deduce_ruta_forward(ruta_xml):
    """Deduce '<nombre>.forward.xml' a partir de '<nombre>.xml'."""
    if ruta_xml.lower().endswith(".forward.xml"):
        return None  # ya es el propio forward, no hay nada que deducir
    if ruta_xml.lower().endswith(".xml"):
        return ruta_xml[:-4] + ".forward.xml"
    return ruta_xml + ".forward.xml"


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Lee el XML de optimizacion de MetaTrader 5 y genera "
                    "resultados.json con las puertas de calidad aplicadas.",
    )
    parser.add_argument("ruta_xml", nargs="+",
                        help="Uno o VARIOS XML del tramo de busqueda exportados "
                             "por MetaTrader 5. Cuando el barrido se parte en "
                             "varias pasadas (por ejemplo una por senal), se "
                             "pasan todas y se funden en un unico resultado.")
    parser.add_argument("--forward", dest="forward", default=None,
                        help="XML del tramo reservado (por defecto se deduce "
                             "sustituyendo .xml por .forward.xml)")
    parser.add_argument("--salida", dest="salida", default="resultados.json",
                        help="Fichero JSON de salida (por defecto resultados.json)")
    args = parser.parse_args(argv)

    # Cada XML se procesa por separado y se cruza con SU propio forward: los
    # numeros de pasada ("Pass") se repiten entre ficheros, asi que cruzarlos
    # todos juntos mezclaria candidatos de barridos distintos.
    rutas_leidas = []
    candidatos = []
    total_filas = 0

    for entrada in args.ruta_xml:
        ruta_xml = os.path.abspath(entrada)
        try:
            registros_busqueda = carga_informe(ruta_xml)
        except LectorError as err:
            print("ERROR: %s" % err, file=sys.stderr)
            return 1
        rutas_leidas.append(ruta_xml)
        total_filas += len(registros_busqueda)

        if len(registros_busqueda) <= 1:
            print("")
            print("!" * 72, file=sys.stderr)
            print("AVISO GRAVE: %s contiene %d fila(s) de datos."
                  % (os.path.basename(ruta_xml), len(registros_busqueda)),
                  file=sys.stderr)
            print("La configuracion del optimizador esta MAL. Una optimizacion",
                  file=sys.stderr)
            print("real produce cientos o miles de combinaciones. Revisa:",
                  file=sys.stderr)
            print("  - que el modo del Probador sea 'Optimizacion' y no una sola pasada",
                  file=sys.stderr)
            print("  - que haya parametros con Inicio/Paso/Fin y la casilla marcada",
                  file=sys.stderr)
            print("  - que el rango de fechas y el simbolo tengan historico",
                  file=sys.stderr)
            print("  - que OnTester no este devolviendo 0 y filtrando todo",
                  file=sys.stderr)
            print("!" * 72, file=sys.stderr)
            print("")

        # --- Tramo reservado de ESTE fichero -------------------------------
        ruta_forward = args.forward if len(args.ruta_xml) == 1 else None
        deducido = False
        if ruta_forward is None:
            ruta_forward = deduce_ruta_forward(ruta_xml)
            deducido = True

        registros_forward = []
        if ruta_forward and os.path.isfile(ruta_forward):
            ruta_forward = os.path.abspath(ruta_forward)
            try:
                registros_forward = carga_informe(ruta_forward)
                rutas_leidas.append(ruta_forward)
                print("Tramo reservado leido: %s (%d filas)"
                      % (ruta_forward, len(registros_forward)))
            except LectorError as err:
                print("AVISO: no se pudo leer el tramo reservado: %s" % err,
                      file=sys.stderr)
                registros_forward = []
        else:
            if ruta_forward is None:
                print("AVISO: %s ya es el tramo reservado (forward); no hay "
                      "nada que cruzar y, sin tramo reservado independiente, "
                      "ninguna combinacion puede aprobarse."
                      % os.path.basename(ruta_xml), file=sys.stderr)
            elif not deducido:
                print("AVISO: no existe el fichero forward indicado: %s"
                      % ruta_forward, file=sys.stderr)
            else:
                print("AVISO: no se encontro el tramo reservado de %s (%s). Se "
                      "continua, pero SIN forward ninguna combinacion puede "
                      "aprobarse." % (os.path.basename(ruta_xml), ruta_forward),
                      file=sys.stderr)

        # --- Puertas de calidad de este fichero ----------------------------
        parciales = construye_candidatos(registros_busqueda, registros_forward,
                                         PUERTAS)
        # Se anota de que barrido viene cada candidato: con varios ficheros el
        # numero de pasada por si solo ya no identifica una combinacion.
        origen = os.path.splitext(os.path.basename(ruta_xml))[0]
        for c in parciales:
            c["origen"] = origen
        candidatos.extend(parciales)

    if total_filas <= 1:
        return 2

    # Con varios barridos fundidos, el orden global lo manda la puntuacion.
    candidatos.sort(key=lambda c: (c.get("puntuacion") is None,
                                   -(c.get("puntuacion") or 0.0)))

    aptas = sum(1 for c in candidatos if c["apta"])

    # --- Escritura del JSON -------------------------------------------------
    salida = {
        "meta": {
            "generado_desde": rutas_leidas,
            "total_combinaciones": len(candidatos),
            "aptas": aptas,
            "puertas": dict(PUERTAS),
        },
        "candidatos": candidatos,
    }

    ruta_salida = os.path.abspath(args.salida)
    try:
        directorio = os.path.dirname(ruta_salida)
        if directorio and not os.path.isdir(directorio):
            os.makedirs(directorio, exist_ok=True)
        with open(ruta_salida, "w", encoding="utf-8") as fichero:
            json.dump(salida, fichero, ensure_ascii=False, indent=2)
    except OSError as err:
        print("ERROR: no se pudo escribir '%s': %s" % (ruta_salida, err),
              file=sys.stderr)
        return 1

    imprime_resumen(candidatos, rutas_leidas, aptas)
    print("JSON escrito en: %s" % ruta_salida)
    return 0


if __name__ == "__main__":
    sys.exit(main())
