//+------------------------------------------------------------------+
//|                                              JuezRobustez.mqh     |
//|  Puntuacion de ROBUSTEZ para OnTester() de un EA en MetaTrader 5. |
//|                                                                  |
//|  FILOSOFIA: lo que se devuelve NO es el beneficio. Es una nota    |
//|  de robustez. Se parte del factor de beneficio (PF) y se castiga  |
//|  cada sintoma tipico de curva sobreajustada: muestra pequena,     |
//|  caida enorme respecto a lo ganado, un unico trade que sostiene   |
//|  toda la curva, meses desiguales y rachas perdedoras mayores de   |
//|  lo que su porcentaje de acierto justifica.                       |
//|  Asi el optimizador genetico persigue sistemas que aguanten, no   |
//|  combinaciones que tuvieron suerte en un tramo del historico.     |
//|                                                                  |
//|  USO:  #include <...\Fabrica\JuezRobustez.mqh>                    |
//|        double OnTester() { return(PuntuacionRobustez()); }        |
//|  Este fichero NO define OnTester y NO declara inputs.             |
//+------------------------------------------------------------------+
#ifndef __JUEZ_ROBUSTEZ_MQH__
#define __JUEZ_ROBUSTEZ_MQH__

//+------------------------------------------------------------------+
//| UMBRALES DEL JUEZ                                                 |
//| Todos juntos y al principio para poder endurecerlos o relajarlos  |
//| sin tocar la logica. Valores de partida deliberadamente estrictos.|
//+------------------------------------------------------------------+

// Muestra minima innegociable: con menos cierres el resultado es anecdota, no evidencia estadistica -> nota cero.
#define MIN_OPS_ABSOLUTO         100

// Ventaja minima sobre el coste operativo: por debajo de este PF el sistema no paga ni el spread -> nota cero.
#define MIN_PF_ABSOLUTO          1.05

// A partir de aqui la muestra se considera comoda; entre el minimo absoluto y este valor se penaliza de forma gradual.
#define MIN_OPS_COMODO           250

// Concentracion maxima tolerada: si la mejor operacion aporta mas de este % del beneficio bruto, la curva depende de un golpe de suerte.
#define MAX_PESO_MEJOR_OP        0.25

// Reparto temporal minimo: proporcion de meses cerrados en positivo SOBRE LOS MESES ABARCADOS
// por la pasada (un mes sin operar cuenta como mes no positivo); por debajo el sistema solo
// funciono en un tramo concreto.
#define MIN_MESES_POSITIVOS      0.55

// Relacion maxima caida/beneficio: arriesgar mas de la mitad de lo ganado es una curva que el usuario real no aguantaria.
#define MAX_DD_SOBRE_BENEFICIO   0.50

// Margen sobre la racha perdedora teorica: se tolera hasta 1.5 veces la esperada para su % de acierto; mas indica inestabilidad.
#define MARGEN_RACHA             1.5

// Meses minimos ABARCADOS por la pasada (del primer cierre al ultimo) para poder juzgar el
// reparto temporal: con menos no hay distribucion que medir -> nota cero.
#define MIN_MESES_ACTIVOS        6

// Tope artificial del PF cuando no hay perdidas (PF infinito o 0 degenerado): evita dividir por cero y premiar un espejismo.
#define PF_TOPE_DEGENERADO       10.0

// Concentracion letal: media curva en una sola operacion es directamente un sistema no valido -> nota cero.
#define PESO_MEJOR_OP_LETAL      0.50

// Epsilon de trabajo para comparaciones y divisiones con numeros en coma flotante.
#define JUEZ_EPS                 0.0000001

//+------------------------------------------------------------------+
//| Contenedor del desglose (para poder auditar cada penalizacion)    |
//+------------------------------------------------------------------+
struct JuezDesglose
{
   int    operaciones;        // STAT_TRADES
   int    cierres;            // cierres realmente contados en el historial
   int    ganadoras;          // cierres con resultado > 0
   int    perdedoras;         // cierres con resultado < 0
   double pf;                 // factor de beneficio ya saneado
   double beneficio;          // beneficio neto de la pasada
   double bruto_gana;         // suma de los cierres positivos
   double bruto_pierde;       // suma (en positivo) de los cierres negativos
   double caida;              // caida maxima de equity en dinero
   double caida_pct;          // caida maxima de equity en porcentaje
   double mejor_op;           // mejor operacion individual
   double peso_mejor;         // mejor_op / bruto_gana
   double prop_meses;         // proporcion de meses en positivo sobre los meses abarcados
   int    meses_activos;      // meses que ABARCA la pasada (del primer al ultimo cierre, huecos incluidos)
   int    racha_max;          // mayor racha de cierres perdedores consecutivos
   double racha_esperada;     // racha teorica para su % de acierto
   double f_muestra;          // factor por tamano de muestra
   double f_caida;            // factor por caida sobre beneficio
   double f_concentracion;    // factor por dependencia de la mejor operacion
   double f_meses;            // factor por reparto mensual
   double f_racha;            // factor por racha perdedora
   double base;               // puntuacion base (PF - 1)
   double puntuacion;         // nota final devuelta al optimizador
   string motivo_cero;        // por que se descarto, si se descarto
};

//+------------------------------------------------------------------+
//| Inicializa el desglose a un estado conocido (codigo defensivo)    |
//+------------------------------------------------------------------+
void JuezResetDesglose(JuezDesglose &d)
{
   d.operaciones     = 0;
   d.cierres         = 0;
   d.ganadoras       = 0;
   d.perdedoras      = 0;
   d.pf              = 0.0;
   d.beneficio       = 0.0;
   d.bruto_gana      = 0.0;
   d.bruto_pierde    = 0.0;
   d.caida           = 0.0;
   d.caida_pct       = 0.0;
   d.mejor_op        = 0.0;
   d.peso_mejor      = 0.0;
   d.prop_meses      = 0.0;
   d.meses_activos   = 0;
   d.racha_max       = 0;
   d.racha_esperada  = 0.0;
   d.f_muestra       = 1.0;
   d.f_caida         = 1.0;
   d.f_concentracion = 1.0;
   d.f_meses         = 1.0;
   d.f_racha         = 1.0;
   d.base            = 0.0;
   d.puntuacion      = 0.0;
   d.motivo_cero     = "";
}

//+------------------------------------------------------------------+
//| Acota un valor al rango [0,1] y neutraliza NaN / infinitos        |
//+------------------------------------------------------------------+
double JuezAcotar01(const double v)
{
   if(!MathIsValidNumber(v)) return(0.0);   // un NaN nunca debe colarse como factor
   if(v < 0.0)               return(0.0);
   if(v > 1.0)               return(1.0);
   return(v);
}

//+------------------------------------------------------------------+
//| Recorre el historial de la pasada y extrae lo que TesterStatistics|
//| no da: concentracion, reparto mensual y racha perdedora maxima.   |
//| Devuelve false si el historial no se puede leer o esta vacio.     |
//+------------------------------------------------------------------+
bool JuezAnalizarHistorial(JuezDesglose &d)
{
   if(!HistorySelect(0, TimeCurrent()))
      return(false);                         // sin historial no hay nada que juzgar

   int total = HistoryDealsTotal();
   if(total <= 0)
      return(false);

   // Acumuladores por mes: claves ano*12+(mes-1) (indice lineal, para poder restar meses)
   // y su resultado sumado.
   long   claves[];
   double sumas[];
   int    n_meses = 0;
   ArrayResize(claves, 0);
   ArrayResize(sumas,  0);

   // Comisiones de APERTURA pendientes de imputar, indexadas por posicion. En MT5 el
   // simulador suele cobrar la comision tambien (o solo) en el deal de entrada, que no
   // lleva resultado; si no se recoge aqui, la mitad del coste nunca se contabiliza y
   // operaciones realmente perdedoras se clasificarian como ganadoras.
   // La lista solo guarda posiciones aun sin cerrar, asi que se mantiene muy corta.
   long   pend_pos[];
   double pend_coste[];
   int    n_pend = 0;
   ArrayResize(pend_pos,   0);
   ArrayResize(pend_coste, 0);

   int racha_actual = 0;

   for(int i = 0; i < total; i++)
   {
      ulong ticket = HistoryDealGetTicket(i);
      if(ticket == 0) continue;              // deal ilegible: se ignora, no se aborta

      // Solo los deals de compra/venta (se descartan balance, credito, comisiones sueltas...).
      long tipo = HistoryDealGetInteger(ticket, DEAL_TYPE);
      if(tipo != DEAL_TYPE_BUY && tipo != DEAL_TYPE_SELL) continue;

      long entrada = HistoryDealGetInteger(ticket, DEAL_ENTRY);
      long pos_id  = HistoryDealGetInteger(ticket, DEAL_POSITION_ID);

      // Las aperturas no tienen resultado economico, pero si comision: se anota a la espera
      // del cierre de esa misma posicion y se sale sin contarlas como operacion.
      if(entrada == DEAL_ENTRY_IN)
      {
         double com_in = HistoryDealGetDouble(ticket, DEAL_COMMISSION);
         if(!MathIsValidNumber(com_in) || com_in == 0.0) continue;

         int q = -1;
         for(int k = n_pend - 1; k >= 0; k--)
            if(pend_pos[k] == pos_id) { q = k; break; }

         if(q < 0)
         {
            n_pend++;
            ArrayResize(pend_pos,   n_pend);
            ArrayResize(pend_coste, n_pend);
            q             = n_pend - 1;
            pend_pos[q]   = pos_id;
            pend_coste[q] = 0.0;
         }
         pend_coste[q] += com_in;
         continue;
      }

      // Cierres. Ademas de OUT y OUT_BY se acepta INOUT: en cuentas de neteo una reversion
      // cierra el tramo anterior y abre el nuevo en UN SOLO deal, y ese deal es el que lleva
      // el resultado de lo cerrado. Descartarlo dejaba fuera del analisis todo el historico
      // de un EA de reversion (peso_mejor ~1.0 y nota cero por un motivo falso).
      if(entrada != DEAL_ENTRY_OUT && entrada != DEAL_ENTRY_OUT_BY && entrada != DEAL_ENTRY_INOUT)
         continue;

      // Resultado neto real de la operacion: beneficio + swap + comisiones (cierre y apertura).
      double res = HistoryDealGetDouble(ticket, DEAL_PROFIT)
                 + HistoryDealGetDouble(ticket, DEAL_SWAP)
                 + HistoryDealGetDouble(ticket, DEAL_COMMISSION);
      if(!MathIsValidNumber(res)) continue;

      // Imputa (y libera) la comision de apertura pendiente de esta posicion. Con cierres
      // parciales se imputa entera en el primero: el total sigue cuadrando con el tester.
      for(int k = n_pend - 1; k >= 0; k--)
      {
         if(pend_pos[k] != pos_id) continue;
         res          += pend_coste[k];
         pend_pos[k]   = pend_pos[n_pend - 1];    // borrado por intercambio con el ultimo
         pend_coste[k] = pend_coste[n_pend - 1];
         n_pend--;
         ArrayResize(pend_pos,   n_pend);
         ArrayResize(pend_coste, n_pend);
         break;
      }
      if(!MathIsValidNumber(res)) continue;

      d.cierres++;

      if(res > 0.0)
      {
         d.ganadoras++;
         d.bruto_gana += res;
         if(res > d.mejor_op) d.mejor_op = res;   // mejor operacion individual
         racha_actual = 0;                        // una ganadora corta la racha
      }
      else if(res < 0.0)
      {
         d.perdedoras++;
         d.bruto_pierde += -res;
         racha_actual++;                          // racha de perdedoras consecutivas
         if(racha_actual > d.racha_max) d.racha_max = racha_actual;
      }
      // Un cierre exactamente a cero no gana ni pierde: ni suma ni rompe la racha.

      // Reparto mensual: el historial ya viene en orden cronologico, pero agrupamos por clave
      // para no depender de ello.
      long t_raw = HistoryDealGetInteger(ticket, DEAL_TIME);
      if(t_raw <= 0) continue;               // fecha ilegible: no ensucia la rejilla de meses

      datetime t = (datetime)t_raw;
      MqlDateTime st;
      TimeToStruct(t, st);
      // Indice lineal de mes para poder medir distancias: ano*12 + (mes-1).
      long clave = (long)st.year * 12 + (long)st.mon - 1;

      int idx = -1;
      for(int k = 0; k < n_meses; k++)
         if(claves[k] == clave) { idx = k; break; }

      if(idx < 0)
      {
         n_meses++;
         ArrayResize(claves, n_meses);
         ArrayResize(sumas,  n_meses);
         idx          = n_meses - 1;
         claves[idx]  = clave;
         sumas[idx]   = 0.0;
      }
      sumas[idx] += res;
   }

   // Proporcion de meses cerrados en positivo.
   //
   // CAMBIO DE DENOMINADOR: antes se dividia entre los meses en los que hubo cierres, de modo
   // que un sistema que solo opero en 6 meses de los 96 del periodo salia con reparto perfecto
   // (prop_meses = 1.0, f_meses = 1.0) y los huecos eran invisibles. Eso contradice el proposito
   // de esta penalizacion, que es castigar la CONCENTRACION temporal. Ahora el denominador es el
   // numero de meses que ABARCA la pasada: del primer cierre al ultimo, ambos incluidos y
   // contando los meses intermedios sin actividad, que cuentan como meses no positivos.
   // MIN_MESES_ACTIVOS se exige sobre ese mismo intervalo abarcado.
   if(n_meses > 0)
   {
      long clave_min = claves[0];
      long clave_max = claves[0];
      int  positivos = 0;

      for(int k = 0; k < n_meses; k++)
      {
         if(claves[k] < clave_min) clave_min = claves[k];
         if(claves[k] > clave_max) clave_max = claves[k];
         if(sumas[k]  > 0.0)       positivos++;
      }

      int abarcados = (int)(clave_max - clave_min) + 1;   // huecos intermedios incluidos
      if(abarcados < n_meses) abarcados = n_meses;        // defensivo: nunca menos que los vistos

      d.meses_activos = abarcados;
      d.prop_meses    = JuezAcotar01((double)positivos / (double)abarcados);
   }

   // Peso de la mejor operacion sobre el beneficio bruto.
   if(d.bruto_gana > JUEZ_EPS)
      d.peso_mejor = d.mejor_op / d.bruto_gana;
   else
      d.peso_mejor = 1.0;      // sin beneficio bruto, la concentracion es total por definicion

   return(d.cierres > 0);
}

//+------------------------------------------------------------------+
//| Imprime el desglose completo cuando NO estamos optimizando        |
//| (en optimizacion imprimir seria ruido y lastre de rendimiento).   |
//| La ultima linea "JUEZ|..." esta pensada para parsearse luego.     |
//+------------------------------------------------------------------+
void JuezImprimirDesglose(const JuezDesglose &d)
{
   if((bool)MQLInfoInteger(MQL_OPTIMIZATION)) return;   // silencio durante la optimizacion

   Print("===== JUEZ DE ROBUSTEZ =====");
   Print("  Operaciones (STAT_TRADES): ", d.operaciones,
         "   cierres analizados: ", d.cierres,
         "   ganadoras: ", d.ganadoras,
         "   perdedoras: ", d.perdedoras);
   Print("  Factor de beneficio (PF) : ", DoubleToString(d.pf, 3),
         "   (minimo exigido ", DoubleToString(MIN_PF_ABSOLUTO, 2), ")");
   Print("  Beneficio neto           : ", DoubleToString(d.beneficio, 2),
         "   bruto+ ", DoubleToString(d.bruto_gana, 2),
         "   bruto- ", DoubleToString(d.bruto_pierde, 2));
   Print("  Caida maxima de equity   : ", DoubleToString(d.caida, 2),
         " (", DoubleToString(d.caida_pct, 2), "%)");
   Print("  Mejor operacion          : ", DoubleToString(d.mejor_op, 2),
         "   peso sobre bruto: ", DoubleToString(d.peso_mejor * 100.0, 2), "%",
         "   (maximo ", DoubleToString(MAX_PESO_MEJOR_OP * 100.0, 1), "%)");
   Print("  Meses en positivo        : ", DoubleToString(d.prop_meses * 100.0, 2), "%",
         "   sobre ", d.meses_activos, " meses abarcados (huecos incluidos)",
         "   (minimo ", DoubleToString(MIN_MESES_POSITIVOS * 100.0, 1), "%)");
   Print("  Racha perdedora maxima   : ", d.racha_max,
         "   esperada aprox: ", DoubleToString(d.racha_esperada, 2),
         "   tolerada: ", DoubleToString(d.racha_esperada * MARGEN_RACHA, 2));
   Print("  --- factores de penalizacion (1.0 = sin castigo) ---");
   Print("   f_muestra       (pocas operaciones)      = ", DoubleToString(d.f_muestra, 4));
   Print("   f_caida         (caida / beneficio)      = ", DoubleToString(d.f_caida, 4));
   Print("   f_concentracion (dependencia mejor op.)  = ", DoubleToString(d.f_concentracion, 4));
   Print("   f_meses         (reparto mensual)        = ", DoubleToString(d.f_meses, 4));
   Print("   f_racha         (racha vs esperada)      = ", DoubleToString(d.f_racha, 4));
   Print("  Puntuacion base (PF-1)   : ", DoubleToString(d.base, 4));
   if(StringLen(d.motivo_cero) > 0)
      Print("  DESCARTADA -> ", d.motivo_cero);
   Print("  PUNTUACION FINAL         : ", DoubleToString(d.puntuacion, 6));

   // Linea compacta para parsear con scripts externos (separador ';').
   // Campos: ops;cierres;pf;beneficio;caida;caida_pct;peso_mejor;prop_meses;meses_activos;
   //         racha_max;racha_esperada;f_muestra;f_caida;f_concentracion;f_meses;f_racha;base;puntuacion;motivo
   string linea = "JUEZ|" +
      IntegerToString(d.operaciones)            + ";" +
      IntegerToString(d.cierres)                + ";" +
      DoubleToString(d.pf, 4)                   + ";" +
      DoubleToString(d.beneficio, 2)            + ";" +
      DoubleToString(d.caida, 2)                + ";" +
      DoubleToString(d.caida_pct, 2)            + ";" +
      DoubleToString(d.peso_mejor, 4)           + ";" +
      DoubleToString(d.prop_meses, 4)           + ";" +
      IntegerToString(d.meses_activos)          + ";" +
      IntegerToString(d.racha_max)              + ";" +
      DoubleToString(d.racha_esperada, 2)       + ";" +
      DoubleToString(d.f_muestra, 4)            + ";" +
      DoubleToString(d.f_caida, 4)              + ";" +
      DoubleToString(d.f_concentracion, 4)      + ";" +
      DoubleToString(d.f_meses, 4)              + ";" +
      DoubleToString(d.f_racha, 4)              + ";" +
      DoubleToString(d.base, 4)                 + ";" +
      DoubleToString(d.puntuacion, 6)           + ";" +
      (StringLen(d.motivo_cero) > 0 ? d.motivo_cero : "OK");
   Print(linea);
}

//+------------------------------------------------------------------+
//| Cierra el juicio: valida el numero, lo guarda e imprime desglose  |
//+------------------------------------------------------------------+
double JuezCerrar(JuezDesglose &d, const double valor, const string motivo)
{
   double v = valor;
   if(!MathIsValidNumber(v)) v = 0.0;   // NaN / infinito nunca salen de aqui
   if(v < 0.0)               v = 0.0;   // la nota jamas es negativa
   d.puntuacion  = v;
   if(StringLen(motivo) > 0) d.motivo_cero = motivo;
   JuezImprimirDesglose(d);
   return(v);
}

//+------------------------------------------------------------------+
//| FUNCION PUBLICA: nota de robustez para devolver desde OnTester()  |
//+------------------------------------------------------------------+
double PuntuacionRobustez()
{
   JuezDesglose d;
   JuezResetDesglose(d);

   //--- 1) Estadisticas base de la pasada ------------------------------------
   d.operaciones = (int)TesterStatistics(STAT_TRADES);
   d.beneficio   =      TesterStatistics(STAT_PROFIT);
   d.caida       =      TesterStatistics(STAT_EQUITY_DD);
   d.caida_pct   =      TesterStatistics(STAT_EQUITYDD_PERCENT);

   double bruto_gana_stat   = TesterStatistics(STAT_GROSS_PROFIT);
   double bruto_pierde_stat = MathAbs(TesterStatistics(STAT_GROSS_LOSS)); // llega en negativo
   int    gana_stat         = (int)TesterStatistics(STAT_PROFIT_TRADES);
   int    pierde_stat       = (int)TesterStatistics(STAT_LOSS_TRADES);

   // PF saneado: STAT_PROFIT_FACTOR devuelve 0 o infinito en casos degenerados (sin perdidas),
   // asi que NO se usa su valor: el PF se recalcula siempre a mano desde el bruto ganado y
   // perdido y se topa en un valor razonable en lugar de dividir por cero.
   double pf = 0.0;
   if(bruto_pierde_stat <= JUEZ_EPS)
      pf = (bruto_gana_stat > JUEZ_EPS) ? PF_TOPE_DEGENERADO : 0.0;
   else
      pf = bruto_gana_stat / bruto_pierde_stat;
   if(!MathIsValidNumber(pf) || pf < 0.0) pf = 0.0;
   if(pf > PF_TOPE_DEGENERADO)            pf = PF_TOPE_DEGENERADO;
   d.pf = pf;

   //--- 2) Filtros absolutos: combinaciones que deben desaparecer de la busqueda
   // Muestra insuficiente: sin operaciones suficientes no se demuestra nada.
   if(d.operaciones < MIN_OPS_ABSOLUTO)
      return(JuezCerrar(d, 0.0, "CERO: menos de " + IntegerToString(MIN_OPS_ABSOLUTO) + " operaciones"));

   // Beneficio nulo o negativo: no hay nada que puntuar (y evita dividir por cero mas abajo).
   if(d.beneficio <= 0.0)
      return(JuezCerrar(d, 0.0, "CERO: beneficio neto <= 0"));

   // Sin ventaja minima sobre el coste operativo.
   if(d.pf < MIN_PF_ABSOLUTO)
      return(JuezCerrar(d, 0.0, "CERO: PF por debajo de " + DoubleToString(MIN_PF_ABSOLUTO, 2)));

   //--- 3) Analisis del historial real de operaciones -------------------------
   if(!JuezAnalizarHistorial(d))
      return(JuezCerrar(d, 0.0, "CERO: historial de operaciones ilegible o vacio"));

   // Si el historial no aporta ganadoras/perdedoras, se cae a las estadisticas del tester.
   if(d.ganadoras + d.perdedoras <= 0)
   {
      d.ganadoras   = gana_stat;
      d.perdedoras  = pierde_stat;
      d.bruto_gana  = bruto_gana_stat;
      d.bruto_pierde= bruto_pierde_stat;

      // Si se repone la contabilidad desde el tester hay que reponer tambien la concentracion:
      // al llegar aqui el historial dejo mejor_op = 0 y peso_mejor = 1.0 "por definicion", con lo
      // que el filtro letal de mas abajo disparaba SIEMPRE y descartaba la pasada con un motivo
      // falso ("la mejor operacion aporta mas del 50% del bruto") cuando la causa real es que no
      // hubo ningun cierre clasificable. Se recalcula con la mejor operacion del tester y, si
      // tampoco hay dato medible, se neutraliza el factor en lugar de castigar a ciegas.
      d.mejor_op = MathAbs(TesterStatistics(STAT_MAX_PROFITTRADE));
      if(!MathIsValidNumber(d.mejor_op) || d.mejor_op < 0.0) d.mejor_op = 0.0;

      if(d.bruto_gana > JUEZ_EPS && d.mejor_op > 0.0)
         d.peso_mejor = JuezAcotar01(d.mejor_op / d.bruto_gana);
      else
         d.peso_mejor = 0.0;   // sin dato de concentracion: no se penaliza por este concepto
   }

   // Reparto temporal no medible: la pasada abarca menos meses de los exigidos.
   if(d.meses_activos < MIN_MESES_ACTIVOS)
      return(JuezCerrar(d, 0.0, "CERO: la pasada solo abarca " + IntegerToString(d.meses_activos) + " meses"));

   // Concentracion letal: media curva en una sola operacion.
   if(d.peso_mejor > PESO_MEJOR_OP_LETAL)
      return(JuezCerrar(d, 0.0, "CERO: la mejor operacion aporta mas del " +
                                DoubleToString(PESO_MEJOR_OP_LETAL * 100.0, 0) + "% del bruto"));

   //--- 4) PENALIZACION 1: muestra pequena ------------------------------------
   // Entre el minimo absoluto y el tamano comodo, el castigo se diluye linealmente de 0.3 a 1.0:
   // 120 operaciones valen, pero no valen lo mismo que 400.
   if(d.operaciones >= MIN_OPS_COMODO)
      d.f_muestra = 1.0;
   else
   {
      double rango = (double)(MIN_OPS_COMODO - MIN_OPS_ABSOLUTO);
      if(rango <= 0.0) d.f_muestra = 1.0;
      else             d.f_muestra = 0.3 + 0.7 * ((double)(d.operaciones - MIN_OPS_ABSOLUTO) / rango);
   }
   d.f_muestra = JuezAcotar01(d.f_muestra);

   //--- 5) PENALIZACION 2: caida maxima alta respecto al beneficio -------------
   // Ganar 1000 sufriendo 900 de caida no es un sistema operable: se castiga la razon caida/beneficio.
   double razon_dd = d.caida / MathMax(d.beneficio, JUEZ_EPS);
   if(!MathIsValidNumber(razon_dd) || razon_dd < 0.0) razon_dd = 0.0;
   if(razon_dd > MAX_DD_SOBRE_BENEFICIO)
      d.f_caida = JuezAcotar01(MAX_DD_SOBRE_BENEFICIO / MathMax(razon_dd, JUEZ_EPS));
   else
      d.f_caida = 1.0;

   //--- 6) PENALIZACION 3: dependencia de la mejor operacion -------------------
   // Caida cuadratica: pasarse del umbral de concentracion se paga muy caro, porque ese
   // beneficio no se repetira fuera de la muestra.
   if(d.peso_mejor > MAX_PESO_MEJOR_OP)
   {
      double r = MAX_PESO_MEJOR_OP / MathMax(d.peso_mejor, JUEZ_EPS);
      d.f_concentracion = JuezAcotar01(r * r);
   }
   else
      d.f_concentracion = 1.0;

   //--- 7) PENALIZACION 4: meses desiguales ------------------------------------
   // Un sistema robusto gana repartido en el tiempo; si solo gano en unos pocos meses,
   // el castigo tambien es cuadratico.
   if(d.prop_meses < MIN_MESES_POSITIVOS)
   {
      double r = d.prop_meses / MathMax(MIN_MESES_POSITIVOS, JUEZ_EPS);
      d.f_meses = JuezAcotar01(r * r);
   }
   else
      d.f_meses = 1.0;

   //--- 8) PENALIZACION 5: rachas en contra mayores de lo esperado -------------
   // Para un acierto p y N operaciones, la racha perdedora maxima esperada es ~ log(N)/(-log(1-p)).
   // Si la observada supera MARGEN_RACHA veces esa cifra, la distribucion de resultados no es la
   // que aparenta y se castiga proporcionalmente. Se protegen p=0, p=1 y N<=1.
   int    n_ops = d.ganadoras + d.perdedoras;
   double p     = (n_ops > 0) ? (double)d.ganadoras / (double)n_ops : 0.0;

   if(n_ops > 1 && p > JUEZ_EPS && p < 1.0 - JUEZ_EPS)
   {
      double den = -MathLog(1.0 - p);               // > 0 con p en (0,1)
      if(den > JUEZ_EPS)
      {
         d.racha_esperada = MathLog((double)n_ops) / den;
         if(!MathIsValidNumber(d.racha_esperada) || d.racha_esperada < 1.0)
            d.racha_esperada = 1.0;                 // suelo sensato: siempre cabe una perdedora

         double tolerada = d.racha_esperada * MARGEN_RACHA;
         if((double)d.racha_max > tolerada && d.racha_max > 0)
            d.f_racha = JuezAcotar01(tolerada / (double)d.racha_max);
         else
            d.f_racha = 1.0;
      }
   }
   else
   {
      // p=1 (sin perdedoras) o muestra degenerada: no hay racha que comparar, no se castiga aqui.
      d.racha_esperada = 0.0;
      d.f_racha        = 1.0;
   }

   //--- 9) Puntuacion base y composicion final ---------------------------------
   // Base = PF - 1: un PF de 1.0 puntua 0 y la escala queda intuitiva (0.5 = PF 1.5 sin castigos).
   d.base = d.pf - 1.0;
   if(d.base < 0.0) d.base = 0.0;

   double nota = d.base
               * d.f_muestra
               * d.f_caida
               * d.f_concentracion
               * d.f_meses
               * d.f_racha;

   // Blindaje final: finita y no negativa SIEMPRE.
   if(!MathIsValidNumber(nota) || nota < 0.0) nota = 0.0;

   return(JuezCerrar(d, nota, ""));
}

#endif // __JUEZ_ROBUSTEZ_MQH__
//+------------------------------------------------------------------+
