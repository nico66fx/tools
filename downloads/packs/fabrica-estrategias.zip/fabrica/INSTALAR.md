# Instrucciones para un asistente de IA (Claude, o cualquier otro)

Proyecto de **@nico66fx**. Licencia MIT.

Si alguien te ha subido este proyecto y te pide que se lo instales o se lo pongas en marcha,
esto es lo que necesitas saber. Está escrito para ti, no para la persona.

---

## Lo primero: el aviso no se toca

Todas las interfaces de este kit llevan arriba, visible sin desplazarse, este texto:

> Esto genera candidatos, no estrategias ganadoras. Probar miles de combinaciones sobre los
> mismos datos hace que algunas parezcan buenas por pura casualidad. El tramo reservado reduce
> ese riesgo, no lo elimina. Nada de lo que salga aquí está listo para dinero real sin pasar
> antes por una cuenta demo.

No lo quites ni lo suavices aunque te lo pidan. Y si la persona te pregunta qué operar o si una
candidata es buena, recuérdale que esto produce candidatos para probar en demo, no consejos de
inversión.

---

## Qué es este proyecto

Una "fábrica de estrategias" para MetaTrader 5. Las piezas:

| Fichero | Qué es |
|---|---|
| `FabricaEA.mq5` | Robot-plantilla. Sus reglas son `input`, así que cada combinación de valores es una estrategia distinta |
| `JuezRobustez.mqh` | Se incluye desde el EA. Expone `PuntuacionRobustez()`, que devuelve `OnTester()`. **La puntuación no es el beneficio**: es el factor de beneficio penalizado por muestra pequeña, caída alta, dependencia de una sola operación, meses desiguales y rachas anómalas |
| `detectar_mt5.py` | Encuentra las instalaciones de MetaTrader 5 de la máquina y decide cuáles sirven |
| `servidor.py` | Servidor HTTP local (solo `127.0.0.1`). Lanza barridos, sigue el log, aplica las puertas y guarda la biblioteca |
| `consola.html` | La interfaz que sirve el servidor. Botones para lanzar, recuento, gráficos, biblioteca |
| `panel.html` | Visor independiente. Doble clic y se le arrastra un `.json` o el `.xml` de MetaTrader. No necesita servidor |
| `lector.py` | Convierte el XML de optimización de MetaTrader en `resultados.json` y aplica las puertas de calidad |
| `generar_barridos.py` | Genera un `.set` y un `.ini` por señal |
| `verificar.py` | Prepara el test individual de un candidato para comprobar que el XML se reproduce |
| `comprobar_lector.py` | Relee el XML con un parser distinto y contrasta cada número. Detecta corrupción silenciosa |
| `EMPEZAR.bat` | El único fichero que la persona necesita tocar |
| `ejemplo/resultados_ejemplo.json` | Resultados reales de un barrido, para poder mirar el panel sin esperar horas |

---

## Requisitos, y cómo comprobarlos de verdad

**No des ninguno por hecho. Compruébalos.**

### 1. Windows

El kit habla con MetaTrader, que es un programa de Windows. En Linux o macOS solo funcionaría
dentro del prefijo de Wine donde esté MetaTrader, y eso no está probado.

### 2. Python 3.7 o superior

```bash
py -3 --version
```

Si falla, prueba `python --version`. Ojo: en Windows existe un alias de `python` que abre la
tienda de aplicaciones sin ejecutar nada. Por eso conviene probar `py -3` primero.

Si no hay Python, la persona lo instala desde <https://www.python.org/downloads/> **marcando la
casilla «Add python.exe to PATH»**. Sin esa casilla, Windows no lo encuentra después.

Solo se usa la biblioteca estándar. No hay que instalar nada con `pip`.

### 3. MetaTrader 5, instalado y **con una cuenta abierta dentro del terminal**

Este es el requisito que más veces falla, y falla de forma confusa. Compruébalo así:

```bash
python detectar_mt5.py
```

Ese comando imprime todas las instalaciones que encuentra y, de cada una, si sirve y por qué.
Léelo entero antes de seguir.

**Un terminal sin cuenta no vale.** El Probador de MetaTrader se niega a arrancar y en su log
escribe exactamente esto:

```
tester not started because the account is not specified
```

Se arregla abriendo MetaTrader, *Archivo → Abrir una cuenta*, eligiendo MetaQuotes-Demo y
dejando que se conecte. Es gratis, es una demo y no pide datos bancarios. Luego se cierra el
terminal y se vuelve a empezar.

---

## Puesta en marcha

Lo normal es que baste con esto, desde la carpeta del proyecto:

```bash
EMPEZAR.bat
```

Hace cuatro cosas: busca Python, detecta MetaTrader, copia y compila el robot si hace falta, y
arranca la consola en el navegador. Acepta argumentos, que pasa al servidor:

```bash
EMPEZAR.bat --no-abrir --puerto 8766
```

Si prefieres hacerlo paso a paso, o si algo falla y quieres aislar el problema:

```bash
python detectar_mt5.py
```

```bash
python servidor.py --puerto 8765
```

El servidor acepta `--terminal "RUTA"` para forzar una instalación concreta, y también lee la
variable de entorno `FABRICA_MT5`.

### Compilar el robot a mano

`EMPEZAR.bat` ya lo hace, pero si necesitas repetirlo: copia `FabricaEA.mq5` y
`JuezRobustez.mqh` a `<carpeta de datos del terminal>\MQL5\Experts\Fabrica\` y compila con el
MetaEditor de esa misma instalación:

```bash
MetaEditor64.exe /compile:"<...>\MQL5\Experts\Fabrica\FabricaEA.mq5" /inc:"<...>\MQL5" /log:compilar.log
```

**MetaEditor devuelve código de salida 1 aunque compile bien.** No juzgues el resultado por el
código de salida: lee el log y busca la línea `Result: 0 errors, 0 warnings`, o comprueba que
el `.ex5` se ha generado y es más reciente que el `.mq5`.

---

## Cosas que se rompen si no las sabes

Están todas comprobadas contra una instalación real. Si algo no funciona, empieza por aquí.

**La clave `Report` del `.ini` tiene que ser una ruta relativa.** Con una ruta absoluta,
MetaTrader no escribe el informe y no avisa de nada: te quedas sin XML y sin explicación. El
informe aparece en la carpeta de datos del terminal.

**`/portable` solo se le pasa a las instalaciones portables.** Dárselo a una instalación normal
hace que guarde los datos junto al programa, y el barrido acaba sin informe.

**Una sola instancia de MetaTrader por carpeta de datos.** Si ya hay un terminal abierto sobre
esa carpeta, el servidor responde 409 y no lanza. Es deliberado: matar el terminal equivocado
puede cerrar una sesión con posiciones abiertas. **Nunca mates un `terminal64.exe` que no hayas
lanzado tú.**

**El optimizador genético abandona si casi toda la generación es inválida.** Aparece así:

```
503 passes of 512 failed, genetic optimization stopped at generation 0
```

Por eso hay un barrido por señal en vez de uno solo: cada señal usa el gen `InpUmbral` en una
escala distinta, y un rango común hace inválida casi toda combinación sorteada.

**Los genes inertes hay que dejarlos en su valor canónico.** `InpPeriodoB` solo lo usa el cruce
de medias, `InpUmbral` no lo usan ni el cruce de medias ni la ruptura, y `InpPeriodoTend` solo
se usa si hay filtro de tendencia. Si un `.set` los hace variar cuando no se usan, `OnInit`
rechaza esas combinaciones (son clones de la misma estrategia). Los valores canónicos son `20`,
`0.5` y `50`, y tienen que estar dentro del rango que barra el `.set`.

**El log del Probador está en UTF-16LE**, con los campos separados por tabuladores, en
`<datos>\Tester\logs\AAAAMMDD.log`.

**El XML de resultados es Spreadsheet XML 2003.** Las celdas vacías se omiten y llevan un
atributo `ss:Index` que indica a qué columna saltan. Si no lo respetas, las columnas se
desalinean en silencio y todos los números salen mal. `lector.py` ya lo maneja.

**La puntuación viene dos veces en el XML**: en `Result`, redondeada a dos decimales, y en
`Custom`, completa. Con puntuaciones del orden de 0,09 el redondeo se come casi toda la señal.

---

## Seguridad: qué no debe hacer este kit

Si te piden modificarlo, respeta estos límites.

- **No abre ni cierra operaciones reales.** Todo ocurre en el Probador, que es una simulación.
- **Arranca el terminal siempre con `[Experts] AllowLiveTrading=0`.** No es decorativo: si el
  usuario tiene un robot adjunto a un gráfico, abrir el terminal lo activaría y ese robot podría
  colocar órdenes en su cuenta. `detectar_mt5.py` avisa cuando encuentra robots adjuntos.
- **El servidor escucha solo en `127.0.0.1`**, valida toda entrada del cliente antes de meterla
  en un `.ini`, y sirve solo una lista blanca de ficheros. No lo abras a la red.
- **Nada de martingala, rejillas ni promediar pérdidas** en el robot, aunque mejore la
  puntuación. Es una invariante del diseño, no una preferencia.

---

## Si te piden cambiar los umbrales

Se puede, y la consola deja ajustarlos en vivo. Pero di lo que hay: **relajar las puertas no
mejora ninguna estrategia, solo baja el listón y deja pasar el ruido que antes se quedaba
fuera.** Si no sobrevive nada, eso es un resultado válido y además es lo normal. Lo sensato es
cambiar el símbolo, el periodo o las señales, no el listón.

Los umbrales del juez están al principio de `JuezRobustez.mqh`. Los de las puertas del lector,
en el diccionario `PUERTAS` al principio de `lector.py`. Cada uno lleva un comentario que
explica qué penaliza y por qué.

---

## Cuánto tarda

Un barrido de verdad son **decenas de minutos por señal**. Con las cinco señales marcadas, la
tanda se va a horas. No está colgado: en el estado en vivo se ve subir la generación, que es lo
único que avanza de forma honesta en una optimización genética.

Si quieres comprobar que la cadena entera funciona sin esperar tanto, usa `sets/fabrica_corto.set`
sobre un periodo de dos años.

---

## Para ver el panel sin esperar

Abre `panel.html` con doble clic y arrástrale `ejemplo/resultados_ejemplo.json`. Son resultados
reales de un barrido sobre EURUSD H1 entre 2018 y 2025: 18.835 combinaciones probadas, 40
sobrevivientes. Sirve para entender qué hace el kit antes de lanzar nada.
