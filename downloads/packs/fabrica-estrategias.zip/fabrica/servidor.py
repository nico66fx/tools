# -*- coding: utf-8 -*-
"""
servidor.py -- El motor de la fabrica, manejable desde el navegador.

POR QUE EXISTE ESTE FICHERO
---------------------------
Una pagina abierta con file:// no puede lanzar un programa. Nunca. Es una
frontera del navegador, no un descuido: si una pagina local pudiera arrancar
ejecutables, cualquier HTML que te llegara por correo seria un troyano.
Por eso, para que un boton de la consola pueda arrancar MetaTrader, hace falta
alguien que escuche del lado del sistema operativo. Eso es este servidor: un
proceso Python, en tu propia maquina, escuchando SOLO en 127.0.0.1, que recibe
peticiones de la pagina y traduce las que son legitimas en trabajo real.

QUE HACE
--------
  - Mantiene una COLA de barridos y UN solo hilo trabajador. Nunca lanza dos
    terminales a la vez: MetaTrader no admite dos instancias sobre la misma
    carpeta de datos, y si lo intentas la segunda muere o corrompe la primera.
  - Genera el .set y el .ini de cada trabajo, lanza el terminal (con /portable
    solo si el terminal elegido es portable), sigue su progreso leyendo el log
    del Probador en vivo, y al acabar recoge el XML del informe.
  - Cuando termina la tanda entera, recalcula los resultados el solo.
  - Mantiene una BIBLIOTECA persistente de supervivientes, que se acumula
    entre tandas y deduplica por la huella de los genes.
  - Sabe volver a pasar un candidato por el Probador como test individual
    para comprobar que la fila del XML se reproduce de verdad.

UNA SOLA FUENTE DE VERDAD
-------------------------
Este fichero NO interpreta XML ni decide que es apto: para eso importa
lector.py, que ya esta probado. Tampoco inventa los rangos de los genes:
importa las tablas de generar_barridos.py. Si el servidor duplicara esa
logica, tarde o temprano el panel y el servidor dirian cosas distintas del
mismo barrido, y no habria manera de saber cual de los dos miente.

DONDE ESTA METATRADER
---------------------
No se sabe de antemano y no se inventa: lo busca detectar_mt5 al arrancar,
entre las instalaciones que haya en esta maquina, y se queda con la mejor. Se
puede mandar a mano con --terminal o con la variable de entorno FABRICA_MT5, y
se puede cambiar con la consola abierta desde /api/terminal.

Solo biblioteca estandar. Python 3.

Uso:
    python servidor.py [--puerto 8765] [--no-abrir] [--terminal RUTA]
"""

from __future__ import annotations

import argparse
import collections
import ctypes
import ctypes.wintypes as wintypes
import datetime as dt
import glob
import hashlib
import io
import json
import os
import re
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs


# ---------------------------------------------------------------------------
# RUTAS DEL ENTORNO
# ---------------------------------------------------------------------------
# La carpeta del PROYECTO es la de este mismo fichero. Nunca una ruta absoluta
# escrita a mano: esto tiene que arrancar igual en el disco de cualquiera.
RAIZ = os.path.dirname(os.path.abspath(__file__))
if RAIZ not in sys.path:
    sys.path.insert(0, RAIZ)

# Carpeta de datos del terminal de MetaTrader. Todo lo que MetaTrader escribe
# por su cuenta (informes, logs, cache) cuelga de aqui.
#
# NO ESTA CLAVADA. La busca detectar_mt5 al arrancar, y se puede mandar a mano
# con --terminal o con la variable de entorno FABRICA_MT5. Estas variables las
# rellena aplica_terminal() antes de que exista el motor, y pueden cambiar en
# caliente desde /api/terminal; por eso todo el fichero las LEE en el momento
# de usarlas y nadie se guarda una copia.
TERMINAL = None          # la ficha completa que devuelve detectar_mt5
MT5_DIR = ""             # carpeta de datos
MT5_EXE = ""             # terminal64.exe
MT5_SETS = ""            # MQL5\Profiles\Tester: donde MetaTrader lee los .set
MT5_LOGS_TESTER = ""     # Tester\logs: el log que se sigue en vivo
MT5_TESTER = ""          # Tester: dentro estan los agentes y sus logs
MT5_PORTABLE = False     # si va con /portable o no

# Carpetas del proyecto. El servidor NO escribe fuera de estas dos raices: la
# carpeta del proyecto y la carpeta Tester del terminal elegido.
DIR_SETS = os.path.join(RAIZ, "sets")
DIR_LOGS = os.path.join(RAIZ, "logs")
DIR_INFORMES = os.path.join(RAIZ, "informes")
RUTA_BIBLIOTECA = os.path.join(DIR_INFORMES, "biblioteca.json")
RUTA_REGISTRO = os.path.join(DIR_INFORMES, "barridos.json")
RUTA_RESULTADOS = os.path.join(DIR_INFORMES, "resultados.json")
RUTA_VERIFICACION = os.path.join(DIR_INFORMES, "verificacion.json")
# Resultados de un barrido de referencia, para que la consola tenga algo que
# ensenar nada mas instalarla. Un panel a cero no se distingue de un panel roto.
RUTA_EJEMPLO = os.path.join(RAIZ, "ejemplo", "resultados_ejemplo.json")

# Ficheros estaticos que se pueden servir. LISTA BLANCA EXPLICITA: jamas se
# construye una ruta de disco con texto que venga del cliente. Esa es
# exactamente la receta del "path traversal" (pedir /../../../etc/passwd y que
# el servidor lo sirva tan contento).
ESTATICOS = {
    "/": "consola.html",
    "/consola.html": "consola.html",
    "/panel.html": "panel.html",
}

# Tope de tamano del cuerpo de una peticion. Un cliente que mande 900 MB no
# debe poder tumbar el servidor por agotar la memoria.
MAX_CUERPO = 1024 * 1024

# Tope de duracion de un trabajo. Si un terminal se queda colgado (pasa: un
# dialogo modal esperando un clic que nadie va a dar), no queremos la cola
# bloqueada para siempre.
MAX_SEGUNDOS_TRABAJO = 6 * 60 * 60

# Cuantas lineas de progreso guardamos en memoria antes de tirar las viejas.
MAX_LINEAS_PROGRESO = 5000

# Tope de candidatos que se devuelven en /api/resultados. Un barrido genetico
# grande puede dejar decenas de miles de filas, y mandarlas todas por HTTP a
# una pagina que solo va a ensenar las primeras es tirar memoria a la basura.
MAX_CANDIDATOS_RESPUESTA = 2000


# ---------------------------------------------------------------------------
# IMPORTACION DE LOS MODULOS YA PROBADOS
# ---------------------------------------------------------------------------
try:
    import detectar_mt5
    import lector
    import generar_barridos
    import verificar
except ImportError as _exc:  # pragma: no cover - solo si falta un fichero
    sys.exit(
        "No encuentro los modulos de la fabrica (%s).\n"
        "Este servidor tiene que ejecutarse desde %s, donde estan\n"
        "detectar_mt5.py, lector.py, generar_barridos.py y verificar.py."
        % (_exc, RAIZ))


# ---------------------------------------------------------------------------
# QUE TERMINAL SE USA
# ---------------------------------------------------------------------------

def aplica_terminal(ficha):
    """Apunta el servidor entero al terminal de esa ficha.

    Es el UNICO sitio donde se decide donde estan las carpetas de MetaTrader.
    Se llama al arrancar y tambien desde /api/terminal cuando el usuario
    cambia de terminal sin cerrar el servidor; por eso tambien repara la cola
    del log, que es lo unico que se guardaba una copia de la ruta.
    """
    global TERMINAL, MT5_DIR, MT5_EXE, MT5_SETS, MT5_LOGS_TESTER, MT5_TESTER
    global MT5_PORTABLE

    TERMINAL = ficha
    MT5_DIR = ficha["datos"]
    MT5_EXE = ficha["exe"]
    MT5_SETS = os.path.join(MT5_DIR, "MQL5", "Profiles", "Tester")
    MT5_TESTER = os.path.join(MT5_DIR, "Tester")
    MT5_LOGS_TESTER = os.path.join(MT5_TESTER, "logs")
    MT5_PORTABLE = bool(ficha["portable"])

    # La cache de procesos habla del terminal ANTERIOR: si no se tira, durante
    # el segundo y medio siguiente el servidor creeria que hay un terminal vivo
    # (o que no lo hay) mirando la carpeta equivocada.
    with _candado_procesos:
        _cache_procesos["momento"] = 0.0
        _cache_procesos["valor"] = []

    motor = globals().get("MOTOR")
    if motor is not None:
        motor.cola_log.carpeta = MT5_LOGS_TESTER
        motor.cola_log.ruta = None
        motor.cola_log.posicion = 0
    return ficha


def resumen_terminal(ficha=None):
    """La ficha de un terminal en la forma que entiende la consola."""
    ficha = ficha if ficha is not None else TERMINAL
    if not ficha:
        return None
    return {
        "datos": ficha["datos"],
        "exe": ficha["exe"],
        "editor": ficha["editor"],
        "nombre": ficha["nombre"],
        "portable": ficha["portable"],
        "brokers": ficha["brokers"],
        "ea_en_graficos": ficha["ea_en_graficos"],
        "escribible": ficha["escribible"],
        "modificado": ficha["modificado"],
        "avisos": ficha["avisos"],
        "apto": ficha["apto"],
        "en_uso": bool(TERMINAL and ficha["datos"] == TERMINAL["datos"]),
    }


# ---------------------------------------------------------------------------
# UTILIDADES PEQUENAS
# ---------------------------------------------------------------------------

def ahora_texto():
    """Fecha y hora local en texto, para sellar lo que se guarda en disco."""
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def a_float(valor):
    """Convierte a float sin reventar. Devuelve None si no hay numero."""
    try:
        if valor is None or isinstance(valor, bool):
            return None
        return float(valor)
    except (TypeError, ValueError):
        return None


def escribe_texto(ruta, contenido):
    """Escribe texto en UTF-8 con saltos CRLF (lo que esperan .set y .ini)."""
    carpeta = os.path.dirname(ruta)
    if carpeta and not os.path.isdir(carpeta):
        os.makedirs(carpeta)
    with io.open(ruta, "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write(contenido)


def escribe_json(ruta, datos):
    """Guarda JSON de forma atomica: primero un .tmp y luego un cambio de nombre.

    Asi un corte de luz (o un Ctrl+C con mala suerte) no deja la biblioteca
    medio escrita y por tanto ilegible.
    """
    carpeta = os.path.dirname(ruta)
    if carpeta and not os.path.isdir(carpeta):
        os.makedirs(carpeta)
    temporal = ruta + ".tmp"
    with io.open(temporal, "w", encoding="utf-8") as fh:
        json.dump(datos, fh, ensure_ascii=False, indent=1)
    os.replace(temporal, ruta)


def lee_json(ruta, por_defecto):
    """Lee un JSON del disco. Si no esta o esta roto, devuelve el valor dado."""
    try:
        with io.open(ruta, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return por_defecto


def firma_genes(genes):
    """Huella estable de un juego de genes.

    Dos pasadas con exactamente los mismos genes son la MISMA estrategia,
    aunque vengan de barridos distintos y lleven numero de pasada distinto.
    La huella se calcula sobre los genes ordenados y con los numeros
    normalizados, para que 20 y 20.0 no cuenten como estrategias diferentes.
    """
    piezas = []
    for nombre in sorted(genes or {}):
        piezas.append("%s=%s" % (nombre, verificar.formatea(genes[nombre])))
    texto = ";".join(piezas)
    return hashlib.sha1(texto.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# QUE TERMINALES HAY VIVOS (y cuales son mios)
# ---------------------------------------------------------------------------
# Esto NO es un detalle. Es normal tener varios MetaTrader abiertos a la vez,
# y alguno puede tener posiciones abiertas con dinero de verdad. Por eso no vale
# con buscar procesos que se llamen terminal64.exe: hay que mirar la RUTA del
# ejecutable y quedarse solo con los del terminal que la fabrica esta usando.
# Matar el terminal equivocado seria un destrozo, no un fallo.

_PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


def _procesos_por_api():
    """Lista (pid, ruta_ejecutable) usando la API de Windows via ctypes.

    Sin subprocess: no abre ventanas de consola y tarda milisegundos.
    """
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    psapi = ctypes.WinDLL("psapi", use_last_error=True)

    capacidad = 4096
    while True:
        arreglo = (wintypes.DWORD * capacidad)()
        necesarios = wintypes.DWORD()
        if not psapi.EnumProcesses(ctypes.byref(arreglo),
                                   ctypes.sizeof(arreglo),
                                   ctypes.byref(necesarios)):
            raise OSError("EnumProcesses fallo")
        if necesarios.value < ctypes.sizeof(arreglo):
            break
        capacidad *= 2  # no cabian: reintentamos con el doble de sitio

    total = necesarios.value // ctypes.sizeof(wintypes.DWORD)
    salida = []
    for i in range(total):
        pid = arreglo[i]
        if pid == 0:
            continue
        manejador = kernel32.OpenProcess(
            _PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not manejador:
            continue  # proceso del sistema o ya muerto: ni caso
        try:
            buzon = ctypes.create_unicode_buffer(32768)
            tamano = wintypes.DWORD(32768)
            if kernel32.QueryFullProcessImageNameW(manejador, 0, buzon,
                                                   ctypes.byref(tamano)):
                salida.append((pid, buzon.value))
        finally:
            kernel32.CloseHandle(manejador)
    return salida


def _procesos_por_powershell():
    """Plan B si la via de ctypes no estuviera disponible."""
    orden = ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             "Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" "
             "| Select-Object ProcessId,ExecutablePath | ConvertTo-Json -Compress"]
    bruto = subprocess.run(orden, capture_output=True, text=True, timeout=20,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    datos = json.loads(bruto.stdout or "[]")
    if isinstance(datos, dict):
        datos = [datos]
    return [(int(d.get("ProcessId") or 0), d.get("ExecutablePath") or "")
            for d in datos]


_cache_procesos = {"momento": 0.0, "valor": []}
_candado_procesos = threading.Lock()


def es_terminal_nuestro(ruta):
    """True si ese ejecutable es el terminal que la fabrica esta usando.

    Con un terminal PORTABLE basta con mirar si el ejecutable cuelga de la
    carpeta de datos, porque ahi programa y datos viven juntos. Con una
    instalacion NORMAL no vale: el programa esta en Program Files y los datos
    en %APPDATA%, asi que lo que se compara es el ejecutable exacto. Y como una
    instalacion normal tiene UNA sola carpeta de datos (el nombre sale de la
    ruta de instalacion), esa comparacion es exacta, no aproximada.
    """
    if not ruta or not MT5_EXE:
        return False
    normal = os.path.normcase(os.path.abspath(ruta))
    if normal == os.path.normcase(os.path.abspath(MT5_EXE)):
        return True
    if MT5_PORTABLE and MT5_DIR:
        raiz = os.path.normcase(os.path.abspath(MT5_DIR)) + os.sep
        return normal.startswith(raiz) and normal.endswith("terminal64.exe")
    return False


def terminales_de_la_fabrica(forzar=False):
    """PIDs de los terminal64.exe que son el terminal elegido por la fabrica.

    El resultado se cachea un segundo y medio: la consola pregunta el estado
    varias veces por segundo y no tiene sentido recorrer la tabla de procesos
    del sistema en cada pregunta.
    """
    with _candado_procesos:
        if not forzar and time.time() - _cache_procesos["momento"] < 1.5:
            return list(_cache_procesos["valor"])
        try:
            procesos = _procesos_por_api()
        except Exception:
            try:
                procesos = _procesos_por_powershell()
            except Exception:
                procesos = []  # sin informacion: mejor no afirmar nada
        encontrados = []
        for pid, ruta in procesos:
            if ruta and es_terminal_nuestro(ruta):
                encontrados.append(pid)
        _cache_procesos["momento"] = time.time()
        _cache_procesos["valor"] = encontrados
        return list(encontrados)


def ruta_de_proceso(pid):
    """Ruta del ejecutable de un PID concreto, o None si ya no existe.

    Sirve para no matar por error a un proceso distinto que haya heredado el
    numero de PID de nuestro terminal despues de que este muriera.
    """
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        manejador = kernel32.OpenProcess(
            _PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
        if not manejador:
            return None
        try:
            buzon = ctypes.create_unicode_buffer(32768)
            tamano = wintypes.DWORD(32768)
            if kernel32.QueryFullProcessImageNameW(manejador, 0, buzon,
                                                   ctypes.byref(tamano)):
                return buzon.value
        finally:
            kernel32.CloseHandle(manejador)
    except Exception:
        return None
    return None


# ---------------------------------------------------------------------------
# VALIDACION DE TODO LO QUE LLEGA DEL CLIENTE
# ---------------------------------------------------------------------------
# Regla: nada que venga de fuera entra en un .ini, en un nombre de fichero o
# en una linea de ordenes sin pasar por aqui. Un simbolo con una barra o unas
# comillas dentro se convertiria en una ruta o en un argumento inesperado.

class ErrorPeticion(Exception):
    """Peticion mal formada. Se responde con 400 y un mensaje legible."""


class ErrorConflicto(Exception):
    """La peticion es valida pero ahora no se puede atender. Responde 409."""


RE_SIMBOLO = re.compile(r"^[A-Za-z0-9._#+-]{1,16}$")
RE_FECHA = re.compile(r"^\d{4}\.\d{2}\.\d{2}$")

MARCOS = ("M1", "M2", "M3", "M4", "M5", "M6", "M10", "M12", "M15", "M20",
          "M30", "H1", "H2", "H3", "H4", "H6", "H8", "H12", "D1", "W1", "MN1")

# Modos de reserva de MetaTrader: 0 sin forward, 1 la mitad, 2 un tercio,
# 3 un cuarto. El 4 es "fecha a mano" y necesita una clave ForwardDate que
# este API no contempla, asi que se rechaza en vez de generar un .ini a medias.
FRACCION_FORWARD = {0: 0.0, 1: 0.5, 2: 1.0 / 3.0, 3: 0.25}


def exige_simbolo(valor):
    texto = str(valor or "").strip().upper()
    if not RE_SIMBOLO.match(texto):
        raise ErrorPeticion(
            "Simbolo no valido: %r. Solo letras, numeros y . _ # + - "
            "(hasta 16 caracteres)." % valor)
    return texto


def exige_marco(valor):
    texto = str(valor or "").strip().upper()
    if texto not in MARCOS:
        raise ErrorPeticion(
            "Marco temporal no valido: %r. Los admitidos son: %s."
            % (valor, ", ".join(MARCOS)))
    return texto


def exige_fecha(valor, etiqueta):
    texto = str(valor or "").strip()
    if not RE_FECHA.match(texto):
        raise ErrorPeticion(
            "%s no valida: %r. El formato es AAAA.MM.DD." % (etiqueta, valor))
    try:
        fecha = dt.datetime.strptime(texto, "%Y.%m.%d").date()
    except ValueError:
        raise ErrorPeticion("%s no existe en el calendario: %r."
                            % (etiqueta, valor))
    if not (1970 <= fecha.year <= 2100):
        raise ErrorPeticion("%s fuera de rango razonable: %r." % (etiqueta, valor))
    return texto, fecha


def exige_numero(valor, etiqueta, minimo, maximo, entero=False):
    numero = a_float(valor)
    if numero is None:
        raise ErrorPeticion("%s no es un numero: %r." % (etiqueta, valor))
    if numero != numero or numero in (float("inf"), float("-inf")):
        raise ErrorPeticion("%s no es un numero finito." % etiqueta)
    if not (minimo <= numero <= maximo):
        raise ErrorPeticion("%s fuera de rango: %s (se admite de %s a %s)."
                            % (etiqueta, valor, minimo, maximo))
    return int(round(numero)) if entero else numero


def exige_senales(valor):
    if not isinstance(valor, (list, tuple)) or not valor:
        raise ErrorPeticion("Hay que indicar al menos una senal, "
                            "como lista de numeros de 0 a 4.")
    vistas = []
    for bruto in valor:
        indice = exige_numero(bruto, "Senal", 0, len(generar_barridos.SENALES) - 1,
                              entero=True)
        if indice not in vistas:
            vistas.append(indice)
    return vistas


def exige_puertas(valor):
    """Valida un diccionario de puertas contra las claves que conoce el lector."""
    if valor is None:
        return dict(lector.PUERTAS)
    if not isinstance(valor, dict):
        raise ErrorPeticion("Las puertas tienen que venir como diccionario.")
    puertas = dict(lector.PUERTAS)
    for clave, bruto in valor.items():
        if clave not in lector.PUERTAS:
            raise ErrorPeticion("Puerta desconocida: %r. Las que hay son: %s."
                                % (clave, ", ".join(sorted(lector.PUERTAS))))
        numero = a_float(bruto)
        if numero is None or numero != numero:
            raise ErrorPeticion("La puerta %s no es un numero: %r." % (clave, bruto))
        if not (-1e9 <= numero <= 1e9):
            raise ErrorPeticion("La puerta %s tiene un valor absurdo: %r."
                                % (clave, bruto))
        puertas[clave] = int(numero) if clave == "MIN_OPERACIONES" else numero
    return puertas


# ---------------------------------------------------------------------------
# LECTURA EN VIVO DEL LOG DEL PROBADOR
# ---------------------------------------------------------------------------
# El log esta en UTF-16LE y con los campos separados por tabuladores:
#   'HG\t0\t07:07:11.961\tTester\tBest result 0.779... produced at generation 34'
# Se lee por el final, apuntando al tamano que tenia el fichero justo antes de
# lanzar el terminal, para no repetir de nuevo lo de tandas anteriores.

PATRONES_UTILES = (
    re.compile(r"Best result\s+([0-9.eE+-]+)\s+produced at generation\s+(\d+)"),
    re.compile(r"genetic optimization finished on pass\s+(\d+)"),
    re.compile(r"optimization finished, total passes\s+(\d+)"),
    re.compile(r"passes of \d+ failed, genetic optimization stopped"),
    re.compile(r"optimization (?:finished|stopped)", re.I),
    re.compile(r"final balance", re.I),
    re.compile(r"history (?:downloaded|starts)", re.I),
    re.compile(r"\bcannot\b|\bfailed to\b|\berror\b", re.I),
)

RE_MEJOR = PATRONES_UTILES[0]
RE_PASE_GENETICO = PATRONES_UTILES[1]
RE_TOTAL_PASADAS = PATRONES_UTILES[2]
RE_PARAMETROS_MALOS = re.compile(r"incorrect input parameters", re.I)


class ColaDelLog:
    """Sigue el fichero de log del dia y devuelve solo las lineas nuevas."""

    def __init__(self, carpeta):
        self.carpeta = carpeta
        self.ruta = None
        self.posicion = 0

    def _log_del_dia(self):
        """El log de hoy; si no existe aun, el mas reciente de la carpeta."""
        esperado = os.path.join(
            self.carpeta, dt.datetime.now().strftime("%Y%m%d") + ".log")
        if os.path.isfile(esperado):
            return esperado
        try:
            ficheros = [os.path.join(self.carpeta, n)
                        for n in os.listdir(self.carpeta) if n.endswith(".log")]
        except OSError:
            return esperado  # la carpeta aun no existe: la creara MetaTrader
        if not ficheros:
            return esperado
        return max(ficheros, key=os.path.getmtime)

    def apunta_al_final(self):
        """Se coloca al final de lo que ya hay escrito. Se llama antes de lanzar."""
        self.ruta = self._log_del_dia()
        try:
            self.posicion = os.path.getsize(self.ruta)
        except OSError:
            self.posicion = 0
        # El BOM inicial (2 bytes) no es una linea: si el fichero esta vacio o
        # recien creado, empezamos en 0 y ya lo descartaremos al decodificar.

    def nuevas(self):
        """Devuelve la lista de lineas completas aparecidas desde la ultima vez."""
        actual = self._log_del_dia()
        if actual != self.ruta:
            # Ha cambiado el dia (o MetaTrader ha abierto un log nuevo).
            self.ruta = actual
            self.posicion = 0
        if not self.ruta or not os.path.isfile(self.ruta):
            return []
        try:
            with io.open(self.ruta, "rb") as fh:
                fh.seek(self.posicion)
                bruto = fh.read()
        except OSError:
            return []
        if not bruto:
            return []
        # UTF-16 gasta dos bytes por caracter: si hemos pillado un byte suelto
        # porque MetaTrader estaba escribiendo justo en ese momento, lo dejamos
        # para la proxima vuelta.
        if len(bruto) % 2:
            bruto = bruto[:-1]
        if not bruto:
            return []
        texto = bruto.decode("utf-16-le", errors="replace").replace("\ufeff", "")
        corte = texto.rfind("\n")
        if corte < 0:
            return []  # linea a medias: esperamos a que termine de escribirla
        consumido = texto[:corte + 1]
        self.posicion += len(consumido.encode("utf-16-le"))
        return [l for l in consumido.splitlines() if l.strip()]


def parte_linea_log(linea):
    """Separa una linea del log en (hora, fuente, mensaje)."""
    campos = linea.split("\t")
    if len(campos) >= 5:
        return campos[2], campos[3], "\t".join(campos[4:]).strip()
    if len(campos) >= 3:
        return campos[2], "", campos[-1].strip()
    return "", "", linea.strip()


# ---------------------------------------------------------------------------
# GENERACION DE .set Y .ini
# ---------------------------------------------------------------------------
# Las tablas de genes NO se copian aqui: se leen de generar_barridos, que es
# donde estan documentadas y probadas. Si manana cambia un rango, cambia en un
# sitio y el servidor se entera solo.

CABECERA_INI = """; %(titulo)s
; Generado por servidor.py el %(fecha)s. No editar a mano: se reescribe.
;
; AllowLiveTrading=0 NO es decorativo. Mientras el terminal esta abierto para
; optimizar, cualquier robot que siga adjunto a un grafico podria ponerse a
; operar con dinero de verdad en cuanto arranque el terminal. Con esta clave a
; cero, el terminal no deja operar a ningun experto. El Probador no se entera
; ni le afecta, porque simula en vez de mandar ordenes al servidor.
;
; OJO CON Report: tiene que ser una ruta RELATIVA (solo el nombre del fichero).
; Con una ruta absoluta MetaTrader no escribe el informe y encima no avisa: te
; deja creyendo que el barrido no dio resultados.
[Experts]
AllowLiveTrading=0
Enabled=1
Account=1
Profile=1

[Tester]
"""


def texto_ini(titulo, pares):
    """Arma un .ini con la cabecera comentada y los pares clave=valor dados."""
    cuerpo = "".join("%s=%s\n" % (k, v) for k, v in pares)
    return (CABECERA_INI % {"titulo": titulo, "fecha": ahora_texto()}) + cuerpo


def construye_set_barrido(indice, riesgo, nombre_fichero):
    """Escribe el .set del barrido de una senal, con el riesgo pedido.

    Reutiliza SENALES, COMUNES y linea() de generar_barridos. Lo unico que
    cambia respecto al fichero que genera aquel script es el riesgo, que aqui
    lo elige el usuario desde la consola.
    """
    clave, nombre, pa, pb, um = generar_barridos.SENALES[indice]
    riesgo_txt = ("%.2f" % riesgo).rstrip("0").rstrip(".")
    if not riesgo_txt:
        riesgo_txt = "0"

    lineas = [
        "; Barrido de la senal %d - %s" % (indice, nombre),
        "; Formato MetaTrader: nombre=valor||inicio||paso||fin||optimizar(Y/N)",
        "; Los genes que esta senal no usa van a su valor canonico, que es lo",
        "; que OnInit exige para no probar la misma estrategia dos veces.",
        generar_barridos.linea("InpSenal", str(indice), str(indice), "1",
                               str(indice), "N"),
        generar_barridos.linea("InpPeriodoA", pa[0], pa[1], pa[2], pa[3], "Y"),
        generar_barridos.linea("InpPeriodoB", pb[0], pb[1], pb[2], pb[3],
                               "Y" if indice == 0 else "N"),
        generar_barridos.linea("InpUmbral", um[0], um[1], um[2], um[3], um[4]),
    ]
    for gen in generar_barridos.COMUNES:
        if gen[0] == "InpRiesgoPct":
            # El riesgo no es un gen: es configuracion, y la fija el usuario.
            gen = ("InpRiesgoPct", riesgo_txt, riesgo_txt, "0.1", riesgo_txt, "N")
        lineas.append(generar_barridos.linea(*gen))
    contenido = "\n".join(lineas) + "\n"

    # Dos copias: la del proyecto (trazabilidad) y la que lee MetaTrader.
    escribe_texto(os.path.join(DIR_SETS, nombre_fichero), contenido)
    if not os.path.isdir(MT5_SETS):
        # En un terminal recien instalado esa carpeta no existe hasta que se
        # abre el Probador por primera vez. Se crea: es del usuario y es donde
        # MetaTrader va a buscar los parametros del barrido.
        try:
            os.makedirs(MT5_SETS)
        except OSError as exc:
            raise ErrorPeticion(
                "No he podido crear la carpeta de .set de MetaTrader (%s): %s. "
                "Comprueba que el terminal elegido es el que crees y que se "
                "puede escribir en el." % (MT5_SETS, exc))
    escribe_texto(os.path.join(MT5_SETS, nombre_fichero), contenido)
    return contenido


def construye_set_verificacion(candidato, set_base, nombre_fichero):
    """Escribe un .set con TODOS los genes fijos, para un test individual.

    Se parte de los valores por defecto del .set del barrido (los genes que no
    se optimizaron no salen como columna en el XML, asi que de algun sitio hay
    que sacarlos) y se pisan con los genes concretos de la pasada.
    """
    base = verificar.lee_set(set_base)
    base.update(verificar.FIJOS_POR_DEFECTO)
    genes = candidato.get("genes") or {}
    base.update({k: verificar.formatea(v) for k, v in genes.items()})

    lineas = ["; Verificacion de la pasada %s - todos los genes FIJOS."
              % candidato.get("pass"),
              "; Esto NO es una optimizacion: es una sola pasada, para ver si"
              " la fila del XML se reproduce."]
    for nombre, valor in base.items():
        lineas.append("%s=%s||%s||0||%s||N" % (nombre, valor, valor, valor))
    contenido = "\n".join(lineas) + "\n"

    escribe_texto(os.path.join(DIR_SETS, nombre_fichero), contenido)
    if not os.path.isdir(MT5_SETS):
        try:
            os.makedirs(MT5_SETS)
        except OSError:
            pass
    if os.path.isdir(MT5_SETS):
        escribe_texto(os.path.join(MT5_SETS, nombre_fichero), contenido)
    return base


def fecha_de_corte(desde, hasta, modo_forward):
    """Fecha en la que MetaTrader parte el periodo para reservar el forward.

    Comprobado contra el log real: con 2018.01.01 -> 2025.12.31 y ForwardMode=3
    (un cuarto), MetaTrader busca hasta 2023.12.31 y reserva de ahi en
    adelante. La cuenta por dias reproduce esa fecha exactamente.
    """
    fraccion = FRACCION_FORWARD.get(int(modo_forward), 0.0)
    if fraccion <= 0:
        return hasta
    dias = (hasta - desde).days
    return desde + dt.timedelta(days=int(dias * (1.0 - fraccion)))


# ---------------------------------------------------------------------------
# REGISTRO DE BARRIDOS
# ---------------------------------------------------------------------------
# Guarda de donde salio cada XML: que senal, que simbolo, que fechas y que
# modo de forward. Hace falta para poder verificar despues un candidato con
# EXACTAMENTE el mismo periodo con el que se busco.

_candado_registro = threading.Lock()


def registro_barridos():
    with _candado_registro:
        datos = lee_json(RUTA_REGISTRO, {})
        return datos if isinstance(datos, dict) else {}


def anota_barrido(clave, info):
    with _candado_registro:
        datos = lee_json(RUTA_REGISTRO, {})
        if not isinstance(datos, dict):
            datos = {}
        datos[clave] = info
        escribe_json(RUTA_REGISTRO, datos)


def clave_de_xml(ruta):
    """De 'informes/fabrica_s1_rsi_EURUSD_H1.xml' saca 's1_rsi_EURUSD_H1'."""
    base = os.path.basename(ruta)
    if base.lower().endswith(".xml"):
        base = base[:-4]
    if base.lower().startswith("fabrica_"):
        base = base[8:]
    return base


def xmls_disponibles():
    """Todos los XML de busqueda que hay en informes/ (sin los .forward.xml)."""
    salida = []
    try:
        nombres = sorted(os.listdir(DIR_INFORMES))
    except OSError:
        return salida
    for nombre in nombres:
        bajo = nombre.lower()
        if not bajo.endswith(".xml") or bajo.endswith(".forward.xml"):
            continue
        salida.append(os.path.join(DIR_INFORMES, nombre))
    return salida


# ---------------------------------------------------------------------------
# CACHE DE INFORMES
# ---------------------------------------------------------------------------
# Parsear un XML de 70 KB no es gratis, y /api/estado se pregunta varias veces
# por segundo. Se cachea por (ruta, fecha de modificacion, tamano): si el
# fichero cambia, la clave cambia y se vuelve a leer solo.

_cache_informes = {}
_candado_informes = threading.Lock()


def carga_informe_cacheado(ruta):
    try:
        estado = os.stat(ruta)
    except OSError:
        return []
    clave = (os.path.normcase(ruta), int(estado.st_mtime), estado.st_size)
    with _candado_informes:
        if clave in _cache_informes:
            return _cache_informes[clave]
    registros = lector.carga_informe(ruta)  # puede lanzar LectorError
    with _candado_informes:
        if len(_cache_informes) > 40:
            _cache_informes.clear()
        _cache_informes[clave] = registros
    return registros


def resumen_barridos():
    """Ficha corta de cada XML disponible, para /api/estado."""
    registro = registro_barridos()
    salida = []
    for ruta in xmls_disponibles():
        clave = clave_de_xml(ruta)
        info = registro.get(clave, {})
        ruta_fwd = lector.deduce_ruta_forward(ruta)
        try:
            filas = len(carga_informe_cacheado(ruta))
        except lector.LectorError:
            filas = 0
        except Exception:
            filas = 0
        try:
            fecha = dt.datetime.fromtimestamp(
                os.path.getmtime(ruta)).strftime("%Y-%m-%d %H:%M")
        except OSError:
            fecha = ""
        salida.append({
            "clave": clave,
            "nombre": info.get("nombre", clave),
            "xml": os.path.basename(ruta),
            "filas": filas,
            "fecha": fecha,
            "tiene_forward": bool(ruta_fwd and os.path.isfile(ruta_fwd)),
        })
    return salida


# ---------------------------------------------------------------------------
# CALCULO DE RESULTADOS
# ---------------------------------------------------------------------------

_candado_resultados = threading.Lock()
_ultimos_resultados = {"meta": None, "candidatos": []}



# Prefijos estables de cada puerta. El motivo que escribe lector.py empieza
# siempre por uno de estos y luego detalla las cifras del caso concreto.
CATEGORIAS_MOTIVO = (
    "muestra insuficiente",
    "puntuacion de robustez baja",
    "el beneficio del tramo de busqueda no es positivo",
    "no consta el beneficio del tramo de busqueda",
    "caida excesiva frente al beneficio",
    "no se puede comprobar la caida sobre el beneficio",
    "la mejor operacion pesa",
    "meses en positivo insuficientes",
    "el tramo reservado no es positivo",
    "desplome fuera de muestra",
    "sin tramo reservado que verificar",
)


def categoria_de_motivo(motivo):
    """Reduce un motivo al nombre de la puerta que lo genero.

    Sirve para el recuento agregado: interesa saber "cuantas caen por muestra
    insuficiente", no "cuantas caen por tener exactamente 42 operaciones".
    """
    texto = (motivo or "").strip()
    bajo = texto.lower()
    for prefijo in CATEGORIAS_MOTIVO:
        if bajo.startswith(prefijo):
            return prefijo
    # Cualquier motivo nuevo que no reconozcamos: nos quedamos con lo que hay
    # antes de los dos puntos, que es donde lector.py pone el nombre de la puerta.
    return texto.split(":")[0].strip() or texto


def carga_ejemplo():
    """Devuelve los resultados de ejemplo, o None si no estan.

    No se le aplican las puertas otra vez: el fichero ya viene clasificado y
    volver a juzgarlo con unos umbrales distintos daria un recuento que no
    cuadra con el que trae dentro. Es material de demostracion, no un barrido.
    """
    try:
        with open(RUTA_EJEMPLO, encoding="utf-8") as fichero:
            datos = json.load(fichero)
    except (OSError, ValueError):
        return None
    meta = dict(datos.get("meta") or {})
    meta["es_ejemplo"] = True
    meta["mostrados"] = len(datos.get("candidatos") or [])
    meta.setdefault("puertas", dict(lector.PUERTAS))
    return {"meta": meta, "candidatos": datos.get("candidatos") or []}


def calcula_resultados(puertas=None):
    """Cruza todos los XML disponibles y aplica las puertas.

    Es lector.py quien parsea y quien juzga. Aqui solo se recorren los
    ficheros, se etiqueta cada candidato con su barrido de origen y se suman
    los totales para el resumen.
    """
    puertas = dict(puertas or lector.PUERTAS)

    # Sin barridos propios todavia, servimos el ejemplo. Va SIEMPRE etiquetado
    # con es_ejemplo=True para que la interfaz lo diga bien claro: nadie debe
    # confundir un barrido de referencia con el suyo. En cuanto aparezca el
    # primer XML propio, esto deja de usarse solo.
    if not xmls_disponibles():
        ejemplo = carga_ejemplo()
        if ejemplo is not None:
            return ejemplo

    registro = registro_barridos()
    todos = []
    origenes = []
    por_barrido = {}
    avisos = []

    for ruta in xmls_disponibles():
        clave = clave_de_xml(ruta)
        try:
            registros = carga_informe_cacheado(ruta)
        except lector.LectorError as exc:
            avisos.append("%s: %s" % (os.path.basename(ruta), exc))
            continue
        except Exception as exc:
            avisos.append("%s: no se pudo leer (%s)" % (os.path.basename(ruta), exc))
            continue

        registros_fwd = []
        ruta_fwd = lector.deduce_ruta_forward(ruta)
        if ruta_fwd and os.path.isfile(ruta_fwd):
            try:
                registros_fwd = carga_informe_cacheado(ruta_fwd)
            except Exception as exc:
                avisos.append("%s: forward ilegible (%s)"
                              % (os.path.basename(ruta_fwd), exc))

        candidatos = lector.construye_candidatos(registros, registros_fwd, puertas)
        aptas = 0
        for cand in candidatos:
            cand["origen"] = clave
            cand["clave"] = "%s#%s" % (clave, cand.get("pass"))
            cand["nombre_origen"] = registro.get(clave, {}).get("nombre", clave)
            if cand.get("apta"):
                aptas += 1
        por_barrido[clave] = {"total": len(candidatos), "aptas": aptas}
        origenes.append(os.path.basename(ruta))
        todos.extend(candidatos)

    # Orden global por puntuacion, los mejores primero.
    todos.sort(key=lambda c: (a_float(c.get("puntuacion")) is not None,
                              a_float(c.get("puntuacion")) or 0.0),
               reverse=True)

    por_motivo = {}
    aptas_total = 0
    for cand in todos:
        if cand.get("apta"):
            aptas_total += 1
        vistas = set()
        for motivo in cand.get("motivos") or []:
            # Se agrupa por la CATEGORIA de la puerta, no por el texto completo.
            # El texto lleva las cifras del caso concreto ("muestra insuficiente:
            # 42 operaciones, minimo 100"), asi que contar cadenas enteras
            # producia decenas de filas casi identicas que enterraban lo util.
            # La ficha de cada candidato sigue mostrando el motivo completo.
            categoria = categoria_de_motivo(motivo)
            if categoria in vistas:
                continue      # una misma puerta no cuenta dos veces por candidato
            vistas.add(categoria)
            por_motivo[categoria] = por_motivo.get(categoria, 0) + 1

    recortado = len(todos) > MAX_CANDIDATOS_RESPUESTA
    meta = {
        "total_combinaciones": len(todos),
        "aptas": aptas_total,
        "puertas": puertas,
        "generado_desde": origenes,
        "por_motivo": por_motivo,
        "por_barrido": por_barrido,
        "fecha": ahora_texto(),
        "mostrados": min(len(todos), MAX_CANDIDATOS_RESPUESTA),
        "recortado": recortado,
    }
    if avisos:
        meta["avisos"] = avisos

    resultado = {"meta": meta, "candidatos": todos}
    with _candado_resultados:
        _ultimos_resultados["meta"] = meta
        _ultimos_resultados["candidatos"] = todos
    try:
        # Se deja tambien en disco para que panel.html pueda cargarlo a mano.
        escribe_json(RUTA_RESULTADOS, resultado)
    except OSError:
        pass
    return resultado


def resultados_para_respuesta(resultado):
    """Recorta la lista de candidatos a un tamano razonable para el navegador."""
    return {
        "ok": True,
        "meta": resultado["meta"],
        "candidatos": resultado["candidatos"][:MAX_CANDIDATOS_RESPUESTA],
    }


def busca_candidato(origen, pasada):
    """Localiza un candidato ya calculado por (origen, numero de pasada)."""
    with _candado_resultados:
        candidatos = list(_ultimos_resultados["candidatos"])
    if not candidatos:
        candidatos = calcula_resultados()["candidatos"]
    for cand in candidatos:
        if cand.get("origen") == origen and str(cand.get("pass")) == str(pasada):
            return cand
    return None


# ---------------------------------------------------------------------------
# BIBLIOTECA DE SUPERVIVIENTES
# ---------------------------------------------------------------------------
# Persistente en disco, acumulativa entre tandas. La identidad de una entrada
# es "<origen>#<pass>", pero al absorber se deduplica ademas por la huella de
# los genes: la misma estrategia encontrada en dos barridos distintos es una
# sola estrategia, no dos.

_candado_biblioteca = threading.Lock()


def carga_biblioteca():
    datos = lee_json(RUTA_BIBLIOTECA, {"entradas": []})
    if not isinstance(datos, dict) or not isinstance(datos.get("entradas"), list):
        datos = {"entradas": []}
    return datos


def guarda_biblioteca(datos):
    datos["total"] = len(datos.get("entradas", []))
    datos["fecha"] = ahora_texto()
    escribe_json(RUTA_BIBLIOTECA, datos)


def total_biblioteca():
    try:
        return len(carga_biblioteca().get("entradas", []))
    except Exception:
        return 0


def _entrada_desde_candidato(candidato):
    return {
        "clave": "%s#%s" % (candidato.get("origen"), candidato.get("pass")),
        "origen": candidato.get("origen"),
        "pass": candidato.get("pass"),
        "firma": firma_genes(candidato.get("genes")),
        "fecha": ahora_texto(),
        "candidato": candidato,
    }


def biblioteca_guardar(clave):
    if "#" not in str(clave or ""):
        raise ErrorPeticion(
            "Clave no valida: %r. Tiene que ser '<origen>#<pasada>'." % clave)
    origen, pasada = str(clave).rsplit("#", 1)
    candidato = busca_candidato(origen, pasada)
    if candidato is None:
        raise ErrorPeticion(
            "No encuentro el candidato %s entre los resultados actuales. "
            "Puede que haga falta recalcular." % clave)
    with _candado_biblioteca:
        datos = carga_biblioteca()
        existentes = {e.get("clave") for e in datos["entradas"]}
        if clave not in existentes:
            datos["entradas"].append(_entrada_desde_candidato(candidato))
            guarda_biblioteca(datos)
        return len(datos["entradas"])


def biblioteca_borrar(clave):
    with _candado_biblioteca:
        datos = carga_biblioteca()
        antes = len(datos["entradas"])
        datos["entradas"] = [e for e in datos["entradas"]
                             if e.get("clave") != clave]
        if len(datos["entradas"]) != antes:
            guarda_biblioteca(datos)
        return len(datos["entradas"])


def biblioteca_absorber():
    """Mete en la biblioteca todas las aptas de ahora que no estuvieran ya."""
    with _candado_resultados:
        candidatos = list(_ultimos_resultados["candidatos"])
    if not candidatos:
        candidatos = calcula_resultados()["candidatos"]

    with _candado_biblioteca:
        datos = carga_biblioteca()
        claves = {e.get("clave") for e in datos["entradas"]}
        firmas = {e.get("firma") for e in datos["entradas"] if e.get("firma")}
        anadidas = 0
        for cand in candidatos:
            if not cand.get("apta"):
                continue
            entrada = _entrada_desde_candidato(cand)
            if entrada["clave"] in claves:
                continue
            # Dedupe por genes: dos pasadas identicas son la misma estrategia
            # aunque el barrido y el numero de pasada sean distintos.
            if entrada["firma"] in firmas:
                continue
            datos["entradas"].append(entrada)
            claves.add(entrada["clave"])
            firmas.add(entrada["firma"])
            anadidas += 1
        if anadidas:
            guarda_biblioteca(datos)
        return anadidas, len(datos["entradas"])


# ---------------------------------------------------------------------------
# LECTURA DE LA LINEA "JUEZ|" (verificacion)
# ---------------------------------------------------------------------------
# En un test individual el propio experto imprime un desglose y una linea
# compacta "JUEZ|..." con los valores separados por ';'. Esa linea es la mejor
# fuente posible para comparar: la escribe el mismo codigo que puso la nota en
# el XML, asi que si no coincide es que algo se ha roto de verdad.

CAMPOS_JUEZ = ("operaciones", "cierres", "factor_beneficio", "beneficio",
               "caida", "caida_pct", "peso_mejor", "prop_meses",
               "meses_activos", "racha_max", "racha_esperada", "f_muestra",
               "f_caida", "f_concentracion", "f_meses", "f_racha", "base",
               "puntuacion", "motivo")


def busca_linea_juez(desde_momento):
    """Ultima linea JUEZ| escrita despues del momento dado, en cualquier log."""
    patrones = [os.path.join(MT5_TESTER, "Agent-*", "logs", "*.log"),
                os.path.join(MT5_LOGS_TESTER, "*.log")]
    mejor = None  # (mtime, linea)
    for patron in patrones:
        for ruta in glob.glob(patron):
            try:
                if os.path.getmtime(ruta) < desde_momento - 5:
                    continue
                with io.open(ruta, "rb") as fh:
                    bruto = fh.read()
            except OSError:
                continue
            if len(bruto) % 2:
                bruto = bruto[:-1]
            texto = bruto.decode("utf-16-le", errors="replace")
            if "JUEZ|" not in texto:
                continue
            encontrada = None
            for linea in texto.splitlines():
                if "JUEZ|" in linea:
                    encontrada = linea
            if encontrada is None:
                continue
            marca = os.path.getmtime(ruta)
            if mejor is None or marca > mejor[0]:
                mejor = (marca, encontrada)
    return mejor[1] if mejor else None


def interpreta_juez(linea):
    """Convierte la linea JUEZ| en un diccionario de valores."""
    if not linea or "JUEZ|" not in linea:
        return None
    trozo = linea.split("JUEZ|", 1)[1].strip()
    partes = trozo.split(";")
    salida = {}
    for nombre, bruto in zip(CAMPOS_JUEZ, partes):
        if nombre == "motivo":
            salida[nombre] = bruto.strip()
            continue
        numero = a_float(bruto)
        if numero is None:
            continue
        if nombre in ("operaciones", "cierres", "meses_activos", "racha_max"):
            salida[nombre] = int(numero)
        else:
            salida[nombre] = numero
    return salida or None


def compara_verificacion(esperado, obtenido):
    """Lista, en castellano, en que se diferencian lo esperado y lo obtenido."""
    if not obtenido:
        return ["No he encontrado la linea JUEZ| en los logs del Probador. "
                "Sin ella no puedo comparar nada: mejor decirlo que inventarme "
                "que coincide."]
    # Tolerancias: el XML redondea (el factor de beneficio a dos decimales,
    # la caida a dos), asi que exigir igualdad exacta seria dar por rota una
    # cadena que funciona. Lo que no se tolera es una diferencia real.
    comprobaciones = (
        ("operaciones", "operaciones", 0.0, "%.0f"),
        ("beneficio", "beneficio", 0.02, "%.2f"),
        ("factor_beneficio", "factor_beneficio", 0.011, "%.4f"),
        ("caida_pct", "caida_pct", 0.05, "%.2f"),
        ("puntuacion", "puntuacion", 0.001, "%.6f"),
    )
    diferencias = []
    for clave_esp, clave_obt, tolerancia, formato in comprobaciones:
        valor_esp = a_float(esperado.get(clave_esp))
        valor_obt = a_float(obtenido.get(clave_obt))
        if valor_esp is None or valor_obt is None:
            continue
        margen = max(tolerancia, abs(valor_esp) * 0.001)
        if abs(valor_esp - valor_obt) > margen:
            diferencias.append(
                "%s: el XML decia %s y el test individual da %s"
                % (clave_esp, formato % valor_esp, formato % valor_obt))
    return diferencias


# ---------------------------------------------------------------------------
# EL MOTOR: COLA DE TRABAJOS Y UN SOLO HILO
# ---------------------------------------------------------------------------

class Motor:
    """Cola de trabajos, hilo trabajador y estado en vivo.

    Todo el estado compartido se toca con el candado. El hilo trabajador es
    uno solo y ejecuta los trabajos de uno en uno, porque MetaTrader no admite
    dos instancias sobre la misma carpeta de datos.
    """

    def __init__(self):
        self.condicion = threading.Condition(threading.RLock())
        self.cola = collections.deque()
        self.actual = None
        self.ultimo = None
        self.proceso = None
        self.pid_propio = None
        self.pausado = False
        self.detener_pedido = False
        self.contador = 0
        self.lineas = []
        self.descartadas = 0
        self.cola_log = ColaDelLog(MT5_LOGS_TESTER)
        self.verificacion = lee_json(RUTA_VERIFICACION, None)
        self.hilo = threading.Thread(target=self._bucle, name="trabajador",
                                     daemon=True)
        self.hilo.start()

    # -- progreso ----------------------------------------------------------
    def anota(self, texto):
        with self.condicion:
            self.lineas.append(texto)
            if len(self.lineas) > MAX_LINEAS_PROGRESO:
                sobran = len(self.lineas) - MAX_LINEAS_PROGRESO
                del self.lineas[:sobran]
                self.descartadas += sobran

    def progreso(self, desde):
        with self.condicion:
            inicio = max(int(desde or 0), self.descartadas)
            trozo = self.lineas[inicio - self.descartadas:]
            return trozo, self.descartadas + len(self.lineas)

    # -- cola --------------------------------------------------------------
    def nuevo_id(self):
        with self.condicion:
            self.contador += 1
            return "t%04d" % self.contador

    def encola(self, trabajos):
        with self.condicion:
            for trabajo in trabajos:
                self.cola.append(trabajo)
            self.pausado = False  # lanzar reanuda una cola que quedo en pausa
            self.condicion.notify_all()

    def vacia_cola(self):
        with self.condicion:
            cuantos = len(self.cola)
            self.cola.clear()
            self.pausado = False
            return cuantos

    def resumen_cola(self):
        with self.condicion:
            return [{"id": t["id"], "clave": t["clave"], "nombre": t["nombre"]}
                    for t in self.cola]

    # -- estado ------------------------------------------------------------
    def estado_trabajo(self):
        with self.condicion:
            trabajo = self.actual or self.ultimo
            if trabajo is None:
                return {"id": None, "clave": None, "nombre": "", "tipo": "",
                        "estado": "inactivo", "segundos": 0, "generacion": None,
                        "mejor": None, "pasadas": None,
                        "mensaje": "Sin trabajo. Elige senales y pulsa lanzar."}
            inicio = trabajo.get("inicio")
            fin = trabajo.get("fin")
            if inicio is None:
                segundos = 0
            elif fin is None:
                segundos = int(time.time() - inicio)
            else:
                segundos = int(fin - inicio)
            return {
                "id": trabajo.get("id"),
                "clave": trabajo.get("clave"),
                "nombre": trabajo.get("nombre", ""),
                "tipo": trabajo.get("tipo", "barrido"),
                "estado": trabajo.get("estado", "inactivo"),
                "segundos": segundos,
                "generacion": trabajo.get("generacion"),
                "mejor": trabajo.get("mejor"),
                "pasadas": trabajo.get("pasadas"),
                "mensaje": trabajo.get("mensaje", ""),
            }

    # -- detener -----------------------------------------------------------
    def detener(self):
        """Mata SOLO el terminal que hemos lanzado nosotros.

        Nunca se busca "un terminal64.exe" y se mata: en esta maquina hay
        varios, y alguno puede tener posiciones abiertas con dinero real. Se
        mata el PID que guardamos al lanzar, y aun asi se comprueba antes que
        ese PID sigue siendo el terminal de la fabrica (los numeros de PID se
        reciclan).
        """
        with self.condicion:
            proceso = self.proceso
            pid = self.pid_propio
            vivo = proceso is not None and pid is not None and proceso.poll() is None
            if vivo or self.cola:
                # Detener significa parar la tanda entera, no solo el trabajo
                # en curso: si no, el hilo arrancaria el siguiente de la cola
                # medio segundo despues y pareceria que el boton no funciona.
                # La cola se conserva; el siguiente lanzar la reanuda.
                self.detener_pedido = True
                self.pausado = True
            if not vivo:
                return False
        ruta = ruta_de_proceso(pid)
        if not es_terminal_nuestro(ruta):
            self.anota("No detengo nada: el PID %s ya no es el terminal de la "
                       "fabrica." % pid)
            return False
        try:
            proceso.terminate()
            try:
                proceso.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proceso.kill()
            self.anota("Terminal detenido a peticion del usuario (PID %s)." % pid)
            return True
        except Exception as exc:
            self.anota("No he podido detener el terminal: %s" % exc)
            return False

    # -- bucle del hilo ----------------------------------------------------
    def _observa_ajeno(self):
        """Sigue el log cuando optimiza un terminal que no hemos lanzado.

        No damos el trabajo por nuestro ni tocamos su proceso: solo leemos el
        log, que es informacion, para que el usuario vea lo que esta pasando.
        """
        try:
            # terminales_de_la_fabrica() devuelve los terminal64.exe del
            # terminal elegido. Como aqui no hay trabajo propio, cualquiera
            # que aparezca es ajeno.
            ajenos = terminales_de_la_fabrica()
        except Exception:
            return
        if not ajenos:
            self._observando = False
            return
        if not getattr(self, "_observando", False):
            # Primera vez: nos colocamos al final para no volcar todo el dia.
            self.cola_log.apunta_al_final()
            self._observando = True
            self.anota("--- hay un MetaTrader optimizando en esta carpeta que "
                       "no he lanzado yo; sigo su log como observador ---")
            return
        try:
            for cruda in self.cola_log.nuevas():
                hora, fuente, mensaje = parte_linea_log(cruda)
                if not mensaje:
                    continue
                if RE_PARAMETROS_MALOS.search(mensaje):
                    continue      # salen a miles; taparian lo util
                # PATRONES_UTILES ya recoge lo que merece verse: generaciones,
                # fin de optimizacion, abortos, balance final y errores.
                if any(p.search(mensaje) for p in PATRONES_UTILES):
                    self.anota("%s  %s" % (hora or "", mensaje))
        except Exception:
            pass

    def _bucle(self):
        while True:
            with self.condicion:
                while not self.cola or self.pausado:
                    self.condicion.wait(1.0)
                    # Mientras no tenemos trabajo propio, si hay un MetaTrader
                    # ajeno optimizando en esta misma carpeta seguimos su log de
                    # todas formas. Si no, el panel de estado se queda en blanco
                    # justo cuando mas cosas estan pasando, y parece averiado.
                    self._observa_ajeno()
                trabajo = self.cola.popleft()
                self.actual = trabajo
                self.ultimo = trabajo
                self.detener_pedido = False
                trabajo["estado"] = "preparando"
                trabajo["inicio"] = time.time()
                trabajo["mensaje"] = "Preparando ficheros..."
            try:
                self._ejecuta(trabajo)
            except ErrorConflicto as exc:
                trabajo["estado"] = "error"
                trabajo["mensaje"] = str(exc)
                self.anota("ERROR: %s" % exc)
            except Exception as exc:  # ningun fallo de un trabajo tumba el hilo
                trabajo["estado"] = "error"
                trabajo["mensaje"] = "%s: %s" % (type(exc).__name__, exc)
                self.anota("ERROR en %s: %s" % (trabajo.get("clave"), exc))
            finally:
                trabajo["fin"] = time.time()
                with self.condicion:
                    self.actual = None
                    self.proceso = None
                    self.pid_propio = None
                    quedan = len(self.cola) and not self.pausado
            if not quedan:
                self._fin_de_tanda()

    def _fin_de_tanda(self):
        """Al vaciarse la cola se recalcula todo sin que nadie lo pida."""
        try:
            resultado = calcula_resultados()
            meta = resultado["meta"]
            self.anota("Tanda terminada. %d combinaciones leidas, %d aptas."
                       % (meta["total_combinaciones"], meta["aptas"]))
        except Exception as exc:
            self.anota("No he podido recalcular los resultados: %s" % exc)

    # -- ejecucion de un trabajo ------------------------------------------
    def _ejecuta(self, trabajo):
        ajenos = terminales_de_la_fabrica(forzar=True)
        if ajenos:
            raise ErrorConflicto(
                "Hay un MetaTrader vivo sobre %s (PID %s). Solo cabe una "
                "instancia por carpeta de datos. Puede ser el terminal del "
                "trabajo anterior, que aun no ha terminado de cerrarse, o uno "
                "que hayas abierto tu: en cualquier caso no lo toco yo."
                % (MT5_DIR, ", ".join(str(p) for p in ajenos)))
        if not os.path.isfile(MT5_EXE):
            raise ErrorConflicto("No encuentro el terminal en %s." % MT5_EXE)

        preparar = trabajo["preparar"]
        ruta_ini = preparar(trabajo)

        self.cola_log.apunta_al_final()
        momento_inicio = time.time()
        trabajo["momento_inicio"] = momento_inicio

        # /portable SOLO si el terminal es portable. Ponerselo a una instalacion
        # normal le hace guardar sus datos junto al programa: se buscaria los
        # .set donde no estan, escribiria el informe donde no lo esperamos y el
        # barrido acabaria sin resultados y sin explicacion.
        orden = [MT5_EXE]
        if MT5_PORTABLE:
            orden.append("/portable")
        orden.append("/config:" + ruta_ini)
        self.anota("Lanzando: %s" % " ".join(orden))
        proceso = subprocess.Popen(orden, cwd=os.path.dirname(MT5_EXE),
                                   stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL)
        with self.condicion:
            self.proceso = proceso
            self.pid_propio = proceso.pid
            trabajo["estado"] = "corriendo"
            trabajo["pid"] = proceso.pid
            trabajo["mensaje"] = "Terminal en marcha (PID %d)." % proceso.pid

        rechazos = 0
        ultimo_aviso_rechazos = 0
        while True:
            if proceso.poll() is not None:
                break
            if time.time() - momento_inicio > MAX_SEGUNDOS_TRABAJO:
                self.anota("El trabajo lleva demasiado tiempo: lo corto.")
                try:
                    proceso.kill()
                except Exception:
                    pass
                trabajo["estado"] = "error"
                trabajo["mensaje"] = "Cortado por exceso de tiempo."
                return
            rechazos, ultimo_aviso_rechazos = self._digiere_log(
                trabajo, rechazos, ultimo_aviso_rechazos)
            time.sleep(0.4)

        # Ultimo sorbo del log: las lineas del final llegan despues de morir.
        time.sleep(0.6)
        self._digiere_log(trabajo, rechazos, ultimo_aviso_rechazos)
        if rechazos:
            self.anota("Total de pasadas rechazadas por parametros incorrectos: "
                       "%d (es normal en el genetico)." % rechazos)

        with self.condicion:
            detenido = self.detener_pedido
        if detenido:
            trabajo["estado"] = "detenido"
            trabajo["mensaje"] = "Detenido por el usuario."
            return

        trabajo["estado"] = "terminado"
        recoger = trabajo.get("recoger")
        if recoger:
            recoger(trabajo)

    def _digiere_log(self, trabajo, rechazos, ultimo_aviso):
        """Lee lo nuevo del log y saca generacion, mejor resultado y pasadas."""
        try:
            lineas = self.cola_log.nuevas()
        except Exception:
            return rechazos, ultimo_aviso
        for cruda in lineas:
            hora, fuente, mensaje = parte_linea_log(cruda)
            if RE_PARAMETROS_MALOS.search(mensaje):
                # Estas salen a miles. Contarlas si, guardarlas todas no:
                # llenarian la memoria y taparian lo que importa.
                rechazos += 1
                if rechazos - ultimo_aviso >= 200:
                    ultimo_aviso = rechazos
                    self.anota("%s  %d pasadas rechazadas por parametros "
                               "incorrectos (normal en el genetico)."
                               % (hora, rechazos))
                continue
            if not any(p.search(mensaje) for p in PATRONES_UTILES):
                continue

            encontrado = RE_MEJOR.search(mensaje)
            if encontrado:
                trabajo["mejor"] = a_float(encontrado.group(1))
                trabajo["generacion"] = int(encontrado.group(2))
            encontrado = RE_PASE_GENETICO.search(mensaje)
            if encontrado:
                trabajo["pasadas"] = int(encontrado.group(1))
            encontrado = RE_TOTAL_PASADAS.search(mensaje)
            if encontrado:
                trabajo["pasadas"] = int(encontrado.group(1))
                trabajo["mensaje"] = mensaje
            self.anota("%s  %s  %s" % (hora, fuente, mensaje))
        return rechazos, ultimo_aviso


MOTOR = None  # se crea en main()


# ---------------------------------------------------------------------------
# PREPARACION Y RECOGIDA DE CADA TIPO DE TRABAJO
# ---------------------------------------------------------------------------

def prepara_barrido(trabajo):
    """Escribe el .set y el .ini del barrido y devuelve la ruta del .ini."""
    par = trabajo["parametros"]
    clave = trabajo["clave"]
    nombre_set = "fabrica_%s.set" % clave
    nombre_xml = "fabrica_%s.xml" % clave
    nombre_ini = "optimizar_%s.ini" % clave

    construye_set_barrido(trabajo["senal"], par["riesgo"], nombre_set)

    ini = texto_ini(
        "Barrido de la senal %d - %s (%s %s)"
        % (trabajo["senal"], trabajo["nombre_senal"], par["simbolo"], par["marco"]),
        [("Expert", r"Fabrica\FabricaEA.ex5"),
         ("ExpertParameters", nombre_set),
         ("Symbol", par["simbolo"]),
         ("Period", par["marco"]),
         ("Model", 1),
         ("FromDate", par["desde"]),
         ("ToDate", par["hasta"]),
         ("ForwardMode", par["forward"]),
         ("Deposit", par["deposito"]),
         ("Currency", "USD"),
         ("Leverage", "1:100"),
         ("Optimization", 2),
         ("OptimizationCriterion", 6),
         ("Visual", 0),
         # RELATIVA a proposito: con ruta absoluta MetaTrader no escribe nada.
         ("Report", nombre_xml),
         ("ReplaceReport", 1),
         ("ShutdownTerminal", 1)])
    ruta_ini = os.path.join(DIR_LOGS, nombre_ini)
    escribe_texto(ruta_ini, ini)

    trabajo["nombre_xml"] = nombre_xml
    trabajo["mensaje"] = "Ficheros listos, arrancando el terminal."
    return ruta_ini


def recoge_barrido(trabajo):
    """Copia el XML (y su forward) de la carpeta de MetaTrader al proyecto."""
    par = trabajo["parametros"]
    nombre_xml = trabajo["nombre_xml"]
    origen = os.path.join(MT5_DIR, nombre_xml)
    if not os.path.isfile(origen):
        trabajo["estado"] = "error"
        trabajo["mensaje"] = (
            "El terminal termino pero no hay informe en %s. Suele significar "
            "que ninguna combinacion fue valida, o que el experto no compilo."
            % origen)
        MOTOR.anota(trabajo["mensaje"])
        return

    # El nombre del forward lo deduce el lector, que es quien manda en esa
    # convencion: aqui no se vuelve a inventar la regla del ".forward.xml".
    rutas = [origen]
    ruta_fwd = lector.deduce_ruta_forward(origen)
    if ruta_fwd:
        rutas.append(ruta_fwd)

    copiados = []
    for ruta_origen in rutas:
        if not os.path.isfile(ruta_origen):
            continue
        nombre = os.path.basename(ruta_origen)
        ruta_destino = os.path.join(DIR_INFORMES, nombre)
        with io.open(ruta_origen, "rb") as lee, io.open(ruta_destino, "wb") as pon:
            pon.write(lee.read())
        copiados.append(nombre)

    anota_barrido(trabajo["clave"], {
        "nombre": "%s (%s %s)" % (trabajo["nombre_senal"], par["simbolo"],
                                  par["marco"]),
        "senal": trabajo["senal"],
        "xml": nombre_xml,
        "set": "fabrica_%s.set" % trabajo["clave"],
        "simbolo": par["simbolo"],
        "marco": par["marco"],
        "desde": par["desde"],
        "hasta": par["hasta"],
        "forward": par["forward"],
        "deposito": par["deposito"],
        "riesgo": par["riesgo"],
        "fecha": ahora_texto(),
    })
    trabajo["mensaje"] = "Informe recogido: %s" % ", ".join(copiados)
    MOTOR.anota(trabajo["mensaje"])


def prepara_verificacion(trabajo):
    """Escribe el .set con los genes fijos y el .ini del test individual."""
    candidato = trabajo["candidato"]
    info = trabajo["info_origen"]

    set_base = os.path.join(DIR_SETS, info.get("set") or
                            ("fabrica_%s.set" % candidato.get("origen")))
    construye_set_verificacion(candidato, set_base, "fabrica_verificar.set")

    # El XML del barrido corresponde SOLO al tramo de busqueda: si el barrido
    # reservo un forward, comparar contra un test que abarque tambien el tramo
    # reservado no tendria ningun sentido. Se recorta el periodo igual que lo
    # recorto MetaTrader.
    desde = dt.datetime.strptime(info["desde"], "%Y.%m.%d").date()
    hasta = dt.datetime.strptime(info["hasta"], "%Y.%m.%d").date()
    corte = fecha_de_corte(desde, hasta, info.get("forward", 0))

    ini = texto_ini(
        "Verificacion individual de la pasada %s del barrido %s"
        % (candidato.get("pass"), candidato.get("origen")),
        [("Expert", r"Fabrica\FabricaEA.ex5"),
         ("ExpertParameters", "fabrica_verificar.set"),
         ("Symbol", info["simbolo"]),
         ("Period", info["marco"]),
         ("Model", 1),
         ("FromDate", info["desde"]),
         ("ToDate", corte.strftime("%Y.%m.%d")),
         ("ForwardMode", 0),
         ("Deposit", info.get("deposito", 10000)),
         ("Currency", "USD"),
         ("Leverage", "1:100"),
         ("Optimization", 0),
         ("Visual", 0),
         ("Report", "fabrica_verificar.htm"),
         ("ReplaceReport", 1),
         ("ShutdownTerminal", 1)])
    ruta_ini = os.path.join(DIR_LOGS, "verificar.ini")
    escribe_texto(ruta_ini, ini)

    trabajo["periodo"] = {"desde": info["desde"], "hasta": corte.strftime("%Y.%m.%d")}
    trabajo["mensaje"] = ("Test individual de la pasada %s, de %s a %s."
                          % (candidato.get("pass"), info["desde"],
                             corte.strftime("%Y.%m.%d")))
    return ruta_ini


def recoge_verificacion(trabajo):
    """Busca la linea JUEZ| del test y la compara con lo que decia el XML."""
    candidato = trabajo["candidato"]
    esperado = {
        "pass": candidato.get("pass"),
        "origen": candidato.get("origen"),
        "puntuacion": candidato.get("puntuacion"),
        "beneficio": candidato.get("beneficio"),
        "factor_beneficio": candidato.get("factor_beneficio"),
        "operaciones": candidato.get("operaciones"),
        "caida_pct": candidato.get("caida_pct"),
        "genes": candidato.get("genes") or {},
    }
    linea = busca_linea_juez(trabajo.get("momento_inicio", time.time()))
    obtenido = interpreta_juez(linea) or {}
    diferencias = compara_verificacion(esperado, obtenido)

    resultado = {
        "ok": True,
        "id": trabajo["id"],
        "fecha": ahora_texto(),
        "periodo": trabajo.get("periodo"),
        "esperado": esperado,
        "obtenido": obtenido,
        "coincide": not diferencias,
        "diferencias": diferencias,
        "informe": os.path.join(MT5_DIR, "fabrica_verificar.htm"),
    }
    MOTOR.verificacion = resultado
    try:
        escribe_json(RUTA_VERIFICACION, resultado)
    except OSError:
        pass
    trabajo["mensaje"] = ("La verificacion REPRODUCE el XML."
                          if not diferencias else
                          "La verificacion NO coincide: %s" % diferencias[0])
    MOTOR.anota(trabajo["mensaje"])


# ---------------------------------------------------------------------------
# LAS OPERACIONES DE LA API
# ---------------------------------------------------------------------------

def api_estado():
    pids = terminales_de_la_fabrica()
    with MOTOR.condicion:
        pid_propio = MOTOR.pid_propio
        pausado = MOTOR.pausado
    return {
        "ok": True,
        "terminal": {
            "ruta": MT5_DIR,
            "nombre": TERMINAL["nombre"] if TERMINAL else "",
            "portable": bool(MT5_PORTABLE),
            "brokers": TERMINAL["brokers"] if TERMINAL else [],
            "ea_en_graficos": TERMINAL["ea_en_graficos"] if TERMINAL else [],
            "avisos": TERMINAL["avisos"] if TERMINAL else [],
            "ejecutando": bool(pids),
            "pid": (pid_propio if pid_propio in pids else (pids[0] if pids else None)),
            # 'propio' distingue el terminal que hemos lanzado nosotros del que
            # pueda haber abierto el usuario a mano: solo el primero se puede
            # detener desde aqui.
            "propio": bool(pid_propio and pid_propio in pids),
        },
        "trabajo": MOTOR.estado_trabajo(),
        "cola": MOTOR.resumen_cola(),
        "pausado": pausado,
        "barridos": resumen_barridos(),
        "biblioteca": {"total": total_biblioteca()},
    }


def api_lanzar(cuerpo):
    if not isinstance(cuerpo, dict):
        raise ErrorPeticion("El cuerpo tiene que ser un objeto JSON.")

    senales = exige_senales(cuerpo.get("senales"))
    simbolo = exige_simbolo(cuerpo.get("simbolo", "EURUSD"))
    marco = exige_marco(cuerpo.get("marco", "H1"))
    desde_txt, desde = exige_fecha(cuerpo.get("desde", "2018.01.01"), "La fecha 'desde'")
    hasta_txt, hasta = exige_fecha(cuerpo.get("hasta", "2025.12.31"), "La fecha 'hasta'")
    if desde >= hasta:
        raise ErrorPeticion("La fecha 'desde' (%s) tiene que ser anterior a "
                            "'hasta' (%s)." % (desde_txt, hasta_txt))
    if (hasta - desde).days < 60:
        raise ErrorPeticion("El periodo es demasiado corto (%d dias). Con menos "
                            "de dos meses no hay estadistica que valga."
                            % (hasta - desde).days)
    forward = exige_numero(cuerpo.get("forward", 3), "El modo de forward", 0, 4,
                           entero=True)
    if forward == 4:
        raise ErrorPeticion(
            "El modo de forward 4 (fecha a mano) necesita una fecha de corte "
            "que este API no contempla. Usa 0 (sin reserva), 1 (la mitad), "
            "2 (un tercio) o 3 (un cuarto).")
    deposito = exige_numero(cuerpo.get("deposito", 10000), "El deposito",
                            100, 10000000, entero=True)
    riesgo = exige_numero(cuerpo.get("riesgo", 0.5), "El riesgo", 0.01, 10.0)

    # Contrato: si hay un terminal vivo en esa carpeta de datos, no se lanza.
    pids = terminales_de_la_fabrica(forzar=True)
    if pids:
        with MOTOR.condicion:
            propio = MOTOR.pid_propio in pids
        if propio:
            raise ErrorConflicto(
                "Ya hay una tanda en marcha (PID %s). Espera a que termine o "
                "pulsa detener." % MOTOR.pid_propio)
        raise ErrorConflicto(
            "Hay un MetaTrader abierto sobre %s (PID %s) que yo no he lanzado. "
            "Solo cabe una instancia por carpeta de datos, y no voy a tocar un "
            "terminal que no es mio: cierralo tu y vuelve a intentarlo."
            % (MT5_DIR, ", ".join(str(p) for p in pids)))

    parametros = {"simbolo": simbolo, "marco": marco, "desde": desde_txt,
                  "hasta": hasta_txt, "forward": forward, "deposito": deposito,
                  "riesgo": riesgo}

    trabajos = []
    for indice in senales:
        clave_senal, nombre_senal = generar_barridos.SENALES[indice][0:2]
        clave = "%s_%s_%s" % (clave_senal, simbolo, marco)
        trabajos.append({
            "id": MOTOR.nuevo_id(),
            "tipo": "barrido",
            "senal": indice,
            "clave": clave,
            "nombre_senal": nombre_senal,
            "nombre": "%s (%s %s)" % (nombre_senal, simbolo, marco),
            "parametros": parametros,
            "estado": "en cola",
            "mensaje": "En cola.",
            "generacion": None, "mejor": None, "pasadas": None,
            "preparar": prepara_barrido,
            "recoger": recoge_barrido,
        })
    MOTOR.encola(trabajos)
    MOTOR.anota("Encolados %d barridos de %s en %s." % (len(trabajos), simbolo, marco))
    return {"ok": True, "encolados": len(trabajos),
            "ids": [t["id"] for t in trabajos]}


def api_verificar(cuerpo):
    if not isinstance(cuerpo, dict):
        raise ErrorPeticion("El cuerpo tiene que ser un objeto JSON.")
    origen = str(cuerpo.get("origen") or "").strip()
    if not origen or not re.match(r"^[A-Za-z0-9._-]{1,64}$", origen):
        raise ErrorPeticion("Origen no valido: %r." % cuerpo.get("origen"))
    pasada = exige_numero(cuerpo.get("pass"), "La pasada", 0, 10 ** 9, entero=True)

    candidato = busca_candidato(origen, pasada)
    if candidato is None:
        raise ErrorPeticion("No encuentro la pasada %s del barrido %s."
                            % (pasada, origen))

    registro = registro_barridos()
    info = dict(registro.get(origen) or {})
    if not info.get("desde"):
        # Barridos antiguos, anteriores al registro: se puede verificar igual
        # si esta el .set, pero con el periodo por defecto y avisando.
        base = os.path.join(DIR_SETS, "fabrica_%s.set" % origen)
        if not os.path.isfile(base):
            raise ErrorPeticion(
                "No tengo constancia de como se genero el barrido %s (ni "
                "registro ni .set en sets/). No puedo reproducir su periodo, y "
                "verificar con otro periodo seria comparar peras con manzanas."
                % origen)
        info.setdefault("set", "fabrica_%s.set" % origen)
        info.setdefault("simbolo", "EURUSD")
        info.setdefault("marco", "H1")
        info.setdefault("desde", generar_barridos.DESDE)
        info.setdefault("hasta", generar_barridos.HASTA)
        info.setdefault("forward", 3)
        info.setdefault("deposito", 10000)

    pids = terminales_de_la_fabrica(forzar=True)
    if pids:
        raise ErrorConflicto(
            "Hay un MetaTrader vivo sobre %s (PID %s). Espera a que acabe "
            "antes de verificar." % (MT5_DIR, ", ".join(str(p) for p in pids)))

    trabajo = {
        "id": MOTOR.nuevo_id(),
        "tipo": "verificacion",
        "clave": "verificar_%s_%s" % (origen, pasada),
        "nombre": "Verificacion de %s pasada %s" % (origen, pasada),
        "candidato": candidato,
        "info_origen": info,
        "estado": "en cola",
        "mensaje": "En cola.",
        "generacion": None, "mejor": None, "pasadas": None,
        "preparar": prepara_verificacion,
        "recoger": recoge_verificacion,
    }
    MOTOR.encola([trabajo])
    return {"ok": True, "estado": "corriendo", "id": trabajo["id"]}


def api_terminales():
    """La lista de MetaTrader que hay en esta maquina, con sus avisos.

    Se vuelve a buscar en cada llamada a proposito: el usuario puede haber
    instalado un terminal, o abierto por fin la cuenta demo que le faltaba,
    mientras la consola estaba abierta. La busqueda tarda menos de un segundo
    salvo que haya que rastrear discos, y no se llama sola: solo cuando alguien
    abre el desplegable de terminales.
    """
    encontrados = detectar_mt5.buscar_terminales()
    fichas = [resumen_terminal(f) for f in encontrados]

    # El terminal en uso puede haber llegado por --terminal y no estar entre
    # los detectados (una carpeta rara, un disco de red...). Aun asi tiene que
    # salir en la lista, o la consola ensenaria un desplegable donde no esta el
    # que se esta usando.
    if TERMINAL and not any(f["en_uso"] for f in fichas):
        fichas.insert(0, resumen_terminal(TERMINAL))
    return {"ok": True, "terminales": fichas,
            "en_uso": TERMINAL["datos"] if TERMINAL else None}


def api_terminal_post(cuerpo):
    """Cambia de terminal sin cerrar el servidor.

    Dos cautelas:
      - No se cambia con trabajo en marcha o en cola. A mitad de una tanda, el
        .set esta en la carpeta de un terminal y el informe se esperaria en la
        de otro: el barrido moriria sin dejar rastro de por que.
      - La ruta que llega del cliente NO se usa tal cual: se vuelve a examinar
        con detectar_mt5, y solo se acepta si resulta ser un MetaTrader 5 apto
        de verdad. Asi una ruta cualquiera no convierte a este servidor en una
        herramienta para escribir ficheros donde le digan.
    """
    if not isinstance(cuerpo, dict):
        raise ErrorPeticion("El cuerpo tiene que ser un objeto JSON.")
    ruta = str(cuerpo.get("datos") or "").strip()
    if not ruta:
        raise ErrorPeticion("Falta 'datos': la carpeta del terminal que quieres "
                            "usar.")
    if len(ruta) > 500:
        raise ErrorPeticion("Esa ruta es absurdamente larga.")

    with MOTOR.condicion:
        ocupado = MOTOR.actual is not None or bool(MOTOR.cola)
    if ocupado:
        raise ErrorConflicto(
            "Hay trabajo en marcha o en cola. No se puede cambiar de terminal a "
            "mitad de una tanda: espera a que acabe o vacia la cola.")

    ficha = detectar_mt5.examina_ruta(ruta)
    if ficha is None:
        raise ErrorPeticion(
            "En esa carpeta no hay ningun MetaTrader 5: %s. Dame la carpeta de "
            "datos del terminal (la que tiene MQL5 dentro) o la carpeta donde "
            "esta terminal64.exe." % ruta)
    if not ficha["apto"]:
        raise ErrorPeticion(
            "Ese terminal no sirve tal y como esta. %s"
            % (" ".join(ficha["avisos"]) or "No se por que, pero no pasa las "
                                            "comprobaciones."))

    aplica_terminal(ficha)
    MOTOR.anota("Terminal cambiado a %s (%s)." % (ficha["nombre"], ficha["datos"]))
    # Si ese terminal esta abierto ahora mismo no se impide el cambio -es el
    # propio usuario quien decide-, pero se le dice, porque hasta que lo cierre
    # no va a poder lanzar nada.
    abierto = bool(terminales_de_la_fabrica(forzar=True))
    if abierto:
        MOTOR.anota("OJO: ese terminal esta abierto ahora mismo. Cierralo antes "
                    "de lanzar una tanda.")
    return {"ok": True, "terminal": resumen_terminal(ficha), "ejecutando": abierto}


def api_biblioteca_post(cuerpo):
    if not isinstance(cuerpo, dict):
        raise ErrorPeticion("El cuerpo tiene que ser un objeto JSON.")
    accion = str(cuerpo.get("accion") or "").strip().lower()
    clave = str(cuerpo.get("clave") or "").strip()
    if accion not in ("guardar", "borrar"):
        raise ErrorPeticion("Accion no valida: %r. Solo 'guardar' o 'borrar'."
                            % cuerpo.get("accion"))
    if not clave or len(clave) > 200:
        raise ErrorPeticion("Clave no valida.")
    if accion == "guardar":
        total = biblioteca_guardar(clave)
    else:
        total = biblioteca_borrar(clave)
    return {"ok": True, "total": total}


# ---------------------------------------------------------------------------
# EL SERVIDOR HTTP
# ---------------------------------------------------------------------------

class Servidor(ThreadingHTTPServer):
    daemon_threads = True
    # OJO: en Windows SO_REUSEADDR permite que DOS procesos se aten al MISMO
    # puerto sin quejarse, y entonces las peticiones caen en uno o en otro al
    # azar. Con esto a False, atar un puerto ocupado falla como debe y la
    # busqueda de puerto libre funciona de verdad.
    allow_reuse_address = False


class Manejador(BaseHTTPRequestHandler):
    server_version = "FabricaLocal/1.0"
    protocol_version = "HTTP/1.1"

    # -- utilidades de respuesta ------------------------------------------
    def responde_bytes(self, datos, tipo, codigo=200, cabeceras=None):
        try:
            self.send_response(codigo)
            self.send_header("Content-Type", tipo)
            self.send_header("Content-Length", str(len(datos)))
            self.send_header("Cache-Control", "no-store")
            # Sin cabeceras CORS a proposito: asi ninguna pagina de internet
            # abierta en el mismo navegador puede leer lo que responde este
            # servidor.
            self.send_header("X-Content-Type-Options", "nosniff")
            for nombre, valor in (cabeceras or {}).items():
                self.send_header(nombre, valor)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(datos)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            # El navegador se ha ido a mitad (recarga, cierre de pestana).
            # No es un error del servidor: no hay nada que hacer ni que gritar.
            pass

    def responde_json(self, objeto, codigo=200):
        datos = json.dumps(objeto, ensure_ascii=False, default=str).encode("utf-8")
        self.responde_bytes(datos, "application/json; charset=utf-8", codigo)

    def responde_error(self, mensaje, codigo=400):
        self.responde_json({"ok": False, "error": mensaje}, codigo)

    def host_valido(self):
        """Solo se atiende a quien nos llama por nuestro nombre local.

        Defensa contra el 'DNS rebinding': una web externa que resuelva su
        dominio a 127.0.0.1 para hablar con este servidor desde el navegador
        del usuario. Si la cabecera Host no es la local, no se contesta.
        """
        host = (self.headers.get("Host") or "").split(":")[0].strip().lower()
        return host in ("127.0.0.1", "localhost", "[::1]", "::1", "")

    # -- rutas -------------------------------------------------------------
    def do_GET(self):
        self.atiende("GET")

    def do_HEAD(self):
        self.atiende("GET")

    def do_POST(self):
        self.atiende("POST")

    def atiende(self, metodo):
        try:
            if not self.host_valido():
                self.responde_error("Peticion rechazada: este servidor solo "
                                    "atiende en 127.0.0.1.", 403)
                return
            partes = urlparse(self.path)
            ruta = partes.path
            if metodo == "GET":
                self.enruta_get(ruta, parse_qs(partes.query))
            else:
                self.enruta_post(ruta)
        except ErrorPeticion as exc:
            self.responde_error(str(exc), 400)
        except ErrorConflicto as exc:
            self.responde_error(str(exc), 409)
        except lector.LectorError as exc:
            self.responde_error("Problema leyendo un informe: %s" % exc, 500)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        except Exception as exc:
            # Nada de volcar la excepcion al navegador: un mensaje legible y
            # el detalle por consola para quien este mirando.
            print("  [aviso] fallo atendiendo %s %s: %s: %s"
                  % (metodo, self.path, type(exc).__name__, exc))
            try:
                self.responde_error("Fallo interno atendiendo la peticion: "
                                    "%s: %s" % (type(exc).__name__, exc), 500)
            except Exception:
                pass

    def enruta_get(self, ruta, consulta):
        if ruta in ESTATICOS:
            self.sirve_estatico(ESTATICOS[ruta])
            return
        if ruta == "/favicon.ico":
            self.responde_bytes(b"", "image/x-icon", 204)
            return

        if ruta == "/api/estado":
            self.responde_json(api_estado())
            return
        if ruta == "/api/terminales":
            self.responde_json(api_terminales())
            return
        if ruta == "/api/progreso":
            bruto = (consulta.get("desde") or ["0"])[0]
            try:
                desde = max(0, int(bruto))
            except ValueError:
                raise ErrorPeticion("El parametro 'desde' tiene que ser un entero.")
            lineas, siguiente = MOTOR.progreso(desde)
            self.responde_json({"ok": True, "lineas": lineas,
                                "siguiente": siguiente})
            return
        if ruta == "/api/resultados":
            self.responde_json(resultados_para_respuesta(calcula_resultados()))
            return
        if ruta == "/api/biblioteca":
            datos = carga_biblioteca()
            self.responde_json({"ok": True,
                                "total": len(datos["entradas"]),
                                "candidatos": datos["entradas"]})
            return
        if ruta == "/api/verificacion":
            if not MOTOR.verificacion:
                self.responde_json({"ok": False,
                                    "error": "Todavia no se ha verificado nada."},
                                   404)
                return
            self.responde_json(MOTOR.verificacion)
            return

        self.responde_error("No existe esa direccion: %s" % ruta, 404)

    def enruta_post(self, ruta):
        cuerpo = self.lee_cuerpo()

        if ruta == "/api/lanzar":
            self.responde_json(api_lanzar(cuerpo))
            return
        if ruta == "/api/terminal":
            self.responde_json(api_terminal_post(cuerpo))
            return
        if ruta == "/api/detener":
            detenido = MOTOR.detener()
            self.responde_json({"ok": True, "detenido": detenido,
                                "en_cola": len(MOTOR.cola)})
            return
        if ruta == "/api/vaciar_cola":
            self.responde_json({"ok": True, "eliminados": MOTOR.vacia_cola()})
            return
        if ruta == "/api/resultados":
            puertas = exige_puertas((cuerpo or {}).get("puertas"))
            self.responde_json(resultados_para_respuesta(calcula_resultados(puertas)))
            return
        if ruta == "/api/biblioteca":
            self.responde_json(api_biblioteca_post(cuerpo))
            return
        if ruta == "/api/biblioteca/absorber":
            anadidas, total = biblioteca_absorber()
            self.responde_json({"ok": True, "anadidas": anadidas, "total": total})
            return
        if ruta == "/api/verificar":
            self.responde_json(api_verificar(cuerpo))
            return

        self.responde_error("No existe esa direccion: %s" % ruta, 404)

    def lee_cuerpo(self):
        try:
            largo = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ErrorPeticion("Content-Length no es un numero.")
        if largo < 0 or largo > MAX_CUERPO:
            raise ErrorPeticion("El cuerpo de la peticion es demasiado grande.")
        if largo == 0:
            return {}
        bruto = self.rfile.read(largo)
        try:
            datos = json.loads(bruto.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise ErrorPeticion("El cuerpo no es JSON valido: %s" % exc)
        return datos

    def sirve_estatico(self, nombre):
        """Sirve un fichero de la LISTA BLANCA. Nunca una ruta del cliente."""
        ruta = os.path.join(RAIZ, nombre)
        if not os.path.isfile(ruta):
            if nombre == "consola.html":
                self.responde_bytes(PAGINA_SIN_CONSOLA.encode("utf-8"),
                                    "text/html; charset=utf-8", 200)
                return
            self.responde_error("Falta el fichero %s en %s." % (nombre, RAIZ), 404)
            return
        try:
            with io.open(ruta, "rb") as fh:
                datos = fh.read()
        except OSError as exc:
            self.responde_error("No he podido leer %s: %s" % (nombre, exc), 500)
            return
        self.responde_bytes(datos, "text/html; charset=utf-8")

    def log_message(self, formato, *args):
        """Silencio para lo normal: el usuario quiere ver el barrido, no el trafico."""
        return


PAGINA_SIN_CONSOLA = u"""<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<title>Fabrica - falta la consola</title>
<style>body{font-family:system-ui,Segoe UI,sans-serif;max-width:44rem;
margin:4rem auto;padding:0 1.5rem;line-height:1.6;color:#1c1c1c}
code{background:#f0f0f0;padding:.1rem .35rem;border-radius:.2rem}</style>
</head><body>
<h1>El servidor esta en marcha</h1>
<p>Pero todavia no existe <code>consola.html</code> en la carpeta del proyecto,
asi que no hay panel de mandos que ensenarte.</p>
<p>La API si responde. Puedes comprobarlo aqui mismo:
<a href="/api/estado">/api/estado</a>.</p>
<p>Si lo que buscas es el panel de resultados de siempre, esta en
<a href="/panel.html">/panel.html</a>.</p>
</body></html>
"""


# ---------------------------------------------------------------------------
# ARRANQUE
# ---------------------------------------------------------------------------

def abre_puerto(preferido, intentos=20):
    """Prueba puertos consecutivos hasta encontrar uno libre en 127.0.0.1."""
    ultimo_fallo = None
    for desplazamiento in range(intentos):
        puerto = preferido + desplazamiento
        try:
            # SOLO 127.0.0.1. Nunca 0.0.0.0: atarse a todas las interfaces
            # dejaria este servidor -que lanza programas- al alcance de
            # cualquiera que este en la misma red.
            servidor = Servidor(("127.0.0.1", puerto), Manejador)
            return servidor, puerto, desplazamiento
        except OSError as exc:
            ultimo_fallo = exc
            continue
    raise SystemExit("No he encontrado ningun puerto libre entre %d y %d (%s)."
                     % (preferido, preferido + intentos - 1, ultimo_fallo))


def main(argv=None):
    global MOTOR

    analizador = argparse.ArgumentParser(
        description="Servidor local de la fabrica de estrategias.")
    analizador.add_argument("--puerto", type=int, default=8765,
                            help="Puerto de escucha (por defecto 8765).")
    analizador.add_argument("--no-abrir", action="store_true",
                            help="No abrir el navegador al arrancar.")
    detectar_mt5.anade_argumento_terminal(analizador)
    args = analizador.parse_args(argv)

    if not (1024 <= args.puerto <= 65000):
        raise SystemExit("Puerto fuera de rango: %d. Elige uno entre 1024 y 65000."
                         % args.puerto)

    for carpeta in (DIR_SETS, DIR_LOGS, DIR_INFORMES):
        if not os.path.isdir(carpeta):
            os.makedirs(carpeta)

    # Esto va ANTES de crear el motor: el motor se apunta al log del Probador
    # del terminal elegido, y para eso el terminal tiene que estar elegido ya.
    # Si no hay ninguno servible, exige_terminal corta aqui explicando que
    # falta MetaTrader 5 y una cuenta abierta.
    aplica_terminal(detectar_mt5.exige_terminal(args.terminal))

    MOTOR = Motor()

    servidor, puerto, desplazamiento = abre_puerto(args.puerto)
    direccion = "http://127.0.0.1:%d/" % puerto

    print("=" * 68)
    print(" FABRICA DE ESTRATEGIAS - servidor local")
    print("=" * 68)
    if desplazamiento:
        print(" El puerto %d estaba ocupado. He cogido el %d."
              % (args.puerto, puerto))
    print(" Escuchando SOLO en 127.0.0.1 (nadie de fuera puede entrar).")
    print(" Direccion: %s" % direccion)
    print(" Proyecto : %s" % RAIZ)
    print(" Terminal : %s" % TERMINAL["nombre"])
    print(" Datos    : %s" % MT5_DIR)
    print(" Programa : %s%s" % (MT5_EXE, "  (portable)" if MT5_PORTABLE else ""))
    if not os.path.isfile(MT5_EXE):
        print(" AVISO: no encuentro %s. Los barridos fallaran hasta que este."
              % MT5_EXE)
    robot = os.path.join(MT5_DIR, "MQL5", "Experts", "Fabrica", "FabricaEA.ex5")
    if not os.path.isfile(robot):
        print(" AVISO: el robot de la fabrica no esta compilado en ese terminal.")
        print("        Falta %s" % robot)
        print("        Cierra esto y arranca con EMPEZAR.bat: el solo lo copia")
        print("        y lo compila.")
    if TERMINAL["ea_en_graficos"]:
        print(" AVISO IMPORTANTE: ese terminal tiene %d robot(s) pegados a sus"
              % len(TERMINAL["ea_en_graficos"]))
        print("        graficos (%s)." % ", ".join(TERMINAL["ea_en_graficos"]))
        print("        La fabrica lo arranca siempre con el trading automatico")
        print("        DESACTIVADO, asi que no va a operar. Pero no lo abras tu")
        print("        a mano sin quitarles antes el robot al grafico.")
    vivos = terminales_de_la_fabrica(forzar=True)
    if vivos:
        print(" AVISO: ya hay un MetaTrader abierto en esa carpeta (PID %s)."
              % ", ".join(str(p) for p in vivos))
        print("        Cierralo antes de lanzar: solo cabe una instancia.")
    print("")
    print(" Se cierra con Ctrl+C.")
    print("=" * 68)
    # Si alguien redirige la salida a un fichero, Python la guarda en un buffer
    # y el aviso no aparece hasta mucho despues. Aqui interesa verlo ya.
    sys.stdout.flush()

    if not args.no_abrir:
        threading.Timer(0.6, lambda: webbrowser.open(direccion)).start()

    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\n Cerrando el servidor...")
    finally:
        servidor.server_close()
        with MOTOR.condicion:
            proceso = MOTOR.proceso
        if proceso is not None and proceso.poll() is None:
            # No se mata: puede estar a mitad de un barrido de horas. El .ini
            # lleva ShutdownTerminal=1, asi que el terminal se cerrara solo al
            # acabar. Se avisa para que nadie se lleve una sorpresa.
            print(" OJO: el terminal sigue optimizando (PID %d). Se cerrara "
                  "solo al terminar." % proceso.pid)
        print(" Hasta luego.")


if __name__ == "__main__":
    main()
