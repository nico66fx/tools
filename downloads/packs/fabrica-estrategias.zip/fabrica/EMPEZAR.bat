@echo off
rem ===================================================================
rem  FABRICA DE ESTRATEGIAS - ESTE ES EL UNICO FICHERO QUE HAY QUE TOCAR
rem
rem  Doble clic y ya. Este fichero:
rem     1. Se coloca en su propia carpeta.
rem     2. Comprueba que tienes Python 3.
rem     3. Busca MetaTrader 5 en tu ordenador y te dice cual va a usar.
rem     4. Copia el robot de la fabrica dentro de ese MetaTrader y lo
rem        compila, pero solo si hace falta.
rem     5. Arranca la consola y te abre el navegador.
rem
rem  El "cd /d %~dp0" del principio no es un adorno: al hacer doble clic,
rem  Windows puede dejarte en C:\Windows\System32 como carpeta actual, y
rem  ahi no esta nada de esto. %~dp0 es la carpeta de ESTE fichero, sea
rem  cual sea el disco donde lo hayas dejado.
rem
rem  Los "pause" tampoco son adorno: sin ellos, cuando algo va mal la
rem  ventana se cierra de golpe y te quedas sin leer el motivo.
rem ===================================================================
title Fabrica de estrategias
cd /d "%~dp0"
color 07

echo.
echo  ==================================================================
echo   F A B R I C A   D E   E S T R A T E G I A S
echo                                         por @nico66fx
echo  ==================================================================
echo.

rem -------------------------------------------------------------------
rem  1. TIENES PYTHON?
rem -------------------------------------------------------------------
rem  Se prueba primero con "py -3", que es el lanzador oficial de Windows
rem  y nunca se confunde de version. Si no esta, se prueba "python", pero
rem  comprobando que de verdad es un Python 3: en algunos Windows el
rem  nombre "python" es un atajo de la tienda de aplicaciones que no
rem  ejecuta nada.
rem -------------------------------------------------------------------
set "PY="
py -3 -c "import sys" >nul 2>&1 && set "PY=py -3"
if not defined PY (
    python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 7) else 1)" >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo   NO TIENES PYTHON, O WINDOWS NO SABE DONDE ESTA.
    echo.
    echo   Python es gratis y se instala en dos minutos:
    echo.
    echo       https://www.python.org/downloads/
    echo.
    echo   IMPORTANTE: en la primera pantalla del instalador, marca la
    echo   casilla que pone "Add python.exe to PATH" antes de darle a
    echo   instalar. Es la casilla de abajo del todo, y sin ella Windows
    echo   no encuentra Python despues.
    echo.
    echo   Cuando lo tengas instalado, vuelve a hacer doble clic aqui.
    echo.
    pause
    exit /b 1
)
echo   [1/4] Python encontrado.

rem -------------------------------------------------------------------
rem  2. DONDE ESTA TU METATRADER 5
rem -------------------------------------------------------------------
rem  Lo busca detectar_mt5.py y devuelve lineas CLAVE=VALOR que este
rem  fichero convierte en variables. Si no encuentra ninguno servible,
rem  no devuelve nada y el mensaje explicando que falta sale por la
rem  pantalla directamente desde Python.
rem -------------------------------------------------------------------
echo   [2/4] Buscando MetaTrader 5 en este ordenador...
echo.
set "FABRICA_DATOS="
set "FABRICA_EXE="
set "FABRICA_EDITOR="
set "FABRICA_NOMBRE="
set "FABRICA_PORTABLE=0"
set "FABRICA_CUENTAS="
set "FABRICA_ROBOTS=0"
for /f "usebackq delims=" %%L in (`%PY% detectar_mt5.py --para-bat`) do set "%%L"

if not defined FABRICA_DATOS (
    echo.
    echo  ------------------------------------------------------------------
    echo   No puedo seguir sin un MetaTrader 5 utilizable. Arriba tienes
    echo   explicado que le falta.
    echo.
    echo   Si quieres ver la lista completa de lo que hay en tu ordenador:
    echo       %PY% detectar_mt5.py
    echo  ------------------------------------------------------------------
    echo.
    pause
    exit /b 1
)

echo   Voy a usar este:
echo       %FABRICA_NOMBRE%
echo       Carpeta : %FABRICA_DATOS%
echo       Cuentas : %FABRICA_CUENTAS%
if not "%FABRICA_ROBOTS%"=="0" (
    echo.
    echo   AVISO: ese MetaTrader tiene %FABRICA_ROBOTS% robot^(s^) pegados a sus
    echo   graficos. La fabrica lo arranca siempre con el trading
    echo   automatico DESACTIVADO, asi que no va a operar. Pero si abres
    echo   tu ese terminal a mano, quitales antes el robot al grafico.
)
echo.

rem -------------------------------------------------------------------
rem  3. EL ROBOT DE LA FABRICA, DENTRO DE TU METATRADER Y COMPILADO
rem -------------------------------------------------------------------
rem  MetaTrader solo ejecuta lo que vive dentro de su propia carpeta
rem  MQL5\Experts, asi que hay que copiarlo ahi. Y solo entiende el .ex5
rem  compilado, no el .mq5 con el codigo.
rem -------------------------------------------------------------------
echo   [3/4] Preparando el robot...
set "DESTINO=%FABRICA_DATOS%\MQL5\Experts\Fabrica"
if not exist "%DESTINO%" mkdir "%DESTINO%"
if not exist "%DESTINO%" (
    echo   No he podido crear la carpeta:
    echo       %DESTINO%
    echo   Comprueba que ese MetaTrader es tuyo y que se puede escribir en el.
    echo.
    pause
    exit /b 1
)
if not exist "logs" mkdir "logs"

copy /y "FabricaEA.mq5" "%DESTINO%\FabricaEA.mq5" >nul
if errorlevel 1 goto :sincopiar
copy /y "JuezRobustez.mqh" "%DESTINO%\JuezRobustez.mqh" >nul
if errorlevel 1 goto :sincopiar
goto :copiado

:sincopiar
echo   No he podido copiar el robot a:
echo       %DESTINO%
echo   Lo mas probable es que MetaTrader este abierto usando ese fichero:
echo   cierralo y vuelve a intentarlo.
echo.
pause
exit /b 1

:copiado
rem  Compilar tarda un segundo, pero no hay que hacerlo cada vez. Se mira
rem  cual de los tres ficheros es el mas reciente: si el que gana es el
rem  .ex5 ya compilado, es que el codigo no ha cambiado desde entonces y
rem  no hay nada que hacer.
set "NUEVO="
for /f "delims=" %%F in ('dir /b /o-d "%DESTINO%\FabricaEA.ex5" "%DESTINO%\FabricaEA.mq5" "%DESTINO%\JuezRobustez.mqh" 2^>nul') do if not defined NUEVO set "NUEVO=%%F"

if /i "%NUEVO%"=="FabricaEA.ex5" (
    echo   El robot ya estaba compilado y al dia. No toco nada.
    goto :listo
)

if not defined FABRICA_EDITOR (
    echo.
    echo   AVISO: no encuentro MetaEditor junto a tu MetaTrader, asi que no
    echo   puedo compilar el robot yo. Hazlo tu una vez:
    echo     - Abre MetaTrader y pulsa F4: se abre el MetaEditor.
    echo     - En el navegador de la izquierda busca Expert Advisors,
    echo       carpeta Fabrica, fichero FabricaEA.mq5.
    echo     - Abrelo y pulsa F7 para compilarlo.
    echo   Sigo arrancando la consola de todas formas.
    echo.
    goto :listo
)

echo   Compilando el robot... ^(esto tarda un par de segundos^)
rem  El /portable solo va si tu MetaTrader es portable. Ponerselo a uno
rem  normal le haria buscar sus cosas donde no estan.
set "MODOPORT="
if "%FABRICA_PORTABLE%"=="1" set "MODOPORT=/portable"
"%FABRICA_EDITOR%" %MODOPORT% /compile:"%DESTINO%\FabricaEA.mq5" /inc:"%FABRICA_DATOS%\MQL5" /log:"%CD%\logs\compilar.log"

rem  OJO: MetaEditor devuelve codigo de error 1 incluso cuando compila
rem  perfectamente, asi que su codigo de salida no sirve para nada. Lo que
rem  si sirve es mirar si el .ex5 ha quedado como el fichero mas reciente.
set "NUEVO="
for /f "delims=" %%F in ('dir /b /o-d "%DESTINO%\FabricaEA.ex5" "%DESTINO%\FabricaEA.mq5" "%DESTINO%\JuezRobustez.mqh" 2^>nul') do if not defined NUEVO set "NUEVO=%%F"

if /i "%NUEVO%"=="FabricaEA.ex5" (
    echo   Robot compilado correctamente.
    goto :listo
)

echo.
echo   LA COMPILACION HA FALLADO. Esto es lo que dijo el compilador:
echo  ------------------------------------------------------------------
if exist "logs\compilar.log" type "logs\compilar.log"
echo  ------------------------------------------------------------------
echo   El informe completo esta en:  %CD%\logs\compilar.log
echo   Sin robot compilado los barridos no van a dar resultados, asi que
echo   no sigo.
echo.
pause
exit /b 1

:listo
echo.
echo   [4/4] Arrancando la consola. Se abrira sola en tu navegador.
echo.
echo   Para PARAR la fabrica: vuelve a esta ventana y pulsa Ctrl+C, o
echo   cierrala directamente.
echo.
echo  ==================================================================
echo.

rem  El servidor abre el navegador el solo al arrancar. Se le pasa el
rem  terminal ya elegido para que no lo busque otra vez.
%PY% servidor.py --terminal "%FABRICA_DATOS%" %*

echo.
echo  ==================================================================
echo   La fabrica se ha cerrado.
echo  ==================================================================
echo.
pause
